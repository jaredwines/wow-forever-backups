
Blizzard_Console_SavedVars = {
["version"] = 3,
["messageHistory"] = {
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 2",
0,
},
{
"Ripple detail changed to 1",
0,
},
{
"Reflection mode changed to 2",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 1",
0,
},
{
"Refraction mode changed to 1",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 2 - 2 band dynamic shadows on units and terrain, 1024",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 3",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 2",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 1",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1794029778\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1794029778\" expirationTime=\"1794044178\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"All pings from all pongs received",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793950341\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":2,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":0,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793950341\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"00000000218e6470\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"00000000218e6470\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"false\"",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"0000000052efaf20\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"0000000052efaf20\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"00000000218e6470\" state=\"(enum)6\"",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"false\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 2",
0,
},
{
"Ripple detail changed to 1",
0,
},
{
"Reflection mode changed to 2",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 1",
0,
},
{
"Refraction mode changed to 1",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 2 - 2 band dynamic shadows on units and terrain, 1024",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 3",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 2",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 1",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1794034082\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1794034082\" expirationTime=\"1794048482\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"All pings from all pongs received",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1794031482\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":2,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":0,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1794031482\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"0000000021162a60\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"0000000021162a60\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"false\"",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"0000000051b42970\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"0000000051b42970\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"false\" tactEncryptionConnectedReady=\"false\" tactKeyPendingPatchesReady=\"true\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"0000000021162a60\" state=\"(enum)6\"",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_RequestLoad type=\"12\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"5484622608\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"12\" pending=\"false\" hasCallback=\"true\" param=\"5484622608\"",
0,
},
{
"AccountData_RequestLoad type=\"13\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"13\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"14\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"14\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"8\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"5484632704\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"8\" pending=\"false\" hasCallback=\"true\" param=\"5484632704\"",
0,
},
{
"AccountData_RequestLoad type=\"9\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"5484632704\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"9\" pending=\"false\" hasCallback=\"true\" param=\"5484632704\"",
0,
},
{
"AccountData_RequestLoad type=\"18\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"18\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"1\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"196609\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"196609\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"196610\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"196610\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"1\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"65568\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"65568\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"65537\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65537\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"131073\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131073\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000000004c6097c0\" serial=\"17\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"000000004c6097c0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65568\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"1\" currentInitCounter=\"1\" mask=\"32\" buffsize=\"1170\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"196609\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"196610\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65537\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131073\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"8\" pendingBefore=\"false\" hasCallback=\"true\" param=\"5484632704\"",
0,
},
{
"LoadAccountDataFromFile type=\"9\" pendingBefore=\"false\" hasCallback=\"true\" param=\"5484632704\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"12\" pendingBefore=\"false\" hasCallback=\"true\" param=\"5484622608\"",
0,
},
{
"LoadAccountDataFromFile type=\"13\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"14\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"15\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"17\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"18\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x0000004080",
0,
},
{
"Proficiency in item class 2 set to 0x0000004180",
0,
},
{
"Proficiency in item class 2 set to 0x0000004184",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x0000104184",
0,
},
{
"Proficiency in item class 2 set to 0x000010c184",
0,
},
{
"Proficiency in item class 2 set to 0x000010c184",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 11/7/2026 (Sat) 0:48",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000000004c122a80\" serial=\"43\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"000000004c122a80\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"000000004c6097c0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 17m 36s",
0,
},
{
"Level: 0d 3h 22m 17s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"2\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"65568\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"2\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"2\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"196609\" newParam=\"327681\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"327681\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"327681\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"196610\" newParam=\"327682\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"327682\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"327682\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"2\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65568\" newParam=\"131104\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"131104\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131104\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"2\" currentInitCounter=\"2\" mask=\"32\" buffsize=\"1238\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65537\" newParam=\"65539\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65539\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65539\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131073\" newParam=\"131075\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131075\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131075\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 21m 31s",
0,
},
{
"Level: 0d 3h 26m 12s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"3\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"131104\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"3\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"3\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"327681\" newParam=\"458753\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"458753\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"458753\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"327682\" newParam=\"458754\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"458754\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"458754\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"3\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131104\" newParam=\"196640\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"196640\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"196640\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"3\" currentInitCounter=\"3\" mask=\"32\" buffsize=\"1238\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65539\" newParam=\"65541\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65541\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65541\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131075\" newParam=\"131077\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131077\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131077\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 21m 47s",
0,
},
{
"Level: 0d 3h 26m 28s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"4\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"196640\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"4\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"4\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"458753\" newParam=\"589825\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"589825\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"589825\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"458754\" newParam=\"589826\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"589826\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"589826\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"4\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"196640\" newParam=\"262176\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"262176\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"262176\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"4\" currentInitCounter=\"4\" mask=\"32\" buffsize=\"1238\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65541\" newParam=\"65543\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65543\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65543\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131077\" newParam=\"131079\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131079\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131079\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 22m 24s",
0,
},
{
"Level: 0d 3h 27m 5s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"5\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"262176\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"5\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"5\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"589825\" newParam=\"720897\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"720897\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"720897\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"589826\" newParam=\"720898\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"720898\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"720898\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"5\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"262176\" newParam=\"327712\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"327712\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"327712\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"5\" currentInitCounter=\"5\" mask=\"32\" buffsize=\"1238\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65543\" newParam=\"65545\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65545\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65545\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131079\" newParam=\"131081\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131081\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131081\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 24m 13s",
0,
},
{
"Level: 0d 3h 28m 54s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"6\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"327712\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"6\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"6\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"720897\" newParam=\"851969\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"851969\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"851969\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"720898\" newParam=\"851970\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"851970\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"851970\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"6\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"327712\" newParam=\"393248\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"393248\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"393248\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"6\" currentInitCounter=\"6\" mask=\"32\" buffsize=\"1238\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65545\" newParam=\"65547\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65547\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65547\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131081\" newParam=\"131083\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131083\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131083\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 26m 22s",
0,
},
{
"Level: 0d 3h 31m 3s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"7\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"393248\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"7\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"7\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"851969\" newParam=\"983041\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"983041\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"983041\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"851970\" newParam=\"983042\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"983042\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"983042\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"7\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"393248\" newParam=\"458784\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"458784\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"458784\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"7\" currentInitCounter=\"7\" mask=\"32\" buffsize=\"1239\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65547\" newParam=\"65549\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65549\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65549\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131083\" newParam=\"131085\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131085\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131085\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 30m 47s",
0,
},
{
"Level: 0d 3h 35m 28s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"8\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"458784\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"8\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"8\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"983041\" newParam=\"1114113\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"1114113\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"1114113\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"983042\" newParam=\"1114114\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"1114114\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"1114114\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"8\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"458784\" newParam=\"524320\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"524320\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"524320\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"8\" currentInitCounter=\"8\" mask=\"32\" buffsize=\"1239\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65549\" newParam=\"65551\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65551\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65551\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131085\" newParam=\"131087\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131087\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131087\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 31m 4s",
0,
},
{
"Level: 0d 3h 35m 45s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"9\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"524320\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"9\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"9\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"1114113\" newParam=\"1245185\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"1245185\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"1245185\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"1114114\" newParam=\"1245186\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"1245186\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"1245186\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"9\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"524320\" newParam=\"589856\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"589856\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"589856\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"9\" currentInitCounter=\"9\" mask=\"32\" buffsize=\"1239\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65551\" newParam=\"65553\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65553\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65553\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131087\" newParam=\"131089\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131089\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131089\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Logout abort acknowledged",
0,
},
{
"Time played:",
0,
},
{
"Total: 0d 15h 38m 49s",
0,
},
{
"Level: 0d 3h 43m 30s",
0,
},
{
"Logout response received result=\"0\" instant=\"0\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 2",
0,
},
{
"Ripple detail changed to 1",
0,
},
{
"Reflection mode changed to 2",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 1",
0,
},
{
"Refraction mode changed to 1",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 2 - 2 band dynamic shadows on units and terrain, 1024",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 3",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 2",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 1",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1794035623\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net external challenge received usedSSO=\"true\" hasPayload=\"true\"",
0,
},
{
"Fatal login error received result=\" (308)\"",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"Battle.net login session destroy requested isInitialized=\"true\"",
0,
},
{
"Login error state cleared from glue script",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 2",
0,
},
{
"Ripple detail changed to 1",
0,
},
{
"Reflection mode changed to 2",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 1",
0,
},
{
"Refraction mode changed to 1",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 2 - 2 band dynamic shadows on units and terrain, 1024",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 3",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 2",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 1",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1794035645\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1794035645\" expirationTime=\"1794050045\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"All pings from all pongs received",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1794035618\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":2,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":0,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1794035618\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"0000000021fc7c80\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"0000000021fc7c80\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"false\"",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000000005156f720\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"000000005156f720\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"false\" tactEncryptionConnectedReady=\"false\" tactKeyPendingPatchesReady=\"true\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"0000000021fc7c80\" state=\"(enum)6\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
},
["height"] = 300,
["fontHeight"] = 14,
["isShown"] = false,
["commandHistory"] = {
},
}
