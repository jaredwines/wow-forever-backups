
AUCTIONATOR_CONFIG = {
["show_selling_bag_2"] = true,
["no_price_database"] = false,
["crafting_info_show_cheapest_qualities_cost"] = false,
["hide_splash_screen"] = false,
["enchant_tooltips"] = false,
["debug"] = false,
["vendor_tooltips"] = true,
["selling_favourites_sort_owned"] = false,
["auctions_history_length"] = 10,
["selling_icon_size_2"] = 42,
["auction_duration"] = 24,
["price_history_days"] = 21,
["selling_prev_shortcut"] = "BACKSPACE",
["selling_skip_shortcut"] = "SHIFT-SPACE",
["shopping_list_missing_terms"] = false,
["columns_shopping_buy_item"] = {
},
["selling_cancel_shortcut"] = "right click",
["selling_ignored_keys"] = {
},
["default_tab"] = 0,
["shopping_always_confirm_commodity_quantity"] = false,
["undercut_items_ahead"] = 0,
["undercut_scan_not_lifo"] = true,
["undercut_percentage"] = 0,
["columns_posting_history"] = {
},
["pet_tooltips"] = true,
["selling_missing_favourites"] = true,
["selling_item_matching"] = "item name and level",
["gear_vendor_price_multiplier"] = 0,
["selling_post_shortcut"] = "SPACE",
["shift_stack_tooltips"] = true,
["selling_favourite_keys_2"] = {
},
["selling_bag_select_shortcut"] = "alt left click",
["auction_tooltips"] = true,
["auction_age_tooltips"] = false,
["replicate_scan_3"] = false,
["small_tabs"] = false,
["selling_buy_shortcut"] = "alt right click",
["selling_confirm_low_price"] = true,
["columns_selling_search_3"] = {
},
["selling_split_panels"] = false,
["cancel_undercut_shortcut"] = "SPACE",
["historical_prices"] = {
},
["columns_shopping"] = {
},
["autoscan_2"] = false,
["save_last_duration_as_default"] = false,
["auction_mean_tooltips"] = false,
["crafting_info_show_cost"] = true,
["selling_auto_select_next"] = false,
["show_selling_bid_price"] = false,
["default_list_2"] = "",
["columns_shopping_historical_prices"] = {
},
["default_quantities"] = {
0,
1,
0,
1,
nil,
nil,
0,
0,
0,
[0] = 0,
[17] = 1,
[15] = 0,
[12] = 0,
[19] = 0,
[16] = 0,
},
["undercut_static_value"] = 0,
["auto_list_search"] = true,
["crafting_info_show_profit"] = true,
["auction_chat_log"] = true,
["mailbox_tooltips"] = true,
["auction_mean_days_limit"] = 21,
["selling_bag_collapsed"] = false,
["columns_cancelling"] = {
},
["columns_shopping_buy_commodity"] = {
},
["auction_sales_preference"] = "percentage",
["autoscan_interval"] = 15,
["splash_screen_version"] = "anything",
["crafting_info_show"] = true,
["selling_should_reselect_item"] = false,
["shopping_last_container_view"] = 1,
}
AUCTIONATOR_SAVEDVARS = {
}
AUCTIONATOR_SHOPPING_LISTS = {
}
AUCTIONATOR_PRICE_DATABASE = {
["__dbversion"] = 8,
["PvP"] = "�Gversion",
}
AUCTIONATOR_POSTING_HISTORY = {
["__dbversion"] = 1,
}
AUCTIONATOR_VENDOR_PRICE_CACHE = {
["252030"] = 25,
["4604"] = 5,
["1645"] = 400,
["252032"] = 125,
["1179"] = 25,
["3771"] = 200,
["2287"] = 25,
["4606"] = 100,
["4605"] = 25,
["4608"] = 400,
["8948"] = 800,
["159"] = 5,
["252027"] = 5,
["117"] = 5,
["1205"] = 100,
["1708"] = 200,
["252029"] = 125,
["__dbversion"] = 1,
["8766"] = 800,
["4599"] = 400,
["4607"] = 200,
["3770"] = 100,
["8952"] = 800,
["252026"] = 25,
}
AUCTIONATOR_RECENT_SEARCHES = {
}
AUCTIONATOR_SELLING_GROUPS = {
["CustomGroups"] = {
{
["name"] = "FAVOURITES",
["type"] = 1,
["hidden"] = false,
["list"] = {
},
},
},
["Version"] = 1,
["HiddenItems"] = {
},
}
