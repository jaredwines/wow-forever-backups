
TomTomDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["arrow"] = {
["theme"] = "classic",
["position"] = {
"RIGHT",
nil,
"RIGHT",
-208.749267578125,
153.5005035400391,
},
["scale"] = 0.800000011920929,
},
["block"] = {
["enable"] = false,
["position"] = {
"CENTER",
nil,
"CENTER",
0,
-100,
},
},
["paste"] = {
["button"] = {
["showInCompartment"] = true,
},
},
},
},
}
TomTomWaypointsM = {
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["global"] = {
["pinFlagsLive"] = true,
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
