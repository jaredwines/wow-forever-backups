
Blizzard_Console_SavedVars = {
["version"] = 3,
["messageHistory"] = {
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon form submission response received result=\"ERROR_OK (0)\" authenticatorRequired=\"true\" legalRequired=\"false\"",
0,
},
{
"Battle.net login requires additional info infoType=\"(enum)2\"",
0,
},
{
"Battle.net authenticator challenge submission requested",
0,
},
{
"Battle.net logon form submission response received result=\"ERROR_OK (0)\" authenticatorRequired=\"false\" legalRequired=\"false\"",
0,
},
{
"Battle.net credentials submission requested",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net credentials response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793213301\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793213301\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Sending ping results from timeout timeoutNs=\"773662951400\" nowNs=\"773679173900\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"000001a59f8b6b50\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000001a59f8b6b50\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000001a6e3e87960\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"000001a6e3e87960\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"false\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000001a59f8b6b50\" state=\"(enum)6\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Realm server disconnect requested from glue script",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"Realm connection cancel requested isConnected=\"true\" isConnecting=\"false\"",
0,
},
{
"Realm connection disconnect requested reason=\"(enum)14\" realmAddress=\"91-2-8\"",
0,
},
{
"Disconnect requested reason=\"(enum)14\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-8\" pendingReconnect=\"false\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Realm connection disconnected in glue previouslyConnected=\"false\"",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 3",
0,
},
{
"Ripple detail changed to 2",
0,
},
{
"Reflection mode changed to 3",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 2",
0,
},
{
"Refraction mode changed to 2",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048",
0,
},
{
"Shadow texture size changed to 2048.",
0,
},
{
"Soft shadows changed to 1.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 4",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 4",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects enabled",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1793497672\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1793497672\" expirationTime=\"1793512072\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793213301\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793213301\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Sending ping results from timeout timeoutNs=\"3486613934200\" nowNs=\"3486629995000\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"000001a25eafbbb0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000001a25eafbbb0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000001a228a868c0\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"000001a228a868c0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000001a25eafbbb0\" state=\"(enum)6\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"superdistrict\"",
0,
},
{
"Switching to screen=\"SuperDistrictUI\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net super district realm connection requested superDistrictID=\"15\"",
0,
},
{
"Screen invalid. Changing from=\"superdistrict\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"superdistrict\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1\" realmListRequestToken=\"3\" isCurrentToken=\"true\" contentSetIDFilter=\"139\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526792201,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6927,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US1 Realm 9 RP PvP\",\"cfgConfigsID\":9,\"cfgContentSetID\":139,\"cfgLanguagesID\":1,\"superDistrictID\":15}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526792201\" lastActiveTime=\"1\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-1-9\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"2\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Disconnect requested reason=\"(enum)12\"",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-8\" pendingReconnect=\"true\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Character selection updating character list success=\"false\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Realm connection requested realmAddress=\"91-1-9\"",
0,
},
{
"Killing connection connection=\"000001a228a868c0\" state=\"(enum)7\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-1-9\" connection=\"000001a2259f76b0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000001a2259f76b0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-1-9\"",
0,
},
{
"Client connected",
0,
},
{
"Connecting to sourceRealmAddress=\"91-1-9\" connection=\"000001a27004eaa0\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"000001a27004eaa0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"Realm wait queue update received waitCount=\"0\" waitMinutes=\"0\" hasFCM=\"false\" canCreateOnlyIfExisting=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000001a2259f76b0\" state=\"(enum)6\"",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:Exit",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"superdistrict\"",
0,
},
{
"Switching to screen=\"SuperDistrictUI\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Screen invalid. Changing from=\"superdistrict\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"superdistrict\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:Exit",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"SaveCharacterOrder called with mismatched realmless settings, not saving",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:Exit",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"superdistrict\"",
0,
},
{
"Switching to screen=\"SuperDistrictUI\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net super district realm connection requested superDistrictID=\"1\"",
0,
},
{
"Screen invalid. Changing from=\"superdistrict\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"superdistrict\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793213301\" realmListRequestToken=\"6\" isCurrentToken=\"true\" contentSetIDFilter=\"136\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793213301\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"3\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Disconnect requested reason=\"(enum)12\"",
0,
},
{
"Realm connection disconnected realmAddress=\"91-1-9\" pendingReconnect=\"true\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Character selection updating character list success=\"false\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Killing connection connection=\"000001a27004eaa0\" state=\"(enum)7\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"000001a25eaf48a0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000001a25eaf48a0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000001a225a11310\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"000001a225a11310\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000001a25eaf48a0\" state=\"(enum)6\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:Exit",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Realm server disconnect requested from glue script",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"Realm connection cancel requested isConnected=\"true\" isConnecting=\"false\"",
0,
},
{
"Realm connection disconnect requested reason=\"(enum)14\" realmAddress=\"91-2-8\"",
0,
},
{
"Disconnect requested reason=\"(enum)14\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-8\" pendingReconnect=\"false\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Realm connection disconnected in glue previouslyConnected=\"false\"",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 3",
0,
},
{
"Ripple detail changed to 2",
0,
},
{
"Reflection mode changed to 3",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 2",
0,
},
{
"Refraction mode changed to 2",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048",
0,
},
{
"Shadow texture size changed to 2048.",
0,
},
{
"Soft shadows changed to 1.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 4",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 4",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects enabled",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1793498405\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1793498405\" expirationTime=\"1793512805\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793213301\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793213301\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Sending ping results from timeout timeoutNs=\"4219641785300\" nowNs=\"4219657857500\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"000001435f826e30\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000001435f826e30\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000143e92df790\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"00000143e92df790\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000001435f826e30\" state=\"(enum)6\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"superdistrict\"",
0,
},
{
"Switching to screen=\"SuperDistrictUI\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net super district realm connection requested superDistrictID=\"15\"",
0,
},
{
"Screen invalid. Changing from=\"superdistrict\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"superdistrict\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1\" realmListRequestToken=\"3\" isCurrentToken=\"true\" contentSetIDFilter=\"139\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857737,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6935,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 9 RP PvP\",\"cfgConfigsID\":9,\"cfgContentSetID\":139,\"cfgLanguagesID\":1,\"superDistrictID\":15}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857737\" lastActiveTime=\"1\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-9\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"2\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Disconnect requested reason=\"(enum)12\"",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-8\" pendingReconnect=\"true\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Character selection updating character list success=\"false\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Realm connection requested realmAddress=\"91-2-9\"",
0,
},
{
"Killing connection connection=\"00000143e92df790\" state=\"(enum)7\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-9\" connection=\"0000014373d12580\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"0000014373d12580\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-9\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-9\" connection=\"00000143dd6000f0\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"00000143dd6000f0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"0000014373d12580\" state=\"(enum)6\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Character create response received result=\"(enum)63\"",
0,
},
{
"Character create response received result=\"(enum)63\"",
0,
},
{
"Character create response received result=\"(enum)63\"",
0,
},
{
"Character create response received result=\"(enum)63\"",
0,
},
{
"Character create response received result=\"(enum)63\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:Exit",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"superdistrict\"",
0,
},
{
"Switching to screen=\"SuperDistrictUI\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net super district realm connection requested superDistrictID=\"1\"",
0,
},
{
"Screen invalid. Changing from=\"superdistrict\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"superdistrict\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" characterCount=\"0\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793213301\" realmListRequestToken=\"6\" isCurrentToken=\"true\" contentSetIDFilter=\"136\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793213301\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"3\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Disconnect requested reason=\"(enum)12\"",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-9\" pendingReconnect=\"true\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Character selection updating character list success=\"false\" isRegionwideData=\"false\" isDeletedCharacters=\"false\" count=\"0\"",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Killing connection connection=\"00000143dd6000f0\" state=\"(enum)7\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"0000014373d12070\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"0000014373d12070\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000143dd6000f0\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"00000143dd6000f0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"true\" tactEncryptionConnectedReady=\"true\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"0000014373d12070\" state=\"(enum)6\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:Exit",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Realm server disconnect requested from glue script",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"Realm connection cancel requested isConnected=\"true\" isConnecting=\"false\"",
0,
},
{
"Realm connection disconnect requested reason=\"(enum)14\" realmAddress=\"91-2-8\"",
0,
},
{
"Disconnect requested reason=\"(enum)14\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-8\" pendingReconnect=\"false\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Realm connection disconnected in glue previouslyConnected=\"false\"",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 3",
0,
},
{
"Ripple detail changed to 2",
0,
},
{
"Reflection mode changed to 3",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 2",
0,
},
{
"Refraction mode changed to 2",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048",
0,
},
{
"Shadow texture size changed to 2048.",
0,
},
{
"Soft shadows changed to 1.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 4",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 4",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects enabled",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1793508718\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1793508718\" expirationTime=\"1793523118\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1793213301\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":4,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":256,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1793213301\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Sending ping results from timeout timeoutNs=\"14532261050900\" nowNs=\"14532277028600\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"0000024872696310\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"0000024872696310\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"true\"",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"0000024863463490\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"0000024863463490\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"0000024872696310\" state=\"(enum)6\"",
0,
},
{
"Realm wait queue completed",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"1\" hadPendingResult=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"1\"",
0,
},
{
"Switching to screen=\"CharacterCreateFrame\" (from \"charselect\")",
0,
},
{
"Character create response received result=\"(enum)24\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"charcreate\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From CharacterCreateMixin:OnEvent",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
{
"Realm server disconnect requested from glue script",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
{
"Realm connection cancel requested isConnected=\"true\" isConnecting=\"false\"",
0,
},
{
"Realm connection disconnect requested reason=\"(enum)14\" realmAddress=\"91-2-8\"",
0,
},
{
"Disconnect requested reason=\"(enum)14\"",
0,
},
{
"Screen invalid. Changing from=\"charselect\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"charselect\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Realm connection disconnected realmAddress=\"91-2-8\" pendingReconnect=\"false\"",
0,
},
{
"Client disconnected",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Realm connection disconnected in glue previouslyConnected=\"false\"",
0,
},
{
"Battle.net front disconnect deferred",
0,
},
},
["height"] = 299.9999694824219,
["fontHeight"] = 14,
["isShown"] = false,
["commandHistory"] = {
},
}
