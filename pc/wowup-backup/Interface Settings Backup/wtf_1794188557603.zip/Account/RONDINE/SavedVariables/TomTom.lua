
TomTomDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["arrow"] = {
["arrival"] = 9,
["lock"] = true,
["theme"] = "classic",
["scale"] = 0.9500000476837158,
["alpha"] = 0.9500000476837158,
["position"] = {
"BOTTOM",
nil,
"BOTTOM",
-2.850738048553467,
164.1669464111328,
},
["stickycorpse"] = true,
},
["paste"] = {
["button"] = {
["showInCompartment"] = true,
},
},
["block"] = {
["enable"] = false,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-75.83352661132812,
-291.6669006347656,
},
},
},
},
}
TomTomWaypointsM = {
["global"] = {
["pinFlagsLive"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
