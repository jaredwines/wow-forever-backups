
WT_LearnedPetAbilities = {
[24545] = true,
[2649] = true,
[14916] = true,
[4187] = true,
}
WT_NeedsToOpenBeastTraining = false
WT_IgnoredSpells = {
}
WT_PriceFaction = "auto"
WT_HideWeaponSkillSwitcher = false
WT_Crafting = {
["selectedProfessions"] = {
[165] = true,
[356] = true,
[393] = true,
[185] = true,
[129] = true,
},
["expandedProfessions"] = {
{
},
{
},
{
},
{
},
{
},
},
["settings"] = {
["showOtherFactionRecipes"] = false,
["showMerchantsFavorRecipes"] = false,
["showReputationRecipes"] = false,
},
["selectedSources"] = {
["world_object"] = false,
["trainer"] = true,
["drop"] = false,
["vendor"] = true,
["quest"] = true,
["crafted"] = false,
},
}
