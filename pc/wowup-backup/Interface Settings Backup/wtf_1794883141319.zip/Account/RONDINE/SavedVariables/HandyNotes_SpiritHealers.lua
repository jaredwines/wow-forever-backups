
HandyNotes_SpiritHealersDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["global"] = {
["setupDone"] = true,
},
["profiles"] = {
["Default"] = {
},
},
}
