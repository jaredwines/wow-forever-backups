
ForeverCombatMeterProfiles = {
["profiles"] = {
["Default"] = {
["minimapAngle"] = 294,
["themeSets"] = {
["seedRevision"] = 0,
["revision"] = 15,
["comicGreyPinned"] = true,
["themeColors"] = {
},
},
["minimapShow"] = false,
["windows"] = {
{
["y"] = -982,
["x"] = 268,
["point"] = "TOP",
["locked"] = true,
["view"] = "overall",
},
{
["y"] = -983,
["x"] = -271,
["point"] = "TOP",
["locked"] = true,
["mode"] = "threat",
["view"] = "overall",
},
},
["windowCount"] = 2,
["locked"] = true,
["threatWarn"] = true,
},
},
}
