
HandyNotes_ReagentVendorsDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["global"] = {
["setupDone"] = true,
},
["profiles"] = {
["Default"] = {
["mine"] = true,
},
},
}
