
HandyNotes_FlightMastersDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["global"] = {
["setupDone"] = true,
},
["profiles"] = {
["Default"] = {
["continent"] = true,
},
},
}
