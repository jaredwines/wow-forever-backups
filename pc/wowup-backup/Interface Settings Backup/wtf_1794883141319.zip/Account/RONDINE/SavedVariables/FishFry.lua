
FishFryDB = {
["settingsProfileMigration4bnApplied"] = true,
["foreverHudPoint"] = {
["y"] = 108.0998611450195,
["x"] = 816.4998779296875,
["point"] = "CENTER",
["relativePoint"] = "BOTTOMLEFT",
},
["forever"] = {
["sessionsUI"] = {
["schemaVersion"] = 1,
["selectedByCharacter"] = {
},
},
["characterIdentity"] = {
["schemaVersion"] = 2,
["legacyBucketsPreserved"] = true,
},
["sessions"] = {
["schemaVersion"] = 5,
["characters"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["byID"] = {
},
["characterKey"] = "ForeverGUID-Player-6934-0043A935",
["order"] = {
},
["nextID"] = 1,
["characterName"] = "Rondine",
},
},
},
["wiki"] = {
["schemaVersion"] = 1,
["search"] = "",
["category"] = "all",
},
["schemaVersion"] = 1,
["minimap"] = {
["shown"] = true,
["angle"] = 225,
["positionMigration127dApplied"] = true,
},
},
["activeBarCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["releaseReset113Applied"] = true,
["characterTackleSwap"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["normalRestoreTime"] = 10310.332,
["normalRestore"] = {
["1"] = {
["empty"] = true,
["slot"] = 1,
},
["8"] = {
["itemID"] = 252425,
["link"] = "|cnIQ3:|Hitem:252425:15:::::::20:1485::::::::Player-6934-0043A935:|h[Dark Leather Boots]|h|r",
["empty"] = false,
["slot"] = 8,
},
["16"] = {
["itemID"] = 276886,
["link"] = "|cnIQ2:|Hitem:276886::::::::20:1485::11:::::::|h[Chol'aruk's Trophy Sword]|h|r",
["empty"] = false,
["slot"] = 16,
},
["17"] = {
["empty"] = true,
["slot"] = 17,
},
["18"] = {
["itemID"] = 5309,
["link"] = "|cnIQ2:|Hitem:5309::::::::20:1485::11:::::::|h[Privateer Musket]|h|r",
["empty"] = false,
["slot"] = 18,
},
["10"] = {
["itemID"] = 2976,
["link"] = "|cnIQ2:|Hitem:2976:15:::::::20:1485::1::1:28:5256:::::|h[Hunting Gloves]|h|r",
["empty"] = false,
["slot"] = 10,
},
["6"] = {
["itemID"] = 4246,
["link"] = "|cnIQ2:|Hitem:4246::::::::20:1485::::::::Player-6934-01B13CBF:|h[Fine Leather Belt]|h|r",
["empty"] = false,
["slot"] = 6,
},
},
["active"] = false,
["normalRestoreOwner"] = "ForeverGUID-Player-6934-0043A935",
["owner"] = "ForeverGUID-Player-6934-0043A935",
["restore"] = {
},
["normalRestoreReason"] = "PLAYER_REGEN_ENABLED",
},
},
["foreverCookingKnowledge"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["campsiteObservedProfessions"] = {
["cooking"] = true,
["skinning"] = true,
["first aid"] = true,
["fishing"] = true,
["leatherworking"] = true,
},
["legacyPositiveSeeded"] = true,
["lastPositiveSource"] = "COOKING_RECIPE_POSITIVE",
["lastUpdatedAt"] = 1794882581,
["recipes"] = {
["7751"] = true,
["1230117"] = true,
["6499"] = true,
["7753"] = true,
["1229737"] = true,
["1229432"] = true,
["1229517"] = true,
["1229745"] = true,
["7752"] = true,
["7827"] = true,
},
["schemaVersion"] = 2,
["campsiteProfessionSnapshotVersion"] = 1,
},
},
["cookingCharacterCacheMigration103Applied"] = true,
["journal"] = {
["totalCatches"] = 293,
["fishingHistory"] = {
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 1,
["firstCaught"] = 1794882335,
["lastCaught"] = 1794882335,
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 17,
["firstCaught"] = 1794879656,
["lastCaught"] = 1794882400,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["lastZone"] = "Durotar",
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 8,
["firstCaught"] = 1794879680,
["lastCaught"] = 1794882231,
},
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["caught"] = 76,
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["lastZone"] = "Durotar",
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882284,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794543010,
["caught"] = 113,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794533891,
["firstCaught"] = 1794533891,
["lastZone"] = "Durotar",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882580,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794542998,
["caught"] = 78,
},
},
["summaryDefault113eApplied"] = true,
["milestoneAllDefault169wApplied"] = true,
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["milestoneSearch"] = "",
["fish"] = {
[6292] = {
["source"] = "fishing-loot-structured",
["count"] = 1,
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["source"] = "fishing-loot-structured",
["count"] = 8,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882231,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["count"] = 76,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["source"] = "fishing-loot-structured",
["count"] = 113,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882284,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6522] = {
["source"] = "fishing-loot-structured",
["count"] = 17,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882400,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
[6289] = {
["source"] = "fishing-loot-structured",
["count"] = 78,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882580,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
},
["accountWide"] = true,
["skillCapEventStyle035Applied"] = true,
["surfaceMode"] = "milestones",
["milestoneNotices"] = true,
["guildChatAnnounce"] = false,
["milestoneView"] = "all",
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
["225"] = true,
[150] = true,
[225] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["totalFishingSeconds"] = 5317.177000000027,
["milestoneAutoShareMode"] = "OFF",
["skillMax"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["milestoneForcedEmotes"] = true,
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["count"] = 1,
["source"] = "equipped",
["lastSeen"] = 1794528221,
},
},
["milestoneGuildReports"] = false,
["activeCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["viewMode"] = "account",
["skillObserved"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["characters"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["fishingHistory"] = {
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 1,
["firstCaught"] = 1794882335,
["lastCaught"] = 1794882335,
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 17,
["firstCaught"] = 1794879656,
["lastCaught"] = 1794882400,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["lastZone"] = "Durotar",
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 8,
["firstCaught"] = 1794879680,
["lastCaught"] = 1794882231,
},
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["caught"] = 76,
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["lastZone"] = "Durotar",
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882284,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794543010,
["caught"] = 113,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794533891,
["firstCaught"] = 1794533891,
["lastZone"] = "Durotar",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882580,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794542998,
["caught"] = 78,
},
},
["lastSeen"] = 1794882582,
["fish"] = {
[6292] = {
["source"] = "fishing-loot-structured",
["count"] = 1,
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["source"] = "fishing-loot-structured",
["count"] = 8,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882231,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["count"] = 76,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["source"] = "fishing-loot-structured",
["count"] = 113,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882284,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6522] = {
["source"] = "fishing-loot-structured",
["count"] = 17,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882400,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
[6289] = {
["source"] = "fishing-loot-structured",
["count"] = 78,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882580,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
},
["skillCapEventStyle035Applied"] = true,
["totalFishingSeconds"] = 5317.177000000027,
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
["225"] = true,
[150] = true,
[225] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["skillObserved"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["count"] = 1,
["source"] = "equipped",
["lastSeen"] = 1794528221,
},
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["count"] = 75,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
},
},
["skillMax"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["name"] = "Rondine",
["faction"] = "Horde",
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
["realm"] = "CAMWOW US2 Realm 8 PvP",
["totalCatches"] = 293,
},
},
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["count"] = 75,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
},
},
["recordSearch"] = "",
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
},
["bar"] = {
["oneButtonRangeWarning"] = true,
["direction"] = "RIGHT",
["castTimer"] = {
["enabled"] = true,
["horizontalSide"] = "ABOVE",
["verticalSide"] = "RIGHT",
["verticalDirection"] = "BOTTOM_TO_TOP",
["horizontalDirection"] = "LEFT_TO_RIGHT",
["colorMode"] = "THEME",
["circleDirection"] = "CLOCKWISE",
},
["showAllFlyoutChoices"] = false,
["tooltips"] = true,
["autoLootPreferenceEstablished"] = true,
["locked"] = false,
["authoredHudAnimations"] = true,
["autoLootWhileFishing"] = true,
["doubleRightCast"] = true,
["forceShown"] = true,
["oneButtonInteractAssist"] = true,
["hiddenButtons"] = {
["guide"] = true,
},
["oneButtonFishing"] = true,
["point"] = {
["y"] = 108.0998611450195,
["x"] = 816.4998779296875,
["point"] = "CENTER",
["relativePoint"] = "BOTTOMLEFT",
},
["contextualFishingKeyboardKey"] = "ENTER",
["effectiveReadoutColor"] = "GREEN",
["flyouts"] = {
["consume"] = "DOWN",
["lure"] = "DOWN",
["cook"] = "DOWN",
["fire"] = "DOWN",
["gear"] = "DOWN",
["sessions"] = "DOWN",
},
["selectedCampfireAction"] = "AUTO",
["spacing"] = 2,
["doubleRightCastSecureAttempt100Applied"] = true,
["mode"] = "CIRCLE",
["expanded"] = true,
["selectedLureItemID"] = 6529,
["suppressTooltipsDuringActions"] = false,
["modeDefault033Applied"] = true,
["oneButtonHudClick"] = true,
["flyoutDefault042Applied"] = true,
["pauseClickToMoveFishing"] = false,
["spacingDefault031Applied"] = true,
["effectiveReadoutSize"] = 1,
["hudButtonAnimations"] = true,
["lootFloaters"] = true,
["oneButtonRangeBell"] = true,
["verticalDirection"] = "DOWN",
["scale"] = 1,
["visibilityMode"] = "FORCED_ON",
["contextualFishingKeyBeforeSplit172d4"] = "F",
["horizontalDirection"] = "RIGHT",
},
["characterCooking"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["lastScanAt"] = 1794880113,
["recipeStates"] = {
["7754"] = {
["outputItemID"] = 6316,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6317,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["7827"] = {
["outputItemID"] = 5095,
["disabled"] = false,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["lastVerifiedAt"] = 1794882581,
["reagents"] = {
{
["items"] = {
6361,
},
["quantityRequired"] = 1,
},
},
},
["25954"] = {
["outputItemID"] = 21217,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
21153,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
},
},
["1247741"] = {
["outputItemID"] = 8957,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
8959,
},
["quantityRequired"] = 1,
},
},
},
["18240"] = {
["outputItemID"] = 13928,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13755,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["1250158"] = {
["outputItemID"] = 250081,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
7974,
},
["quantityRequired"] = 3,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 4,
},
},
},
["25704"] = {
["outputItemID"] = 21072,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
21071,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["7752"] = {
["outputItemID"] = 787,
["lastVerifiedAt"] = 1794882581,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["disabled"] = false,
["reagents"] = {
{
["items"] = {
6303,
},
["quantityRequired"] = 1,
},
},
},
["8238"] = {
["outputItemID"] = 6657,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6522,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["18245"] = {
["outputItemID"] = 13933,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13888,
},
["quantityRequired"] = 1,
},
{
["items"] = {
159,
},
["quantityRequired"] = 1,
},
},
},
["7751"] = {
["outputItemID"] = 6290,
["lastVerifiedAt"] = 1794882581,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["disabled"] = false,
["reagents"] = {
{
["items"] = {
6291,
},
["quantityRequired"] = 1,
},
},
},
["18241"] = {
["outputItemID"] = 13930,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13758,
},
["quantityRequired"] = 1,
},
},
},
["18239"] = {
["outputItemID"] = 13927,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13754,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["18244"] = {
["outputItemID"] = 13932,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13760,
},
["quantityRequired"] = 1,
},
},
},
["7755"] = {
["outputItemID"] = 4593,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6308,
},
["quantityRequired"] = 1,
},
},
},
["6415"] = {
["outputItemID"] = 5476,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
5468,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["20916"] = {
["outputItemID"] = 8364,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
8365,
},
["quantityRequired"] = 1,
},
},
},
["7828"] = {
["outputItemID"] = 4594,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6362,
},
["quantityRequired"] = 1,
},
},
},
["18242"] = {
["outputItemID"] = 13929,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13756,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 2,
},
},
},
["6500"] = {
["outputItemID"] = 5527,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
5504,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
},
},
["7753"] = {
["outputItemID"] = 4592,
["disabled"] = false,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["lastVerifiedAt"] = 1794882581,
["reagents"] = {
{
["items"] = {
6289,
},
["quantityRequired"] = 1,
},
},
},
["18246"] = {
["outputItemID"] = 13934,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13893,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["18247"] = {
["outputItemID"] = 13935,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13889,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["6499"] = {
["outputItemID"] = 5525,
["disabled"] = false,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["lastVerifiedAt"] = 1794882581,
["reagents"] = {
{
["items"] = {
5503,
},
["quantityRequired"] = 1,
},
{
["items"] = {
159,
},
["quantityRequired"] = 1,
},
},
},
["18243"] = {
["outputItemID"] = 13931,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13759,
},
["quantityRequired"] = 1,
},
{
["items"] = {
159,
},
["quantityRequired"] = 1,
},
},
},
["20626"] = {
["outputItemID"] = 16766,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
7974,
},
["quantityRequired"] = 2,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
{
["items"] = {
1179,
},
["quantityRequired"] = 1,
},
},
},
["7213"] = {
["outputItemID"] = 6038,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
4655,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
},
},
["18238"] = {
["outputItemID"] = 6887,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
4603,
},
["quantityRequired"] = 1,
},
},
},
["6501"] = {
["outputItemID"] = 5526,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
5503,
},
["quantityRequired"] = 1,
},
{
["items"] = {
1179,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
},
["knownTradeSkillNames"] = {
["slitherskin mackerel"] = true,
["brilliant smallfish"] = true,
["rainbow fin albacore"] = true,
["longjaw mud snapper"] = true,
["boiled clams"] = true,
},
["recipeCacheSchema"] = 4,
["scanRecipes"] = true,
["lastScanTrackedKnown"] = 5,
["recipeVariantByFish"] = {
},
["lastScanVisibleRecipes"] = 5,
["knownNames"] = {
["slitherskin mackerel"] = true,
["brilliant smallfish"] = true,
["rainbow fin albacore"] = true,
["longjaw mud snapper"] = true,
["boiled clams"] = true,
},
["characterKey"] = "ForeverGUID-Player-6934-0043A935",
["lastScanWindowRows"] = 5,
["knownTradeSkillRows"] = {
},
["lastScanNewRawRecipes"] = 0,
["knownRecipes"] = {
},
["knownTradeSkillResults"] = {
["787"] = true,
["5525"] = true,
["6290"] = true,
["4592"] = true,
["5095"] = true,
},
["knownTradeSkillSpells"] = {
["7751"] = true,
["7827"] = true,
["6499"] = true,
["7752"] = true,
["7753"] = true,
},
["lastScanNewTrackedRecipes"] = 0,
["knownResults"] = {
["787"] = true,
["5525"] = true,
["6290"] = true,
["4592"] = true,
["5095"] = true,
},
["knownRecipesScanned"] = true,
},
},
["characterProfiles"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["hudPoint"] = {
["y"] = 90,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["guideStarterAssist"] = false,
["contextualFishingSplit172d4Applied"] = true,
["milestoneSystem113dApplied"] = true,
["forever"] = {
["sessionsUI"] = {
["schemaVersion"] = 1,
["selectedByCharacter"] = {
},
},
["characterIdentity"] = {
["schemaVersion"] = 2,
["legacyBucketsPreserved"] = true,
},
["sessions"] = {
["schemaVersion"] = 1,
["characters"] = {
},
},
["schemaVersion"] = 1,
["wiki"] = {
["schemaVersion"] = 1,
["search"] = "",
["category"] = "all",
},
},
["sound"] = {
["muteOriginalSplash"] = false,
["volumeBoost"] = true,
["helperVolume"] = 1,
["mutePetSoundsWhilePole"] = true,
["probeEnabled"] = false,
["focus"] = true,
["adjustMusic"] = true,
["enabled"] = true,
["background"] = true,
["soundDefault0202Applied"] = true,
["activation"] = "cast",
},
["keybinds"] = {
},
["milestoneForcedEmotes"] = false,
["milestoneGuildReports"] = false,
["guideStarterAssistGroupKey"] = "",
["notifications"] = true,
["bar"] = {
["oneButtonRangeWarning"] = true,
["direction"] = "RIGHT",
["castTimer"] = {
["enabled"] = true,
["horizontalSide"] = "ABOVE",
["verticalSide"] = "RIGHT",
["verticalDirection"] = "BOTTOM_TO_TOP",
["horizontalDirection"] = "LEFT_TO_RIGHT",
["colorMode"] = "THEME",
["circleDirection"] = "CLOCKWISE",
},
["showAllFlyoutChoices"] = false,
["tooltips"] = true,
["autoLootPreferenceEstablished"] = true,
["locked"] = false,
["authoredHudAnimations"] = true,
["autoLootWhileFishing"] = true,
["doubleRightCast"] = true,
["forceShown"] = true,
["oneButtonInteractAssist"] = true,
["hiddenButtons"] = {
["guide"] = true,
},
["oneButtonFishing"] = true,
["point"] = {
["y"] = 108.0998611450195,
["x"] = 816.4998779296875,
["point"] = "CENTER",
["relativePoint"] = "BOTTOMLEFT",
},
["contextualFishingKeyboardKey"] = "ENTER",
["effectiveReadoutColor"] = "GREEN",
["flyouts"] = {
["consume"] = "DOWN",
["lure"] = "DOWN",
["cook"] = "DOWN",
["fire"] = "DOWN",
["gear"] = "DOWN",
["sessions"] = "DOWN",
},
["selectedCampfireAction"] = "AUTO",
["spacing"] = 2,
["doubleRightCastSecureAttempt100Applied"] = true,
["mode"] = "CIRCLE",
["expanded"] = true,
["selectedLureItemID"] = 6529,
["suppressTooltipsDuringActions"] = false,
["modeDefault033Applied"] = true,
["oneButtonHudClick"] = true,
["flyoutDefault042Applied"] = true,
["pauseClickToMoveFishing"] = false,
["spacingDefault031Applied"] = true,
["effectiveReadoutSize"] = 1,
["hudButtonAnimations"] = true,
["lootFloaters"] = true,
["oneButtonRangeBell"] = true,
["verticalDirection"] = "DOWN",
["scale"] = 1,
["visibilityMode"] = "FORCED_ON",
["contextualFishingKeyBeforeSplit172d4"] = "F",
["horizontalDirection"] = "RIGHT",
},
["hudButtonSwap132dApplied"] = true,
["snapshotOnHover"] = true,
["guidePoint"] = {
["y"] = 0,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["minimap"] = {
["shown"] = true,
["angle"] = 225,
},
["milestoneNotices"] = true,
["sessionAutoStartWithPole"] = false,
["tackle"] = {
["mode"] = "MANUAL",
},
["theme"] = "gilded",
["guideWindowScale"] = 1.2,
["guideTextScale"] = 1,
["tackleSwap"] = {
["normalRestoreTime"] = 10310.332,
["normalRestore"] = {
["1"] = {
["empty"] = true,
["slot"] = 1,
},
["8"] = {
["itemID"] = 252425,
["link"] = "|cnIQ3:|Hitem:252425:15:::::::20:1485::::::::Player-6934-0043A935:|h[Dark Leather Boots]|h|r",
["empty"] = false,
["slot"] = 8,
},
["16"] = {
["itemID"] = 276886,
["link"] = "|cnIQ2:|Hitem:276886::::::::20:1485::11:::::::|h[Chol'aruk's Trophy Sword]|h|r",
["empty"] = false,
["slot"] = 16,
},
["17"] = {
["empty"] = true,
["slot"] = 17,
},
["18"] = {
["itemID"] = 5309,
["link"] = "|cnIQ2:|Hitem:5309::::::::20:1485::11:::::::|h[Privateer Musket]|h|r",
["empty"] = false,
["slot"] = 18,
},
["10"] = {
["itemID"] = 2976,
["link"] = "|cnIQ2:|Hitem:2976:15:::::::20:1485::1::1:28:5256:::::|h[Hunting Gloves]|h|r",
["empty"] = false,
["slot"] = 10,
},
["6"] = {
["itemID"] = 4246,
["link"] = "|cnIQ2:|Hitem:4246::::::::20:1485::::::::Player-6934-01B13CBF:|h[Fine Leather Belt]|h|r",
["empty"] = false,
["slot"] = 6,
},
},
["active"] = false,
["normalRestoreOwner"] = "ForeverGUID-Player-6934-0043A935",
["owner"] = "ForeverGUID-Player-6934-0043A935",
["restore"] = {
},
["normalRestoreReason"] = "PLAYER_REGEN_ENABLED",
},
["milestoneAutoShareMode"] = "OFF",
["barShown"] = true,
["journal"] = {
["totalCatches"] = 293,
["fishingHistory"] = {
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 1,
["firstCaught"] = 1794882335,
["lastCaught"] = 1794882335,
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 17,
["firstCaught"] = 1794879656,
["lastCaught"] = 1794882400,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["lastZone"] = "Durotar",
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 8,
["firstCaught"] = 1794879680,
["lastCaught"] = 1794882231,
},
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["caught"] = 76,
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["lastZone"] = "Durotar",
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882284,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794543010,
["caught"] = 113,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794533891,
["firstCaught"] = 1794533891,
["lastZone"] = "Durotar",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882580,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794542998,
["caught"] = 78,
},
},
["summaryDefault113eApplied"] = true,
["milestoneAllDefault169wApplied"] = true,
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["milestoneSearch"] = "",
["fish"] = {
[6292] = {
["source"] = "fishing-loot-structured",
["count"] = 1,
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["source"] = "fishing-loot-structured",
["count"] = 8,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882231,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["count"] = 76,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["source"] = "fishing-loot-structured",
["count"] = 113,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882284,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6522] = {
["source"] = "fishing-loot-structured",
["count"] = 17,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882400,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
[6289] = {
["source"] = "fishing-loot-structured",
["count"] = 78,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882580,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
},
["accountWide"] = true,
["skillCapEventStyle035Applied"] = true,
["surfaceMode"] = "milestones",
["milestoneNotices"] = true,
["guildChatAnnounce"] = false,
["milestoneView"] = "all",
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
["225"] = true,
[150] = true,
[225] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["totalFishingSeconds"] = 5317.177000000027,
["milestoneAutoShareMode"] = "OFF",
["skillMax"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["milestoneForcedEmotes"] = true,
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["count"] = 1,
["source"] = "equipped",
["lastSeen"] = 1794528221,
},
},
["milestoneGuildReports"] = false,
["activeCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["viewMode"] = "account",
["skillObserved"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["characters"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["fishingHistory"] = {
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 1,
["firstCaught"] = 1794882335,
["lastCaught"] = 1794882335,
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 17,
["firstCaught"] = 1794879656,
["lastCaught"] = 1794882400,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["lastZone"] = "Durotar",
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 8,
["firstCaught"] = 1794879680,
["lastCaught"] = 1794882231,
},
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["caught"] = 76,
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["lastZone"] = "Durotar",
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882284,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794543010,
["caught"] = 113,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794533891,
["firstCaught"] = 1794533891,
["lastZone"] = "Durotar",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastCaught"] = 1794882580,
["lastZone"] = "The Barrens",
["firstCaught"] = 1794542998,
["caught"] = 78,
},
},
["lastSeen"] = 1794882582,
["fish"] = {
[6292] = {
["source"] = "fishing-loot-structured",
["count"] = 1,
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["source"] = "fishing-loot-structured",
["count"] = 8,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882231,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["count"] = 76,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["source"] = "fishing-loot-structured",
["count"] = 113,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882284,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6522] = {
["source"] = "fishing-loot-structured",
["count"] = 17,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882400,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
[6289] = {
["source"] = "fishing-loot-structured",
["count"] = 78,
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794882580,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
},
["skillCapEventStyle035Applied"] = true,
["totalFishingSeconds"] = 5317.177000000027,
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
["225"] = true,
[150] = true,
[225] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["skillObserved"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["count"] = 1,
["source"] = "equipped",
["lastSeen"] = 1794528221,
},
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["count"] = 75,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
},
},
["skillMax"] = {
["Fishing"] = 165,
["Cooking"] = 73,
},
["name"] = "Rondine",
["faction"] = "Horde",
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
["realm"] = "CAMWOW US2 Realm 8 PvP",
["totalCatches"] = 293,
},
},
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["count"] = 75,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
},
},
["recordSearch"] = "",
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
},
["contextualFishingRestored164bApplied"] = true,
["contextualKeyOptIn165bApplied"] = true,
["hudShown"] = false,
["activeTab"] = "options",
["warnings"] = true,
["optionsPage"] = "sound",
["guideFullscreen"] = false,
["milestoneGuildReports140aApplied"] = true,
["milestoneSharingPolicy122wApplied"] = true,
},
},
["sharedProfile"] = {
["guideFullscreen"] = false,
["snapshotOnHover"] = true,
["contextualFishingSplit172d4Applied"] = true,
["guidePoint"] = {
["y"] = 0,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["hudShown"] = false,
["milestoneNotices"] = true,
["sessionAutoStartWithPole"] = false,
["hudPoint"] = {
["y"] = 90,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["theme"] = "ocean",
["tackle"] = {
["mode"] = "BEST",
},
["milestoneForcedEmotes"] = true,
["sound"] = {
["enabled"] = false,
["volumeBoost"] = true,
["focus"] = true,
["background"] = true,
["activation"] = "cast",
},
["guideWindowScale"] = 1.2,
["guideTextScale"] = 1,
["tackleSwap"] = {
["restore"] = {
},
["active"] = false,
},
["milestoneAutoShareMode"] = "OFF",
["keybinds"] = {
},
["guideStarterAssistGroupKey"] = "",
["barShown"] = true,
["activeTab"] = "guide",
["milestoneGuildReports"] = false,
["contextualKeyOptIn165bApplied"] = true,
["minimap"] = {
["shown"] = true,
["angle"] = 225,
},
["forever"] = {
["sessionsUI"] = {
["schemaVersion"] = 1,
["selectedByCharacter"] = {
},
},
["characterIdentity"] = {
["schemaVersion"] = 2,
["legacyBucketsPreserved"] = true,
},
["sessions"] = {
["schemaVersion"] = 1,
["characters"] = {
},
},
["schemaVersion"] = 1,
["wiki"] = {
["schemaVersion"] = 1,
["search"] = "",
["category"] = "all",
},
},
["warnings"] = true,
["notifications"] = true,
["contextualFishingRestored164bApplied"] = true,
["guideStarterAssist"] = true,
["bar"] = {
["suppressTooltipsDuringActions"] = false,
["direction"] = "RIGHT",
["castTimer"] = {
["enabled"] = true,
["horizontalSide"] = "ABOVE",
["verticalSide"] = "RIGHT",
["verticalDirection"] = "BOTTOM_TO_TOP",
["horizontalDirection"] = "LEFT_TO_RIGHT",
["colorMode"] = "THEME",
["circleDirection"] = "CLOCKWISE",
},
["showAllFlyoutChoices"] = false,
["tooltips"] = true,
["autoLootPreferenceEstablished"] = true,
["locked"] = false,
["authoredHudAnimations"] = true,
["visibilityMode"] = "AUTO_COLLAPSE",
["doubleRightCast"] = true,
["forceShown"] = false,
["oneButtonInteractAssist"] = true,
["hiddenButtons"] = {
},
["oneButtonFishing"] = true,
["point"] = {
["y"] = 28,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["scale"] = 1,
["horizontalDirection"] = "RIGHT",
["lootFloaters"] = true,
["selectedCampfireAction"] = "AUTO",
["spacing"] = 2,
["mode"] = "CIRCLE",
["expanded"] = true,
["oneButtonHudClick"] = true,
["pauseClickToMoveFishing"] = false,
["effectiveReadoutSize"] = 1,
["contextualFishingKeyboardKey"] = "F",
["hudButtonAnimations"] = true,
["autoLootWhileFishing"] = true,
["oneButtonRangeBell"] = true,
["verticalDirection"] = "DOWN",
["flyouts"] = {
["consume"] = "DOWN",
["lure"] = "DOWN",
["cook"] = "DOWN",
["fire"] = "DOWN",
["gear"] = "DOWN",
["sessions"] = "DOWN",
},
["oneButtonRangeWarning"] = true,
["contextualFishingKeyBeforeSplit172d4"] = "F",
["effectiveReadoutColor"] = "GREEN",
},
},
["classicThemeRetired150Applied"] = true,
["settingsCharacterSpecific"] = true,
["activeSettingsCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["barCharacterSpecific"] = true,
["characterTackleProfiles"] = {
},
}
