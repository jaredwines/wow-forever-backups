
HandyNotes_TravelerDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["global"] = {
["setupDone"] = true,
},
["profiles"] = {
["Default"] = {
},
},
}
