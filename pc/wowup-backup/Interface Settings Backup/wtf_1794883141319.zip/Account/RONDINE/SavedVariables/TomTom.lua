
TomTomDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["arrow"] = {
["arrival"] = 9,
["lock"] = true,
["theme"] = "classic",
["scale"] = 0.9500000476837158,
["alpha"] = 0.9500000476837158,
["position"] = {
"BOTTOM",
nil,
"BOTTOM",
2.411833047866821,
179.9570922851563,
},
["stickycorpse"] = true,
},
["worldmap"] = {
["create_modifier"] = "C",
},
["paste"] = {
["button"] = {
["showInCompartment"] = true,
},
["autoclose"] = true,
},
["block"] = {
["enable"] = false,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-75.83352661132812,
-291.6669006347656,
},
},
},
},
}
TomTomWaypointsM = {
["global"] = {
["pinFlagsLive"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
