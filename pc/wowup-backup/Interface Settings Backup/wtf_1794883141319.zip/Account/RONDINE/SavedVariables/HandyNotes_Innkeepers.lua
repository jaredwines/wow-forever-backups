
HandyNotes_InnkeepersDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["global"] = {
["setupDone"] = true,
},
["profiles"] = {
["Default"] = {
},
},
}
