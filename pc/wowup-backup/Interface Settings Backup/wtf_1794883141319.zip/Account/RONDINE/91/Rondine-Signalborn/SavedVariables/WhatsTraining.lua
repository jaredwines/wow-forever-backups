
WT_LearnedPetAbilities = {
[14916] = true,
[16828] = true,
[4188] = true,
[14917] = true,
[24549] = true,
[23992] = true,
[4189] = true,
[2649] = true,
[24446] = true,
[24493] = true,
[17255] = true,
[17256] = true,
[1264494] = true,
[4187] = true,
[24550] = true,
[24492] = true,
[24545] = true,
[24488] = true,
}
WT_NeedsToOpenBeastTraining = false
WT_IgnoredSpells = {
}
WT_PriceFaction = "auto"
WT_HideWeaponSkillSwitcher = false
WT_Crafting = {
["selectedProfessions"] = {
[165] = true,
[356] = true,
[393] = true,
[185] = true,
[129] = true,
},
["expandedProfessions"] = {
{
[165] = true,
[185] = true,
[129] = true,
},
{
},
{
[165] = true,
[185] = true,
[129] = true,
},
{
[165] = true,
[185] = false,
[393] = false,
[129] = true,
},
{
},
},
["settings"] = {
["showMerchantsFavorRecipes"] = false,
["showOtherFactionRecipes"] = false,
["showReputationRecipes"] = false,
},
["selectedSources"] = {
["world_object"] = false,
["trainer"] = true,
["drop"] = false,
["vendor"] = true,
["quest"] = true,
["crafted"] = false,
},
}
