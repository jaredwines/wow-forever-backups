
OpenMapCharDB = {
["worldmap"] = {
["flightsKnown"] = {
["Sun Rock Retreat, Stonetalon Mountains"] = true,
["Booty Bay, Stranglethorn"] = true,
["Tarren Mill, Hillsbrad"] = true,
["Hammerfall, Arathi"] = true,
["Undercity, Tirisfal"] = true,
["Ratchet, The Barrens"] = true,
["Orgrimmar, Durotar"] = true,
["Grom'gol, Stranglethorn"] = true,
["Camp Taurajo, The Barrens"] = true,
["Crossroads, The Barrens"] = true,
["Thunder Bluff, Mulgore"] = true,
["Brackenwall Village, Dustwallow Marsh"] = true,
["The Sepulcher, Silverpine Forest"] = true,
},
["cvars"] = {
},
["flightsKnownV"] = 2,
},
}
