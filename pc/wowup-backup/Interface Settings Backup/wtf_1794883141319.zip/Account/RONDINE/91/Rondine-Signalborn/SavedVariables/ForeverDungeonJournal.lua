
ForeverDungeonJournalCharacterDB = {
["favouriteItems"] = {
},
["trackedDungeons"] = {
},
["trackerSlots"] = {
},
["arrowChains"] = {
},
["hearthSpot"] = {
["y"] = 0.6845757365226746,
["mapID"] = 1454,
["name"] = "Orgrimmar",
["x"] = 0.5419030785560608,
},
["journalMode"] = "gamer",
["runTracker"] = {
},
["rpgKills"] = {
},
["flightPointsVersion"] = 2,
["hiddenDungeons"] = {
},
["flightPoints"] = {
["sun rock retreat, stonetalon mountains"] = true,
["grom'gol, stranglethorn"] = true,
["camp taurajo, the barrens"] = true,
["brackenwall village, dustwallow marsh"] = true,
["booty bay, stranglethorn"] = true,
["orgrimmar, durotar"] = true,
["thunder bluff, mulgore"] = true,
["hammerfall, arathi"] = true,
["ratchet, the barrens"] = true,
["the sepulcher, silverpine forest"] = true,
["tarren mill, hillsbrad"] = true,
["undercity, tirisfal"] = true,
["crossroads, the barrens"] = true,
},
["runLog"] = {
["nextID"] = 2,
["runs"] = {
{
["deathTimes"] = {
1794532313,
},
["deaths"] = 1,
["lastSeen"] = 1794532320,
["endedAt"] = 1794532320,
["otherXP"] = 0,
["needs"] = {
},
["closed"] = true,
["dungeon"] = "Ragefire Chasm",
["kills"] = {
},
["map"] = 389,
["exits"] = {
{
["why"] = "released",
["t"] = 1794532320,
},
},
["instanceName"] = "Ragefire Chasm",
["seenN"] = 0,
["id"] = 1,
["created"] = 1794532313,
},
},
},
["rpgQuests"] = {
[5728] = true,
[959] = true,
[914] = true,
[1221] = true,
[1491] = true,
[962] = true,
},
}
