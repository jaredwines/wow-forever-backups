
QuestieAutomaticArrowDB = {
["showObjectiveProgress"] = true,
["overrideManual"] = false,
["debug"] = false,
["panelPoint"] = {
"CENTER",
"CENTER",
0,
-160,
},
["prioritizeTurnins"] = true,
["excludeGroupContent"] = true,
["excludeScenarioQuests"] = true,
["onlyTrackedQuests"] = true,
["showTargetName"] = true,
["throttle"] = 2,
["settingsVersion"] = 6,
["enabled"] = true,
["showQuestName"] = true,
["excludePetBattleQuests"] = true,
["preferCurrentZone"] = true,
["panelShown"] = false,
}
