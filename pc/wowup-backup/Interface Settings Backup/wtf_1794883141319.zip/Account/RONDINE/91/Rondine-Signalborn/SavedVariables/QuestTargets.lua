
QuestTargetsDB = {
["masterAppearance"] = "modern",
["minimapHidden"] = false,
["autoTargets"] = {
["locale"] = "enUS",
["entries"] = {
["821:1"] = {
["signature"] = "item:Savannah Lion Tusk",
["names"] = {
["Savannah Huntress"] = true,
},
},
},
},
["minimap"] = {
["minimapPos"] = 225,
["hide"] = false,
},
["masterText"] = "Target quest objective",
["ellesmereTrackerButtons"] = true,
["restedXPIntegration"] = false,
["muteDeadTargetSound"] = false,
["masterModernScale"] = 1,
["watchedOnly"] = false,
["masterScaleBaseline"] = 2,
["masterHidden"] = false,
["ellesmereTrackerOffset"] = 0,
["autoMark"] = true,
["focusBindingsNative"] = true,
["markerIcon"] = 8,
["hidden"] = true,
["questieTrackerOffset"] = 35,
["showTooltips"] = false,
["masterScaleY"] = 1,
["questieTrackerButtons"] = true,
["position"] = {
["y"] = 25.0001220703125,
["x"] = 1190.0029296875,
},
["transparencyMode"] = false,
["masterPosition"] = {
["y"] = -402.4996643066406,
["x"] = 91.666015625,
},
["menuScale"] = 1,
["masterScaleX"] = 1,
}
