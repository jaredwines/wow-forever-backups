
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 299.9999694824219,
["messageHistory"] = {
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"5\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"5\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"589825\" newParam=\"720897\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"720897\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"720897\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"589826\" newParam=\"720898\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"720898\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"720898\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"5\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"262176\" newParam=\"327712\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"327712\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"327712\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"5\" currentInitCounter=\"5\" mask=\"32\" buffsize=\"1334\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65543\" newParam=\"65545\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65545\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65545\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131079\" newParam=\"131081\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131081\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131081\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Lua Error: ...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:459: attempt to call a nil value\n[Interface/AddOns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua]:459: in function <...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:458>\n",
3,
},
{
"Logout abort acknowledged",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"6\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"327712\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"6\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"6\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"720897\" newParam=\"851969\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"851969\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"851969\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"720898\" newParam=\"851970\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"851970\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"851970\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"6\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"327712\" newParam=\"393248\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"393248\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"393248\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"6\" currentInitCounter=\"6\" mask=\"32\" buffsize=\"1334\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65545\" newParam=\"65547\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65547\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65547\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131081\" newParam=\"131083\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131083\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131083\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Lua Error: ...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:459: attempt to call a nil value\n[Interface/AddOns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua]:459: in function <...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:458>\n",
3,
},
{
"Logout abort acknowledged",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"7\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"393248\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"7\" pendingMask=\"0\"",
0,
},
{
"LimitedLuaResources: Reset All",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"7\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"851969\" newParam=\"983041\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"983041\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"2\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"983041\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"851970\" newParam=\"983042\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"983042\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"3\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"983042\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"6\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"11\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"7\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"393248\" newParam=\"458784\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"458784\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"1\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"458784\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"7\" currentInitCounter=\"7\" mask=\"32\" buffsize=\"1334\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65547\" newParam=\"65549\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65549\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"4\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65549\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"131083\" newParam=\"131085\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131085\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"5\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131085\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad forcing local file load type=\"7\" isReloadingUI=\"true\" loadOnDemandOnly=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Lua Error: ...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:459: attempt to call a nil value\n[Interface/AddOns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua]:459: in function <...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:458>\n",
3,
},
{
"Logout abort acknowledged",
0,
},
{
"Proficiency in item class 2 set to 0x000010c18c",
0,
},
{
"Skill 46 increased from 0 to 1",
0,
},
{
"Proficiency in item class 2 set to 0x000010c58c",
0,
},
{
"Skill 136 increased from 0 to 1",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000295bfd689e0\" serial=\"133\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000295bfd689e0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000295dca09460\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000295bff302f0\" serial=\"163\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000295bff302f0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000295bfd689e0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Proficiency in item class 2 set to 0x000010c58e",
0,
},
{
"Skill 172 increased from 0 to 1",
0,
},
{
"Proficiency in item class 2 set to 0x000010c58f",
0,
},
{
"Skill 44 increased from 0 to 1",
0,
},
{
"Proficiency in item class 2 set to 0x000011c58f",
0,
},
{
"Skill 176 increased from 0 to 1",
0,
},
{
"Proficiency in item class 2 set to 0x000011e58f",
0,
},
{
"Skill 473 increased from 0 to 1",
0,
},
{
"Sending ping results from timeout timeoutNs=\"222910792075200\" nowNs=\"222910792869800\"",
0,
},
{
"Killing connection connection=\"00000295bff302f0\" state=\"(enum)7\"",
0,
},
{
"Logout response received result=\"0\" instant=\"1\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Logout completed",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"8\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"458784\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"8\" pendingMask=\"0\"",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 3",
0,
},
{
"Ripple detail changed to 2",
0,
},
{
"Reflection mode changed to 3",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 2",
0,
},
{
"Refraction mode changed to 2",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048",
0,
},
{
"Shadow texture size changed to 2048.",
0,
},
{
"Soft shadows changed to 1.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 4",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 4",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 0",
0,
},
{
"Physics interaction level changed to 2",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 1",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects enabled",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 3",
0,
},
{
"Ripple detail changed to 2",
0,
},
{
"Reflection mode changed to 3",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 2",
0,
},
{
"Refraction mode changed to 2",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048",
0,
},
{
"Shadow texture size changed to 2048.",
0,
},
{
"Soft shadows changed to 1.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 4",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 4",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 0",
0,
},
{
"Physics interaction level changed to 2",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 1",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects enabled",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1794869247\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1794869247\" expirationTime=\"1794883647\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1794820553\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":2,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":0,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1794820553\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Sending ping results from timeout timeoutNs=\"73483797100\" nowNs=\"73494601200\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"000002341ddc00a0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000002341ddc00a0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"false\"",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"0000023520d25360\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"0000023520d25360\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"DownloadAccountData begin type=\"0\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"0\"",
0,
},
{
"DownloadAccountData pending set type=\"0\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"false\" tactEncryptionConnectedReady=\"false\" tactKeyPendingPatchesReady=\"true\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"DownloadAccountData begin type=\"0\" pendingBefore=\"true\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"0\"",
0,
},
{
"DownloadAccountData pending set type=\"0\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"true\"",
0,
},
{
"DownloadAccountData begin type=\"0\" pendingBefore=\"true\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"0\"",
0,
},
{
"DownloadAccountData pending set type=\"0\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000002341ddc00a0\" state=\"(enum)6\"",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"OnUpdateAccountData received type=\"0\" size=\"1387\" isAccountWide=\"true\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"0\" size=\"1387\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"0\" compressedSize=\"655\" decompressedSize=\"1387\"",
0,
},
{
"LoadAccountDataFromServer type=\"0\" bufSize=\"1387\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"OnUpdateAccountData completed type=\"0\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"0\" size=\"1387\" isAccountWide=\"true\"",
0,
},
{
"OnUpdateAccountData ignored because request no longer pending type=\"0\"",
0,
},
{
"OnUpdateAccountData received type=\"0\" size=\"1387\" isAccountWide=\"true\"",
0,
},
{
"OnUpdateAccountData ignored because request no longer pending type=\"0\"",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_RequestLoad type=\"12\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"140702663177944\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"12\" pending=\"false\" hasCallback=\"true\" param=\"140702663177944\"",
0,
},
{
"AccountData_RequestLoad type=\"13\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"13\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"14\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"14\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"8\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"140702663187984\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"8\" pending=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"AccountData_RequestLoad type=\"9\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"140702663187984\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"9\" pending=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"AccountData_RequestLoad type=\"18\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"18\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"1\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"196609\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"196609\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"196610\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"196610\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"1\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"65568\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"65568\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"65537\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65537\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"131073\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131073\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234ed648350\" serial=\"17\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234ed648350\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"DownloadAccountData begin type=\"1\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"1\"",
0,
},
{
"DownloadAccountData pending set type=\"1\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"196609\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"196610\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65537\"",
0,
},
{
"DownloadAccountData begin type=\"5\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"5\"",
0,
},
{
"DownloadAccountData pending set type=\"5\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"DownloadAccountData begin type=\"8\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"8\"",
0,
},
{
"DownloadAccountData pending set type=\"8\" pendingAfter=\"true\"",
0,
},
{
"DownloadAccountData begin type=\"9\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"9\"",
0,
},
{
"DownloadAccountData pending set type=\"9\" pendingAfter=\"true\"",
0,
},
{
"DownloadAccountData begin type=\"11\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"11\"",
0,
},
{
"DownloadAccountData pending set type=\"11\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"12\" pendingBefore=\"false\" hasCallback=\"true\" param=\"140702663177944\"",
0,
},
{
"DownloadAccountData begin type=\"13\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"13\"",
0,
},
{
"DownloadAccountData pending set type=\"13\" pendingAfter=\"true\"",
0,
},
{
"DownloadAccountData begin type=\"14\" pendingBefore=\"false\" isCharacterlessLogin=\"false\"",
0,
},
{
"DownloadAccountData request sent type=\"14\"",
0,
},
{
"DownloadAccountData pending set type=\"14\" pendingAfter=\"true\"",
0,
},
{
"LoadAccountDataFromFile type=\"15\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"17\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"18\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004000",
0,
},
{
"Proficiency in item class 2 set to 0x0000006000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x0000006080",
0,
},
{
"Proficiency in item class 2 set to 0x0000006180",
0,
},
{
"Proficiency in item class 2 set to 0x0000006181",
0,
},
{
"Proficiency in item class 2 set to 0x0000016181",
0,
},
{
"Proficiency in item class 2 set to 0x0000016185",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000001618d",
0,
},
{
"Proficiency in item class 2 set to 0x000011618d",
0,
},
{
"Proficiency in item class 2 set to 0x000011658d",
0,
},
{
"Proficiency in item class 2 set to 0x000011658f",
0,
},
{
"Proficiency in item class 2 set to 0x000011e58f",
0,
},
{
"Proficiency in item class 2 set to 0x000011e58f",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 11/16/2026 (Mon) 16:47",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Lua Error: ...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:459: attempt to call a nil value\n[Interface/AddOns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua]:459: in function <...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:458>\n",
3,
},
{
"OnUpdateAccountData received type=\"1\" size=\"1365\" isAccountWide=\"false\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"1\" size=\"1365\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"1\" compressedSize=\"638\" decompressedSize=\"1365\"",
0,
},
{
"LoadAccountDataFromServer type=\"1\" bufSize=\"1365\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65568\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"1\" currentInitCounter=\"1\" mask=\"32\" buffsize=\"1365\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"OnUpdateAccountData completed type=\"1\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"5\" size=\"407\" isAccountWide=\"false\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"5\" size=\"407\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"5\" compressedSize=\"202\" decompressedSize=\"407\"",
0,
},
{
"LoadAccountDataFromServer type=\"5\" bufSize=\"407\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131073\"",
0,
},
{
"OnUpdateAccountData completed type=\"5\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"9\" size=\"48\" isAccountWide=\"false\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"9\" size=\"48\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"9\" compressedSize=\"47\" decompressedSize=\"48\"",
0,
},
{
"LoadAccountDataFromServer type=\"9\" bufSize=\"48\" pendingBefore=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"OnUpdateAccountData completed type=\"9\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"11\" size=\"1\" isAccountWide=\"false\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"11\" size=\"1\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"11\" compressedSize=\"9\" decompressedSize=\"1\"",
0,
},
{
"LoadAccountDataFromServer type=\"11\" bufSize=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"OnUpdateAccountData completed type=\"11\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"14\" size=\"21\" isAccountWide=\"false\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"14\" size=\"21\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"14\" compressedSize=\"16\" decompressedSize=\"21\"",
0,
},
{
"LoadAccountDataFromServer type=\"14\" bufSize=\"21\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"OnUpdateAccountData completed type=\"14\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"8\" size=\"46\" isAccountWide=\"true\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"8\" size=\"46\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"8\" compressedSize=\"46\" decompressedSize=\"46\"",
0,
},
{
"LoadAccountDataFromServer type=\"8\" bufSize=\"46\" pendingBefore=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"OnUpdateAccountData completed type=\"8\" allowServerSave=\"true\"",
0,
},
{
"OnUpdateAccountData received type=\"13\" size=\"5159\" isAccountWide=\"true\"",
0,
},
{
"OnUpdateAccountData consuming pending response type=\"13\" size=\"5159\"",
0,
},
{
"OnUpdateAccountData decompression succeeded type=\"13\" compressedSize=\"1385\" decompressedSize=\"5159\"",
0,
},
{
"LoadAccountDataFromServer type=\"13\" bufSize=\"5159\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"OnUpdateAccountData completed type=\"13\" allowServerSave=\"true\"",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234ed755040\" serial=\"43\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234ed755040\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234ed648350\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000002341df56130\" serial=\"73\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"000002341df56130\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234ed755040\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234deddf6f0\" serial=\"103\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234deddf6f0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"000002341df56130\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Skill 46 increased from 1 to 3",
0,
},
{
"Skill 46 increased from 3 to 4",
0,
},
{
"Skill 46 increased from 4 to 5",
0,
},
{
"Skill 46 increased from 5 to 6",
0,
},
{
"Skill 46 increased from 6 to 7",
0,
},
{
"Skill 95 increased from 85 to 86",
0,
},
{
"Skill 46 increased from 7 to 8",
0,
},
{
"Skill 46 increased from 8 to 9",
0,
},
{
"Skill 46 increased from 9 to 10",
0,
},
{
"Skill 46 increased from 10 to 11",
0,
},
{
"Skill 46 increased from 11 to 12",
0,
},
{
"Sending ping results from timeout timeoutNs=\"1873378868600\" nowNs=\"1873384994600\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234ee46afc0\" serial=\"133\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234ee46afc0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234deddf6f0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000236a1ca73d0\" serial=\"163\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000236a1ca73d0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234ee46afc0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Skill 46 increased from 12 to 13",
0,
},
{
"Skill 46 increased from 13 to 14",
0,
},
{
"Skill 46 increased from 14 to 15",
0,
},
{
"Skill 46 increased from 15 to 16",
0,
},
{
"Skill 46 increased from 16 to 17",
0,
},
{
"Skill 46 increased from 17 to 18",
0,
},
{
"Skill 46 increased from 18 to 19",
0,
},
{
"Skill 46 increased from 19 to 20",
0,
},
{
"Skill 46 increased from 20 to 21",
0,
},
{
"Skill 46 increased from 21 to 22",
0,
},
{
"Skill 46 increased from 22 to 23",
0,
},
{
"Skill 46 increased from 23 to 25",
0,
},
{
"Skill 46 increased from 25 to 26",
0,
},
{
"Skill 46 increased from 26 to 27",
0,
},
{
"Skill 46 increased from 27 to 28",
0,
},
{
"Skill 46 increased from 28 to 29",
0,
},
{
"Skill 43 increased from 84 to 85",
0,
},
{
"Skill 46 increased from 29 to 30",
0,
},
{
"Skill 46 increased from 30 to 31",
0,
},
{
"Skill 46 increased from 31 to 32",
0,
},
{
"Skill 46 increased from 32 to 33",
0,
},
{
"Skill 46 increased from 33 to 34",
0,
},
{
"Skill 46 increased from 34 to 35",
0,
},
{
"Skill 46 increased from 35 to 36",
0,
},
{
"Skill 46 increased from 36 to 37",
0,
},
{
"Skill 46 increased from 37 to 38",
0,
},
{
"Skill 46 increased from 38 to 39",
0,
},
{
"Skill 46 increased from 39 to 40",
0,
},
{
"Skill 46 increased from 40 to 41",
0,
},
{
"Skill 46 increased from 41 to 42",
0,
},
{
"Skill 46 increased from 42 to 43",
0,
},
{
"Skill 46 increased from 43 to 44",
0,
},
{
"Skill 46 increased from 44 to 45",
0,
},
{
"Skill 46 increased from 45 to 46",
0,
},
{
"Skill 46 increased from 46 to 47",
0,
},
{
"Skill 46 increased from 47 to 48",
0,
},
{
"Skill 46 increased from 48 to 49",
0,
},
{
"Skill 46 increased from 49 to 50",
0,
},
{
"Skill 95 increased from 86 to 87",
0,
},
{
"Skill 46 increased from 50 to 51",
0,
},
{
"Skill 46 increased from 51 to 52",
0,
},
{
"Skill 46 increased from 52 to 53",
0,
},
{
"Skill 46 increased from 53 to 54",
0,
},
{
"Skill 46 increased from 54 to 55",
0,
},
{
"Sending ping results from timeout timeoutNs=\"3673315241500\" nowNs=\"3673320789700\"",
0,
},
{
"Skill 46 increased from 55 to 56",
0,
},
{
"Skill 46 increased from 56 to 57",
0,
},
{
"Skill 46 increased from 57 to 58",
0,
},
{
"Skill 46 increased from 58 to 59",
0,
},
{
"Skill 46 increased from 59 to 60",
0,
},
{
"Skill 46 increased from 60 to 61",
0,
},
{
"Skill 46 increased from 61 to 62",
0,
},
{
"Skill 46 increased from 62 to 63",
0,
},
{
"Skill 43 increased from 85 to 86",
0,
},
{
"Skill 46 increased from 63 to 64",
0,
},
{
"Skill 46 increased from 64 to 65",
0,
},
{
"Skill 46 increased from 65 to 66",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"0000023523b3d960\" serial=\"193\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"0000023523b3d960\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000236a1ca73d0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234e8e199d0\" serial=\"223\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234e8e199d0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"0000023523b3d960\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Skill 46 increased from 66 to 67",
0,
},
{
"Skill 46 increased from 67 to 68",
0,
},
{
"Skill 46 increased from 68 to 69",
0,
},
{
"Skill 46 increased from 69 to 70",
0,
},
{
"Skill 46 increased from 70 to 71",
0,
},
{
"Skill 46 increased from 71 to 72",
0,
},
{
"Skill 95 increased from 87 to 88",
0,
},
{
"Skill 46 increased from 72 to 73",
0,
},
{
"Skill 46 increased from 73 to 74",
0,
},
{
"Skill 46 increased from 74 to 75",
0,
},
{
"Skill 46 increased from 75 to 76",
0,
},
{
"Skill 46 increased from 76 to 77",
0,
},
{
"Skill 43 increased from 86 to 87",
0,
},
{
"Skill 46 increased from 77 to 78",
0,
},
{
"Skill 46 increased from 78 to 79",
0,
},
{
"Skill 46 increased from 79 to 80",
0,
},
{
"Skill 46 increased from 80 to 81",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234e0e38540\" serial=\"253\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234e0e38540\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234e8e199d0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Skill 261 increased from 95 to 100",
0,
},
{
"Skill 50 increased from 95 to 100",
0,
},
{
"Skill 51 increased from 95 to 100",
0,
},
{
"Skill 183 increased from 95 to 100",
0,
},
{
"Skill 163 increased from 95 to 100",
0,
},
{
"Skill 2980 increased from 95 to 100",
0,
},
{
"World transfer pending...",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000002341de37e90\" serial=\"283\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"000002341de37e90\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234e0e38540\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234dc61d060\" serial=\"313\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234dc61d060\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"000002341de37e90\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234df9a2710\" serial=\"343\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234df9a2710\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234dc61d060\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 0 to 100",
0,
},
{
"Sending ping results from timeout timeoutNs=\"5473327980800\" nowNs=\"5473329787200\"",
0,
},
{
"Killing connection connection=\"00000234df9a2710\" state=\"(enum)7\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Logout completed",
0,
},
{
"GameUI::Shutdown invalidated load generation initCounter=\"2\" isClosingClient=\"false\"",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"AccountData_CancelRequestLoad type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_CancelRequestLoad type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"65568\"",
0,
},
{
"GameUI::Shutdown canceled CVar account-data loads initCounter=\"2\" pendingMask=\"0\"",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"false\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"LimitedLuaResources: Reset Timer",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"AccountData_RequestLoad type=\"12\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"140702663177944\" newParam=\"140702663177944\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"12\" pending=\"false\" hasCallback=\"true\" param=\"140702663177944\"",
0,
},
{
"AccountData_RequestLoad type=\"13\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"13\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"14\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"14\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"8\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"140702663187984\" newParam=\"140702663187984\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"8\" pending=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"AccountData_RequestLoad type=\"9\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"140702663187984\" newParam=\"140702663187984\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"9\" pending=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"AccountData_RequestLoad type=\"18\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"18\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"PreLoadGameCVars initialized pending mask pendingMask=\"32\" initCounter=\"3\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"2\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"196609\" newParam=\"458753\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"2\" pending=\"false\" hasCallback=\"true\" param=\"458753\"",
0,
},
{
"AccountData_RequestLoad type=\"3\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"196610\" newParam=\"458754\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"3\" pending=\"false\" hasCallback=\"true\" param=\"458754\"",
0,
},
{
"AccountData_RequestLoad type=\"6\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"6\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"11\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"11\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadGameCVars request dispatch initCounter=\"3\" pendingMask=\"32\" characterlessLogin=\"false\"",
0,
},
{
"AccountData_RequestLoad type=\"1\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"65568\" newParam=\"196640\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"1\" pending=\"false\" hasCallback=\"true\" param=\"196640\"",
0,
},
{
"AccountData_RequestLoad type=\"4\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"true\" newHasCallback=\"true\" existingParam=\"65537\" newParam=\"65539\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"4\" pending=\"false\" hasCallback=\"true\" param=\"65539\"",
0,
},
{
"AccountData_RequestLoad type=\"5\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"131073\" newParam=\"131075\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"5\" pending=\"false\" hasCallback=\"true\" param=\"131075\"",
0,
},
{
"AccountData_RequestLoad type=\"7\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"7\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000002341ddfdd40\" serial=\"373\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"000002341ddfdd40\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"LoadAccountDataFromFile type=\"1\" pendingBefore=\"false\" hasCallback=\"true\" param=\"196640\"",
0,
},
{
"LoadGameCVarsCallback received callbackInitCounter=\"3\" currentInitCounter=\"3\" mask=\"32\" buffsize=\"1354\" pendingMaskBefore=\"32\"",
0,
},
{
"LoadGameCVarsCallback applied response mask=\"32\" pendingMaskAfter=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone areCVarsLoaded=\"true\" pendingMask=\"0\"",
0,
},
{
"LoadGameCVarsCheckDone signaled variables loaded pendingMask=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"2\" pendingBefore=\"false\" hasCallback=\"true\" param=\"458753\"",
0,
},
{
"LoadAccountDataFromFile type=\"3\" pendingBefore=\"false\" hasCallback=\"true\" param=\"458754\"",
0,
},
{
"LoadAccountDataFromFile type=\"4\" pendingBefore=\"false\" hasCallback=\"true\" param=\"65539\"",
0,
},
{
"LoadAccountDataFromFile type=\"5\" pendingBefore=\"false\" hasCallback=\"true\" param=\"131075\"",
0,
},
{
"LoadAccountDataFromFile type=\"6\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"7\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"8\" pendingBefore=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"LoadAccountDataFromFile type=\"9\" pendingBefore=\"false\" hasCallback=\"true\" param=\"140702663187984\"",
0,
},
{
"LoadAccountDataFromFile type=\"11\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"12\" pendingBefore=\"false\" hasCallback=\"true\" param=\"140702663177944\"",
0,
},
{
"LoadAccountDataFromFile type=\"13\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"14\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"15\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"17\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"18\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004000",
0,
},
{
"Proficiency in item class 2 set to 0x0000006000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x0000006080",
0,
},
{
"Proficiency in item class 2 set to 0x0000006180",
0,
},
{
"Proficiency in item class 2 set to 0x0000006181",
0,
},
{
"Proficiency in item class 2 set to 0x0000016181",
0,
},
{
"Proficiency in item class 2 set to 0x0000016185",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000001618d",
0,
},
{
"Proficiency in item class 2 set to 0x000011618d",
0,
},
{
"Proficiency in item class 2 set to 0x000011658d",
0,
},
{
"Proficiency in item class 2 set to 0x000011658f",
0,
},
{
"Proficiency in item class 2 set to 0x000011e58f",
0,
},
{
"Proficiency in item class 2 set to 0x000011e58f",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 11/16/2026 (Mon) 18:21",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Lua Error: ...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:459: attempt to call a nil value\n[Interface/AddOns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua]:459: in function <...ns/Critline/Libs/LibDualSpec-1.0/LibDualSpec-1.0.lua:458>\n",
3,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234ed643f70\" serial=\"399\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234ed643f70\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"000002341ddfdd40\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234dc62ae00\" serial=\"429\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234dc62ae00\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234ed643f70\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234df07f5c0\" serial=\"459\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234df07f5c0\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234dc62ae00\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 1, intensity 0.612590\n",
0,
},
{
"Weather changed to 1, intensity 0.612590\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234ed659690\" serial=\"489\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234ed659690\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234df07f5c0\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Sending ping results from timeout timeoutNs=\"7273294326100\" nowNs=\"7273301651400\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234ed76c350\" serial=\"519\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234ed76c350\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234ed659690\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000235f0e42a90\" serial=\"549\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000235f0e42a90\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000234ed76c350\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Proficiency in item class 2 set to 0x000015e58f",
0,
},
{
"Skill 226 increased from 0 to 1",
0,
},
{
"Proficiency in item class 2 set to 0x000015e5cf",
0,
},
{
"Skill 229 increased from 0 to 1",
0,
},
{
"Skill 129 increased from 63 to 64",
0,
},
{
"Skill 2942 increased from 63 to 64",
0,
},
{
"Skill 129 increased from 64 to 65",
0,
},
{
"Skill 2942 increased from 64 to 65",
0,
},
{
"Skill 129 increased from 65 to 66",
0,
},
{
"Skill 2942 increased from 65 to 66",
0,
},
{
"Skill 129 increased from 66 to 67",
0,
},
{
"Skill 2942 increased from 66 to 67",
0,
},
{
"Skill 129 increased from 67 to 68",
0,
},
{
"Skill 2942 increased from 67 to 68",
0,
},
{
"Skill 129 increased from 68 to 69",
0,
},
{
"Skill 2942 increased from 68 to 69",
0,
},
{
"Skill 129 increased from 69 to 70",
0,
},
{
"Skill 2942 increased from 69 to 70",
0,
},
{
"World transfer pending...",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000236b38e4370\" serial=\"579\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000236b38e4370\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000235f0e42a90\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 11/16/2026 (Mon) 19:15",
0,
},
{
"Time set to 11/16/2026 (Mon) 19:15",
0,
},
{
"Skill 46 increased from 81 to 82",
0,
},
{
"Sending ping results from timeout timeoutNs=\"9073359299900\" nowNs=\"9073365482800\"",
0,
},
{
"Skill 46 increased from 82 to 83",
0,
},
{
"Skill 46 increased from 83 to 84",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"00000234e8e1f010\" serial=\"609\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)3\" connection=\"00000234e8e1f010\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)3\"",
0,
},
{
"Killing connection connection=\"00000236b38e4370\" state=\"(enum)6\"",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Skill 46 increased from 84 to 85",
0,
},
{
"Skill 95 increased from 88 to 89",
0,
},
{
"Skill 43 increased from 87 to 88",
0,
},
{
"Skill 356 increased from 150 to 151",
0,
},
{
"Skill 2943 increased from 150 to 151",
0,
},
{
"Skill 356 increased from 151 to 152",
0,
},
{
"Skill 2943 increased from 151 to 152",
0,
},
{
"Skill 356 increased from 152 to 153",
0,
},
{
"Skill 2943 increased from 152 to 153",
0,
},
{
"Skill 356 increased from 153 to 154",
0,
},
{
"Skill 2943 increased from 153 to 154",
0,
},
{
"Skill 356 increased from 154 to 155",
0,
},
{
"Skill 2943 increased from 154 to 155",
0,
},
{
"Sending ping results from timeout timeoutNs=\"10873371474200\" nowNs=\"10873376461000\"",
0,
},
{
"Skill 356 increased from 155 to 156",
0,
},
{
"Skill 2943 increased from 155 to 156",
0,
},
{
"Skill 356 increased from 156 to 157",
0,
},
{
"Skill 2943 increased from 156 to 157",
0,
},
{
"Skill 356 increased from 157 to 158",
0,
},
{
"Skill 2943 increased from 157 to 158",
0,
},
{
"Skill 356 increased from 158 to 159",
0,
},
{
"Skill 2943 increased from 158 to 159",
0,
},
{
"Skill 356 increased from 159 to 160",
0,
},
{
"Skill 2943 increased from 159 to 160",
0,
},
{
"Skill 393 increased from 135 to 136",
0,
},
{
"Skill 2947 increased from 135 to 136",
0,
},
{
"Sending ping results from timeout timeoutNs=\"12673415945800\" nowNs=\"12673417915600\"",
0,
},
{
"Skill 356 increased from 160 to 161",
0,
},
{
"Skill 2943 increased from 160 to 161",
0,
},
{
"Skill 356 increased from 161 to 162",
0,
},
{
"Skill 2943 increased from 161 to 162",
0,
},
{
"Skill 356 increased from 162 to 163",
0,
},
{
"Skill 2943 increased from 162 to 163",
0,
},
{
"Skill 356 increased from 163 to 164",
0,
},
{
"Skill 2943 increased from 163 to 164",
0,
},
{
"Skill 356 increased from 164 to 165",
0,
},
{
"Skill 2943 increased from 164 to 165",
0,
},
{
"Logout response received result=\"0\" instant=\"0\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Linear: 1. 0- disabled (live), 1- linear",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 3",
0,
},
{
"Ripple detail changed to 2",
0,
},
{
"Reflection mode changed to 3",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 2",
0,
},
{
"Refraction mode changed to 2",
0,
},
{
"Volume fog enabled.",
0,
},
{
"Particulate volumes enabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 4 - 4 band dynamic shadows on units and terrain, 2048",
0,
},
{
"Shadow texture size changed to 2048.",
0,
},
{
"Soft shadows changed to 1.",
0,
},
{
"Shadow cascade blending changed to 1",
0,
},
{
"Number of shadow cascades changed to 4",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading enabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 4",
0,
},
{
"Depth Based Opacity Enabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 0",
0,
},
{
"Physics interaction level changed to 2",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 1",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"GamePad input enabled.",
0,
},
{
"ChromaEffects enabled",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Overlay is disabled.  Only internal builds and public China builds have it.",
4,
},
{
"Glue login started loginType=\"(enum)1\" launcherPortal=\"us.actual.battle.net\" loginPortal=\"us.actual.battle.net:1119\"",
0,
},
{
"Glue login state reset requested",
0,
},
{
"Battle.net login session initialization requested",
0,
},
{
"Battle.net logon requested host=\"us.actual.battle.net\" port=\"1119\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net front connected connectionId=\"1\" title_id=\"5730135\" platform=\"Wn64\" locale=\"enUS\" usedToken=\"true\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net logon queue update received position=\"1\" estimatedQueueExitTime=\"1794882614\"",
0,
},
{
"Battle.net logon response received result=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net logon completed result=\"ERROR_OK (0)\" numGameAccounts=\"1\"",
0,
},
{
"Battle.net login waiting for server response",
0,
},
{
"Battle.net auth token response received code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetInfo\" responseTypeValue=\"1\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"BNetRestriction\" responseTypeValue=\"2\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service response received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net account service game info received responseType=\"GameInfo\" responseTypeValue=\"4\" code=\"ERROR_OK (0)\" name=\"RONDINE\" numGameAccounts=\"1\" numGameAccountNames=\"0\"",
0,
},
{
"Battle.net account service response received responseType=\"GameRestriction\" responseTypeValue=\"8\" code=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net complete login requested hasGameAccount=\"true\"",
0,
},
{
"Saved game account list to accountName CVar accountList=\"!RONDINE||\"",
0,
},
{
"Battle.net logon completed in glue",
0,
},
{
"Reconnect token saved creationTime=\"1794882614\" expirationTime=\"1794897014\"",
0,
},
{
"Character selection waiting for account item collection data collectionListType=\"7\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net realm list ticket requested",
0,
},
{
"Battle.net realm list ticket received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" hasTicket=\"true\"",
0,
},
{
"Battle.net login waiting for realm list",
0,
},
{
"Battle.net subregion list received code=\"ERROR_OK (0)\" realmListRequestToken=\"0\" isCurrentToken=\"true\" subRegionCount=\"1\"",
0,
},
{
"Battle.net last played character requests sent numSubRegions=\"1\" selectedSubRegion=\"91-1-89\"",
0,
},
{
"Battle.net last played character received code=\"ERROR_OK (0)\" subRegion=\"91-1-89\" lastPlayedTime=\"1794874901\" realmListRequestToken=\"0\" isCurrentToken=\"true\" contentSetIDFilter=\"-1\" numRegions=\"1\" selectedSubRegion=\"91-1-89\" numRegionsWithData=\"0\" realmPermissions=\"3\" licensesCount=\"1\" realmEntry=\"{\"wowRealmAddress\":1526857736,\"useBleepChance\":0.0,\"cfgTimezonesID\":3,\"populationState\":2,\"cfgCategoriesID\":2,\"version\":{\"versionMajor\":1,\"versionBuild\":70399,\"versionMinor\":60,\"versionRevision\":1},\"cfgRealmsID\":6934,\"gameServiceRegionId\":1,\"flags\":0,\"name\":\"CAMWOW US2 Realm 8 PvP\",\"cfgConfigsID\":2,\"cfgContentSetID\":136,\"cfgLanguagesID\":1,\"superDistrictID\":1}\"",
0,
},
{
"Battle.net realm list ready in glue",
0,
},
{
"Battle.net most recent character found; joining realm lastPlayedRegion=\"91-1-89\" realmAddress=\"1526857736\" lastActiveTime=\"1794874901\"",
0,
},
{
"Battle.net realm join requested subRegion=\"91-1-89\" realmAddress=\"91-2-8\"",
0,
},
{
"Requesting super district list",
0,
},
{
"Received super district list code=\"ERROR_OK (0)\"",
0,
},
{
"Sending ping results from timeout timeoutNs=\"13440355600100\" nowNs=\"13440371848300\"",
0,
},
{
"Battle.net realm join response received code=\"ERROR_OK (0)\" joinToken=\"1\" isLatestJoinToken=\"true\" hasJoinData=\"true\"",
0,
},
{
"Realm connection change requested",
0,
},
{
"Realm connection requested realmAddress=\"91-2-8\"",
0,
},
{
"Opening game realm connection realmAddress=\"91-2-8\" connection=\"000001cc0dbca8c0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)0\" connection=\"000001cc0dbca8c0\" protocol=\"(enum)0\" directAddressCount=\"6\" bleepProxyCount=\"0\"",
0,
},
{
"Realm connection connected realmAddress=\"91-2-8\"",
0,
},
{
"Client connected",
0,
},
{
"Authentication response received result=\"0\" hasSuccessInfo=\"true\" hasWaitInfo=\"false\"",
0,
},
{
"Realm authentication completed result=\"ERROR_OK (0)\"",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"CVar 'encounterTimelineHighlightDuration' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyHiddenMask' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineIconographyEnabled' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideForOtherRoles' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideQueuedCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineHideLongCountdowns' failed validation for its initial value.",
0,
},
{
"CVar 'encounterTimelineEnabled' failed validation for its initial value.",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"Character list request sent fastLogin=\"false\"",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Battle.net connected to realm; disconnecting from front",
0,
},
{
"Battle.net front disconnecting connectionId=\"1\"",
0,
},
{
"Battle.net authentication server disconnect started",
0,
},
{
"AccountData_RequestLoad type=\"0\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"0\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"10\" fromAuth=\"true\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"10\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"AccountData_RequestLoad type=\"16\" fromAuth=\"false\" pending=\"false\" existingHasCallback=\"false\" newHasCallback=\"true\" existingParam=\"0\" newParam=\"0\" isReloadingUI=\"false\" loadOnDemandOnly=\"false\"",
0,
},
{
"AccountData_RequestLoad updated callback state type=\"16\" pending=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"LimitedLuaResources: Global capacity for Texture changed to 400000",
0,
},
{
"LimitedLuaResources: Global capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Addon capacity for Animation changed to 5000",
0,
},
{
"LimitedLuaResources: Addon capacity for FontString changed to 5000",
0,
},
{
"LimitedLuaResources: Global capacity for AnimGroup changed to 20000",
0,
},
{
"LimitedLuaResources: Addon capacity for AnimGroup changed to 2000",
0,
},
{
"LimitedLuaResources: Addon capacity for Frame changed to 10000",
0,
},
{
"LimitedLuaResources: Global capacity for Animation changed to 50000",
0,
},
{
"LimitedLuaResources: Addon capacity for Timer changed to 500",
0,
},
{
"LimitedLuaResources: Global capacity for Font changed to 3000",
0,
},
{
"LimitedLuaResources: Global capacity for FontString changed to 50000",
0,
},
{
"LimitedLuaResources: Global capacity for Frame changed to 100000",
0,
},
{
"LimitedLuaResources: Enabled = false",
0,
},
{
"LimitedLuaResources: Addon capacity for Font changed to 300",
0,
},
{
"LimitedLuaResources: Addon capacity for Texture changed to 40000",
0,
},
{
"Connecting to sourceRealmAddress=\"91-2-8\" connection=\"000001cc0dc46940\" serial=\"14\" protocol=\"(enum)0\"",
0,
},
{
"Opening network connection connectionIndex=\"(enum)2\" connection=\"000001cc0dc46940\" protocol=\"(enum)0\" directAddressCount=\"1\" bleepProxyCount=\"0\"",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-0000034738DC] [WowAccount-0-000001A74ED1] Initialized with 15 entitlements.",
0,
},
{
"Battle.net front disconnected connectionId=\"1\" reason=\"ERROR_OK (0)\"",
0,
},
{
"Battle.net authentication server disconnected",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Glue feature system status received",
0,
},
{
"Character list response received success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" characterCount=\"2\" hadPendingResult=\"false\"",
0,
},
{
"LoadAccountDataFromFile type=\"0\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"10\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"16\" pendingBefore=\"false\" hasCallback=\"true\" param=\"0\"",
0,
},
{
"LoadAccountDataFromFile type=\"19\" pendingBefore=\"false\" hasCallback=\"false\" param=\"0\"",
0,
},
{
"Character list update waiting on startup prerequisites waitingForHotfixesReady=\"false\" tactEncryptionConnectedReady=\"false\" tactKeyPendingPatchesReady=\"false\" sectionLoadsReady=\"true\" preloadAccountSettingsDataReady=\"true\"",
0,
},
{
"Resuming communications connectionIndex=\"(enum)2\"",
0,
},
{
"Killing connection connection=\"000001cc0dbca8c0\" state=\"(enum)6\"",
0,
},
{
"Initial hotfixes applied",
0,
},
{
"Account item collection data received for character selection collectionListType=\"7\" itemCount=\"0\" wasWaiting=\"true\"",
0,
},
{
"Character selection updating character list success=\"true\" isRegionwideData=\"true\" isDeletedCharacters=\"false\" count=\"2\"",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
