
SpokenBossesCharacter = {
["found"] = {
},
["storiesRead"] = {
},
}
