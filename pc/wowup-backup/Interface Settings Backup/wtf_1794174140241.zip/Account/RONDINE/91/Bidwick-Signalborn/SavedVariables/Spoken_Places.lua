
SpokenPlacesCharacter = {
["visited"] = {
["1411"] = true,
["1411/valley of trials"] = true,
},
["greeted"] = true,
["heard"] = {
["1411/valley of trials"] = true,
},
}
SpokenZonesCharacter = nil
