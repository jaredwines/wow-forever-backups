
ForeverDungeonJournalCharacterDB = {
["hiddenDungeons"] = {
},
["favouriteItems"] = {
},
["rpgKills"] = {
},
["journalMode"] = "rpg",
}
