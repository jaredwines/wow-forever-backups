
GatherLiteConfigCharacter = nil
