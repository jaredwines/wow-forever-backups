
EllesmereUIChatScrollDB = {
["sessionLog"] = {
},
}
