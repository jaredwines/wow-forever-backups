
OpenMapCharDB = {
["worldmap"] = {
["cvars"] = {
},
},
}
