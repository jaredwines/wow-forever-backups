
betterVendorPriceSaved = {
["settings"] = {
["autoRestack"] = true,
["debug"] = false,
["holdShiftForMore"] = false,
["reportFull"] = true,
["showFullStack"] = true,
["highlightCheapest"] = true,
},
["keep"] = {
},
}
