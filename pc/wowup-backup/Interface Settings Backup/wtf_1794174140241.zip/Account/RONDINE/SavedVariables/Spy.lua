
SpyDB = {
["kosData"] = {
["CAMWOW US2 Realm 8 PvP"] = {
["Horde"] = {
["Rondine"] = {
},
},
},
},
["removeKOSData"] = {
["CAMWOW US2 Realm 8 PvP"] = {
["Horde"] = {
},
},
},
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["ForeverDebug"] = {
"2026-11-04 16:03:16",
"Forever port of Spy 1.3.8, client 1.60.1 (70790), interface 16001",
"Spy on: ? | in this zone: no (pvp type sanctuary, flagged yes, instance no)",
"Off in this zone because: sanctuary (Enable Spy in sanctuaries)",
"Enemy nameplates: yes | nameplates watched: 0 | unit scan: running",
"Nearby: 0 (active 0) | last hour: 0 | KoS: 0 | known players: 0",
"Seen: 69 unit reads, 0 enemy casts, 0 stealth alerts, 0 kills, 0 deaths counted",
"Secret restrictions: yes | target: none",
"Saved data read at login: account yes, character yes",
"Window: hidden, 0 row(s)",
"Ran: no macro and no TargetUnit since login",
"Buttons act on key press (ActionButtonUseKeyDown)",
"Blocked by the client: nothing",
"Addon restrictions active: none",
"Last error: none",
},
["profiles"] = {
["Rondine Signalborn"] = {
["MainWindowVis"] = false,
["Colors"] = {
["Bar"] = {
["Bar Text"] = {
["a"] = 1,
},
},
},
["AppendUnitNameCheck"] = true,
["AppendUnitKoSCheck"] = true,
["MinimapButton"] = {
["hide"] = false,
["angle"] = -2.463081346192286,
},
},
},
}
