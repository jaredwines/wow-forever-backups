
EllesmereUIMinimapDB = {
}
