
SpokenContributionsDB = {
["Tidied"] = true,
["Lines"] = {
{
["key"] = "q:92460:accept:251362",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nquest=92460\nevent=accept\nnpc=251362 Ailee Farheart\nkind=creature\nmodel=7478494\nsex=3\ncreature=Humanoid\ntitle=Coming of Age\ntext<<\nLook at you, bright eyed and ready for adventure! We need all the help we can get here in Thendal Village and your arrival is most welcome. I imagine you are brimming with nerves for what is to come. After all, you only get to come of age once in a lifetime.\n\nGo, seek out our village leader Rorian the Dayseeker at the entrance to the greatfather tree just west of here. He will get you started on your journey.\n>>\nsum=471510226\n",
},
{
["key"] = "q:92460:complete:251361",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nquest=92460\nevent=complete\nnpc=251361 Rorian the Dayseeker\nkind=creature\nmodel=7478487\nsex=2\ncreature=Humanoid\ntitle=Coming of Age\ntext<<\nGale's greetings, $N. I am honored to bestow your coming of age relic today as you are recognized for the potential you bring to the shen'dorei. Our people have faced great hardship and persecution in our complex history.\n\nToday you are given this relic which is one of many held by those before you. Someday when your ashes are scattered to the winds it will pass to another to continue our tradition.\n\nAs you take this relic with you know that the winds of home will be with you wherever you travel.\n>>\nsum=2115690515\n",
},
{
["key"] = "q:94414:accept:257554",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nquest=94414\nevent=accept\nnpc=257554 Halaan Hawk-Eye\nkind=creature\nmodel=7478487\nsex=2\ncreature=Humanoid\ntitle=The Anchors of Zephras\ntext<<\nGreetings, young $N. I oftentimes come here to look upon the ancient anchor pylon. Gifts from the spirits of the winds, they bind and sustain our island. Of late however, their magic has grown unstable and inconsistent.\n\nThey suffer no distress I can see. Their splendor has not changed.\n\nIf you'd like, I can lend you my gift to look upon them yourself.\n>>\nsum=1120902809\n",
},
{
["key"] = "q:94414:progress:257554",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nquest=94414\nevent=progress\nnpc=257554 Halaan Hawk-Eye\nkind=creature\nmodel=7478487\ndisplays=143583\nsex=2\ncreature=Humanoid\ntitle=The Anchors of Zephras\ntext<<\nMy gift is simple, and mundane. I cannot peer between worlds such as those with the skysight, nor can I draw upon the magic of the leylines beneath Zephras like others can. But a gift it remains and I am grateful to have it.\n\nAppreciation of what you have is the key to happiness. Yearning for what you may have, or what you have lost, only leads to despair.\n>>\nsum=1800994258\n",
},
{
["key"] = "q:92482:progress:251376",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nquest=92482\nevent=progress\nnpc=251376 Tai'ree Farsight\nkind=creature\nmodel=7478494\ndisplays=136976\nsex=3\ncreature=Humanoid\ntitle=The Way of the Hunter\ntext<<\n<Tai'ree nods at you curtly.>\n>>\nsum=1417094898\n",
},
{
["key"] = "q:93552:accept:251363",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nquest=93552\nevent=accept\nnpc=251363 Dalia the Collector\nkind=creature\nsex=3\ncreature=Humanoid\ntitle=Harvesting Windstones\ntext<<\nWindstones are a critical resource on Zephras Isle as they contain the raw, concentrated energy of the winds themselves. The wind elementals who used to live here on Zephras with us vanished a number of years ago, and since then, the magic that sustains this island is slowly fading. Not without limitations, the windstones are still a reliable energy source, and are incredibly valuable to us.\n\nYou'll find raw windstones scattered around the grove. Think you can help me harvest them?\n>>\nsum=336009209\n",
},
{
["key"] = "g:257021:1526310394:f",
["envelope"] = "!SPOKEN1 quests\naddon=SpokenQuests/3.8.0\nbuild=1.60.1/70790\nlocale=enUS\npack=enUS\npackVersion=2.5.0\nnpc=257021 Halassa Fernbreeze\nkind=creature\nmodel=7478494\ndisplays=140080\nsex=3\ncreature=Humanoid\ntext<<\nKaelsig Veldbarad, ras. Y wirsh odes barad me ko tiras ko lo ash se faergas Y gol majis nud me o mod engoth aelgestron.\n>>\nsum=1596999455\n",
},
},
}
