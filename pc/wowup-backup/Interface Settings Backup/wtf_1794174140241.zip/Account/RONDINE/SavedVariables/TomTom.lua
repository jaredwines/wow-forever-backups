
TomTomDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["arrow"] = {
["arrival"] = 9,
["lock"] = true,
["theme"] = "classic",
["scale"] = 0.9500000476837158,
["stickycorpse"] = true,
["position"] = {
"BOTTOM",
nil,
"BOTTOM",
-2.850738048553467,
164.1669464111328,
},
["alpha"] = 0.9500000476837158,
},
["block"] = {
["enable"] = false,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-75.83352661132812,
-291.6669006347656,
},
},
["paste"] = {
["button"] = {
["showInCompartment"] = true,
},
},
},
},
}
TomTomWaypointsM = {
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["global"] = {
["pinFlagsLive"] = true,
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
