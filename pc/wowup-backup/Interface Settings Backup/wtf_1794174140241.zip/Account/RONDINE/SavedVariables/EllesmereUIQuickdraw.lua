
EllesmereUIQuickdrawDB = {
}
