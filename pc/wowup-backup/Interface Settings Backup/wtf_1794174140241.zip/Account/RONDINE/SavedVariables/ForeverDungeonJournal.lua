
ForeverDungeonJournalDB = {
["questFaction"] = "Horde",
["portraitCacheVersion"] = 2,
["lastMode"] = "bosses",
["minimap"] = {
["minimapPos"] = 225,
["hide"] = false,
},
["displayIDs"] = {
},
["learnedItemIDs"] = {
},
["portraitTexturesByNpcID"] = {
},
["questText"] = {
["enUS"] = {
[92516] = {
["o"] = "Slay 8 Hippogryph Youths, 6 Hippogryph Protectors and a Hippogryph Matriarch in the Shen'dar Highlands.",
["d"] = "A flock of Hippogryph have recently established nesting grounds southeast of Shen'dar Village and they've been wreaking havoc on travelers on the road. I need someone to head down there and thin them out for us.",
},
[92461] = {
["o"] = "Slay 8 Vuldren Juveniles in Thendal Grove.",
["d"] = "We live in times of great uncertainty for our people. We face unprecedented challenges that may require bold solutions, but we also must contend with the ordinary and mundane here in Thendal Grove. Take, for example, the recent unsustainable rise in the vuldren population.\r\n\r\nThe vuldren are a vital part of our ecosystem. However, imbalances must be corrected to maintain the delicate harmony that all creatures in Thendal Grove share.\r\n\r\nHead east and cull some of the vuldren there.",
},
[92528] = {
["o"] = "Look around Falaath Village to learn about the cult's intentions in the Shen'dar Highlands.",
["d"] = "The faithful of Al'Akir grow ever stronger with each eager new recruit like yourself. As you can see, our strength gives form to the storm itself!\r\n\r\nNormally I'd send you straight to Skypriest Aanders for assessment, but he is occupied at present receiving a guest at the inn on the north side of town. Please avoid that place for now. An unshaven recruit like yourself in the presence of such a guest would be inappropriate.\r\n\r\nFor now, just don't get in anyone's way.",
},
[93036] = {
["o"] = "Speak with Sania Silverstream in Shen'dar Village.",
["d"] = "You may or may not be aware of this, but Sania Silverstream over there is a \"missionary\" for the Al'Aketh. They like to play at being a normal religious order and send non-threatening emissaries around to recruit. We've tolerated Sania so far to avoid direct conflict with the cult, but it's obvious the illusion of peace won't last much longer.\r\n\r\nYou are new here and unknown to most, so I'd like to see if you can use Sania to get close to the cult and find out what their plans are for the village.",
},
[93165] = {
["o"] = "Collect 5 Al'Aketh Cultist's Ears from the Al'Aketh cultists in Shadowgale Forest, the Shrine of Akir, or Gustberry Lowlands.",
["d"] = "The Al'Aketh have visited great tragedy upon our enclave, and blood must be repaid with blood.\r\n\r\nI have an offer for you, stranger. Should you find conflict with these accursed cultists, bring me the ears of those you kill. I will reward you for each that you return with in both coin and, in time, access to the Nightclaw's secrets should you prove yourself to be a true friend.",
},
[93926] = {
["o"] = "Find Peacekeeper Vaaniel at the western watchtower.",
["d"] = "Whatever reason the cult has for attacking the tower, it's not worth losing our people over.\r\n\r\nI'd like for you to head to the southwest and check in on that watchtower for us. Find the peacekeepers there and tell them to head back to the village. Holding that tower is not worth the lives it would cost and I'd rather concentrate the defenders we do have here to protect our citizens.\r\n\r\nPeacekeeper Vaaniel is in charge; let him know to head back here as quickly as possible. Hurry!",
},
[93552] = {
["o"] = "Collect 15 Windstone Clusters from Raw Windstones in Thendal Grove.",
["d"] = "Windstones are a critical resource on Zephras Isle as they contain the raw, concentrated energy of the winds themselves. The wind elementals who used to live here on Zephras with us vanished a number of years ago, and since then, the magic that sustains this island is slowly fading. Not without limitations, the windstones are still a reliable energy source, and are incredibly valuable to us.\r\n\r\nYou'll find raw windstones scattered around the grove. Think you can help me harvest them?",
},
[94050] = {
["o"] = "Speak to Quel'dora Quickgale in Valanaar.",
["d"] = "You now have the power to tame a pet, but you must also gain the skills to train it. For this, there is none better than my sister, Quel'dora. She will give you the ability to train your new pet. \r\n\r\nGo with the winds, young hunter.",
},
[93319] = {
["o"] = "Collect 10 Pilfered Windstones from the Highlands Bandits in the Shen'dar Highlands.",
["d"] = "We are relying on windstones more and more for day-to-day living here on Zephras so we try and maintain a cache of them in reserve for emergencies. Lately I've noticed some go missing from our stores.\r\n\r\nWe've found windstones on bandits we've captured recently, and I suspect they are behind our shortages.\r\n\r\nIf you find yourself near the bandit cave to the north, mind knocking a few heads together and reclaiming some of our pilfered windstones for me?",
},
[92682] = {
["o"] = "Gather 10 Ripe Stormapples and slay 5 Hungry Bandits at the Windfield Orchard.",
["d"] = "Oh, so you've got more courage than sense, then? Fine, I won't argue.\r\n\r\nFerauu and his goons aren't due to pick up their take of the harvest just yet, so I'm going to put you to work for your meals until they arrive.\r\n\r\nHead outside and gather today's batch of stormapples for me. Oh, and the bandits lurking around the stormapple trees... They think they are sneaky. They aren't. Kill them for me. \r\n\r\nLet's see what you've got in a fight.",
},
[94485] = {
["o"] = "Collect 8 Lady's Tear Moss.",
["d"] = "If we are to save my fellows in the Nightclaw Den, I am going to need some ingredients for a poultice. The first and most important is a spindly moss called Lady's Tear. It typically grows on the base of the trees here in Shadowgale.\r\n\r\nThis moss secretes a sticky substance that acts as an antiseptic and is perfect for binding open wounds. I have gathered what little I can reach but I know there is more in this forest.\r\n\r\nGo and be swift. We are going to need a lot if the injured I left behind still live.",
},
[94013] = {
["o"] = "Use the Taming Rod to tame a Vuldren Alpha in the Gustberry Lowlands. Practice your skills, then return the Taming Rod to Quel'ana Quickgale in Valanaar.",
["d"] = "You've returned triumphant from taming two beasts. It's time now for your last trial. The winds of Zephras whisper of greater challenges ahead. \r\n\r\nTake this Taming Rod and journey to the Gustberry Lowlands. There, tame a Vuldren Alpha and prove your mastery. \r\n\r\nComplete this lesson and you'll be ready to learn the deeper ways of the hunter.",
},
[93737] = {
["o"] = "Speak with Riaani Nightwind and listen to what he has to say.",
["d"] = "Oh, hello. Ayessa sent you to assist me? Very well then. \r\n\r\nNot sure what an obvious novice like yourself can do, but if you give me a moment to pull my head out of this construct's innards I might have a few ideas of things you can do to help.",
},
[92698] = {
["o"] = "Speak with Aamelia Windfield about the Malfunctioning Cyclone Construct.",
["d"] = "<You lean in close to try and hear the words coming from beneath the giant construct's armor plates.>\r\n\r\n...Function error...\r\n\r\n...Question...\r\n\r\n...What is....\r\n\r\n...Function...\r\n\r\n<These fragmented words and phrases seem to just repeat. Maybe someone nearby knows more about this construct?>",
},
[93951] = {
["o"] = "Collect 8 Hippogryph Down feathers in the Shen'dar Highlands.",
["d"] = "The hippogryphs that have taken up residence southwest of the village can be a nuisance, but they also present a rather unique opportunity to obtain their feathers. Many skyborne love to adorn their hair with vibrant plumes and the down feathers of a hippogryph are exceptionally vibrant and, more importantly, silky soft.\r\n\r\nIf you are heading that way, try and gather as many of the fallen feathers as you can from around their nesting grounds. Do be careful, as wild hippogryph are not tolerant of guests.",
},
[92517] = {
["o"] = "Kill 10 Highlands Bandits and their leader, \"Badwind\" Bennic in the Shen'dar Highlands.",
["d"] = "There's a cave not far to the north, hidden behind a waterfall. It's well known to me that there's a group of bandits that are operating out of that cave. They were a problem for us before the cult arrived, but now they are a real terror. I can't spare the people to go and clear them out, unfortunately.\r\n\r\nI need you to go there and take care of them for me. Kill as many as you can, and if possible, take out their leader, the one they call \"Badwind\" Bennic. That cave is dangerous, so be careful.",
},
[94411] = {
["o"] = "Slay 6 High Order Apprentices in Shen'dar Highlands.",
["d"] = "Be warned, members of the High Order have been seen in the vicinity of the standing stones north of the village. We have warned them time and again to not meddle at our sacred sites, but they are growing more bold in pushing us. Prove your resolve to us by going to the standing stones and dispersing them.\r\n\r\nI am loathe to condone outright bloodshed, but do what you must to drive them off. Return to me when it's done.",
},
[92462] = {
["o"] = "Slay 8 Pesky Cirrusflies in Thendal Grove.",
["d"] = "One of our rangers recently reported an infestation of cirrusflies here in Thendal Grove. \r\n\r\nCirrusflies can be dangerous if the swarm is allowed to grow too large, so please head to the eastern end of the Grove and exterminate as many as you can.",
},
[92529] = {
["o"] = "Report to Missionary Jasaan near the entrance to Falaath Village.\r\n\r\nIf you lose your Mark of Akir, speak with Sania Silverstream in Shen'dar Village to regain the effect.",
["d"] = "It gladdens my heart that you wish to serve Al'Akir. Our current trials as a people stem from our own complacency. We grew prideful and took the bounty of the winds for granted. The stagnation that followed is the reason the spirits of the wind abandoned us.\r\n\r\nOnly through acts of contrition may we feel the wind's caress once more. If you seek the fellowship of like-minded shen'dorei, go to Falaath Village and find Missionary Jasaan there. I will mark you so that the faithful will know you as a recruit.",
},
[94486] = {
["o"] = "Collect 20 feathers from the Shadowgale Shrieklings in Shadowgale Forest.",
["d"] = "The other ingredient I need for the poultice is feathers from the Shadowgale shrieklings that roam this forest. In their juvenile form, the shrieklings have insulative feathers which would be ideal to put over the moss. These feathers will prevent the antiseptic sap from drying out and will provide at least some protection against the elements.\r\n\r\nBe warned, the shrieklings are normally docile but they have been incredibly hostile of late. Their large talons can easily disembowel you if you aren't careful.",
},
[92474] = {
["o"] = "Jump from the top of the watchtower in Thendal Grove and use your Walk on Air ability to slow your fall.",
["d"] = "Well hello there, N! Want to play a game?\r\n\r\nAll you've got to do is step up on that ledge... then jump! Use your innate ability to walk on the air to slow your fall and see how far forward you can float.\r\n\r\nThe rules are made up and the points don't matter, but you get bonus points if you can land right in front of Rorian the Dayseeker and startle him! He won't like it but I'll certainly get a good laugh if you can get him all worked up! Hah!",
},
[93927] = {
["o"] = "Collect the note you found near the dead peacekeeper and read it to determine your next steps.",
["d"] = "<As you inspect the body of the dead peacekeeper, a bloody note falls free of his hands. Picking it up and reading it may give you a clue as to how to proceed from here.>",
},
[92482] = {
["o"] = "Read the Scribbled Note and then speak with Tai'ree Farsight in Thendal Grove.",
["d"] = "While you were away dealing with our vuldren problem, our resident hunter trainer--Tai'ree Farsight--left this note for you. You can find her just over yonder near the center of the village. Read the note then seek her out.",
},
[97967] = {
["o"] = "Speak with Fenn Fairweather in Shen'dar Village to learn to craft a camping item for your profession once you have shown proficiency in your skill.",
["d"] = "You might not think so, but your skill as a fisherman can actually come in handy at camp.\r\n\r\nI reckon I know someone that can teach you how to craft a Fish Bowl for your camp. You can use this fixture to help provide a bit of joy to yourself and your fellow adventurers. A happy adventurer is a strong adventurer and I'm sure your combat capabilities will reflect that.",
},
[92553] = {
["o"] = "Collect 3 Small Eggs and 8 Strider Meat from creatures found throughout the Shen'dar Highlands.",
["d"] = "Up for a bit of work? I could use a bit of muscle from a strong adventuring-type such as yourself. With how dangerous things are getting around here, no one's had much time to hunt or forage of late, and I need someone to get out there and source me fresh eggs and strider meat to keep this village fed.\r\n\r\nI'd be happy to teach you one of my famous recipes if you can bring me what I need. What do you say?",
},
[92683] = {
["o"] = "Gather 5 Flutterfly Dust from the Flutterflies around the Gustberry Lowlands.",
["d"] = "I'm sure you've noticed the giant flutterflies out in the outer fields near the orchard? They are pleasant to look at, but they also have other benefits; namely their wing dust. It can be a mess, but if you can gather it up in large amounts, it has useful household applications.\r\n\r\nTake this Flutterfly Swatter and give the big bugs a good swat for me. They'll usually just get scared and flee, but sometimes they'll take some offense. Either way, they'll give their rumps a shake and drop a pile of dust.",
},
[93317] = {
["o"] = "Collect 6 pieces of Windsong Crawler Meat.",
["d"] = "Are you familiar with Windsong Crawlers? You see, these crabs are native only to Windsong Lake here on Zephras, and they are only able to be harvested a few weeks of the year.\r\n\r\nWith all of the cult activity of late, I've not been able to get out to the lake to harvest them, and our window is rapidly closing. I'd be appreciative if you could go and gather some for me. They can generally be found along the shorelines around the lake and in rivers.\r\n\r\nDo be careful though, they are meaner than they look!",
},
[94896] = {
["o"] = "Collect 8 Abandoned Belongings from the ruins of Ban'aethal.",
["d"] = "You look like a capable adventurer. Do you happen to be headed towards Shadowgale Forest? Ban'aethal lies deep in the forest; that's where we're all from.\r\n\r\n<Ealaane gestures to the other refugees.>\r\n\r\nWe've recently had to evacuate Ban'aethal, as it began to fall into the sky. It was sudden and in the middle of the night. If you are headed that way, would you please look for any belongings left behind? The forest and village are far too dangerous for us to return to now.",
},
[94978] = {
["o"] = "Use the Taming Rod to tame a Windsong Crawler found near bodies of water. \r\nPractice your skills, then return the Taming Rod to Quel'ana Quickgale in Valanaar.",
["d"] = "Every hunter begins by learning the bond between beast and master. This is your first challenge. In time, you'll tame creatures from every corner of the world, but for now, start with our rivers and lakes on Zephras. \r\n\r\nTake this Taming Rod and seek out a Windsong Crawler.\r\n\r\nShow that you can earn its trust, and begin your path toward true mastery.",
},
[96101] = {
["o"] = "Sit near Raan's Basic Campfire and wait until you receive the Boosted Rest buff.",
["d"] = "Greetings, hunter. I can see you've got the look of an adventurer about you. This is good. The world needs more of us restless souls, seeking fortune and glory.\r\n\r\nYou'll need to learn to thrive in the wilds to be successful in this line of work. Not sure how your outdoor skills are but I can probably teach you a thing or two, if you'd be apt to learn.\r\n\r\nHave a seat near the fire and get comfortable. I'll walk you through it.",
},
[97969] = {
["o"] = "Speak with Indari Sunseam in Shen'dar Village to learn to craft a camping item for your profession once you have shown proficiency in your skill.",
["d"] = "You've become a leatherworker. Good for you, hunter. I reckon I know someone that can teach you how to make yourself a tent that will keep you cool on hot days, and dry on rainy days.\r\n\r\nWith a good tent over your head, you'll ensure that you get all the rest you need to stay sharp on your travels.",
},
[92551] = {
["o"] = "Collect 10 packs of Stolen Shen'dar Supplies from Falaath Village in the Shen'dar Highlands.",
["d"] = "I overheard you might be going to Falaath Village? While you are there, please keep an eye out for our stolen supply caches.\r\n\r\nThe Al'Aketh have been raiding our supply caravans carrying various goods such as food and windstones to and from the lowlands for months. They've been blaming the bandits, of course, but we all know that it all ends up in the same place. If there's any of that stuff left in Falaath, it would be a huge help if you could recover it.",
},
[94979] = {
["o"] = "Use the Taming Rod to tame an Ornery Galestrider in the Gustberry Lowlands. \r\nPractice your skills, then return the Taming Rod to Quel'ana Quickgale in Valanaar.",
["d"] = "You've proven you can tame the river's crawler. Now it's time to test your skill on open ground. The plains of Zephras echo with the cries of the galestrider, a proud, winged hunter that runs like the wind.\r\n\r\nTake this Taming Rod and seek one out. Travel to the lowlands and earn its trust.\r\n\r\nShow you're ready for the trials yet to come.",
},
[92463] = {
["o"] = "Destroy the Cirrusfly Queen in Thendal Grove.",
["d"] = "If the forest is as thick with these insects as it sounds, simply killing the workers won't be enough.\r\n\r\nGo deeper into the forest and find the queen. She'll be close to the hive and surrounded by bigger and more aggressive soldiers, so be careful.\r\n\r\nPut her down and return here when it's done. That'll be one less problem to think about around here.",
},
[93160] = {
["o"] = "Gather 8 Shadowgale Acorns in Shadowgale Forest.",
["d"] = "I do appreciate you stopping by to talk with me! I-If you do want to help out, I could use a bit of help gathering up acorns from the forest floor. I've gathered most of the ones close by but there sure are a lot of raptor-bird things in the forest. It's dangerous out there and I'd rather not become a giant bird's lunch!\r\n\r\nSo if you want, you could maybe gather them for me? I'll make us something tasty if you do!",
},
[94487] = {
["o"] = "Collect 10 Bloodied Heirlooms from Al'Aketh Footsoldiers and Al'Aketh Stormchasers in the Shadowgale Forest.",
["d"] = "The Al'Aketh Cultists ambushed us with no warning, though their motives remain a mystery to me. I knew these cultists had clouds between their ears, but I never imagined they would upset the delicate balance here on Zephras with such brutality. Go, slay as many as you can and take their heirlooms if they wear any.\r\n\r\n<Elegael spits.>\r\n\r\nThese storm-cursed cultists don't deserve to be called shen'dorei. The beasts of the forest can have their bodies. Their ashes don't deserve the winds.",
},
[93735] = {
["o"] = "Find Riaani Nightwind on the west side of Valanaar.",
["d"] = "Historically, the Windshapers have seen to the tending of the magical instruments and devices that were gifted to us by the spirits of the wind. This includes the myriad of magical constructs around the island. Since the spirits left us, only a scant few of these are still functional.\r\n\r\nOne of the few remaining working constructs in Valanaar has become damaged. One of our artisans was dispatched to help, but he may be in need of aid. Travel to the west end of the city and offer any assistance you can.",
},
[93172] = {
["o"] = "Destroy 10 Wind Hollows in Shadowgale Forest.",
["d"] = "Most of the elves on this island seem to think that these woods are haunted, and they aren't wrong.\r\n\r\nAt the old ruins to the northeast, a strange type of ghost-like spirits gather. Some nights, you can almost hear them \"singing\". It's not like any song I've heard before, but it's definitely a song and it's... just so sad.\r\n\r\nI'm not sure why, but I think something terrible happened there at some point, and the spirits are trapped there somehow. If you are feeling brave, maybe you can help set them free?",
},
[92679] = {
["o"] = "Listen to what Alvarion Windfield has to say and find Aamelia Windfield at the Windfield Orchard.",
["d"] = "H--Hello, stranger. You have the look of a capable adventurer about you. I...\r\n\r\n<The Skyborne man winces, clearly suffering terrible pain>\r\n\r\n...I was wondering if you were seeking employment? I came here to Valanaar to recruit fighters to help save my farm. If you are interested, please go find my wife Aamelia Windfield at our orchard to the west of Valanaar, in the lowlands.",
},
[92550] = {
["o"] = "Travel to the ruins of Falaath Village and slay 6 Al'Aketh Stormcallers, 4 Living Lightning and take the head of Commander Cyclas.",
["d"] = "Our best defense here might just be a strong offense. The advantage we now have is that we expect an attack is coming. What they won't expect is for us to hit them first.\r\n\r\nI've already asked a lot of you, but please head back over to Falaath Village. Kill as many cultists as you can and if you can get close enough, kill the commander and bring me his head. I'll stay here and organize the citizens and our few peacekeepers to prepare a defense... just in case you don't return.",
},
[98512] = {
["o"] = "Kill 10 Al'Aketh Assassins in the Shen'dar Highlands.",
["d"] = "You there, stranger. Get low and keep quiet. We are not alone here.\r\n\r\nI was on patrol near the border and noticed that there are a number of Al'Aketh skulking around the house just up the hill there to the north. I don't know what they are doing here, but it can't be good.\r\n\r\nIf you want to make yourself useful, get in there and take them out. I'll wait here and watch your back.",
},
[92684] = {
["o"] = "Gather 7 Lowlands Galestrider Tenderloins from the Ornery Galestriders found throughout the Gustberry Lowlands.",
["d"] = "As if the harvest wasn't light enough this year already, the galestriders in the area have been getting into the orchard and stealing my stormapples. Think you can head out to the fields and cull them for me?\r\n\r\nTake care though stranger, these lowlands galestriders are bigger and angrier than the highlands variety. Watch yourself. A well-timed kick is all it takes to put you down for good if you aren't paying attention.\r\n\r\nBring me some of their meat and I can make us a hot meal with it as well.",
},
[93318] = {
["o"] = "Kill Vulgara the Insatiable in the Shen'dar Highlands and bring her head to Danarii Bellowveil.",
["d"] = "By order of Constable Aonda of the Peacekeepers, a bounty is hereby placed upon the scourge of the highlands, Vulgara the Insatiable. Last spotted on a hilltop rise just southwest of Shen'dar Village, the winged vuldren terror is highly dangerous and should be approached with caution.\r\n\r\nDeliver the beast's head to Danarii Bellowveil to receive your reward.",
},
[94897] = {
["o"] = "Find Resaan in the Ruins of Ban'aethal.",
["d"] = "If you are traveling to Ban'aethal, I have a selfish request. My love, Resaan... I believe is no longer a part of this world. He had tried to go back to get supplies even though I begged him to stay. It has been over a week already and I fear the worst.\r\n\r\nPlease, if you find him, bring him home. If he has perished then I beg you to please bring me his heirloom.",
},
[92579] = {
["o"] = "Deliver Aonda's Written Report to Valennia Stormfist in Valanaar.",
["d"] = "For now it seems the pylon and the village are safe, so I'd like you to deliver this report to Valennia Stormfist in Valanaar, at the southeastern edge of the island. Valennia is the leader of the peacekeepers on the island and she needs to know what happened here.\r\n\r\nThe cult is expanding rapidly and the peacekeepers have avoided direct conflict until now, but those days are over. Valanaar will need to be ready for a fight.\r\n\r\nAt any rate, thank you. You'll always have friends in Shen'dar, N.",
},
[92700] = {
["o"] = "Find Ayessa Dawnsinger in Valanaar.",
["d"] = "Now that you've arrived in Valanaar, you'll likely want to check in with the other members of the Windshapers here. The current Grand Skyseer and her people operate out of the lodge near the center of Valanaar.\r\n\r\nYou should also be aware, the Windshapers and High Order don't get along very well in these parts. Be careful and give the High Order a good, wide berth. We've got enough to worry about with the cult, I won't tolerate faction violence in the streets of Valanaar.",
},
[92515] = {
["o"] = "Collect 10 Prideclaw Pelts from the Prideclaws in Shen'dar Highlands.",
["d"] = "As if bandits and mad cultists weren't enough, the hills are thick with prideclaws as well right now. They are starting to encroach on the village borders and growing bolder by the day. It's only a matter of time before someone's pet or child is taken. It would be a mercy for us to cull their numbers now rather than after some tragedy occurs.\r\n\r\nBring me a dozen or so of their pelts. I can turn them into all sorts of goods that will be of aid to the village.",
},
[92708] = {
["o"] = "Listen to what Ayessa Dawnsinger has to say.",
["d"] = "The Windshapers have been hard at work trying to respond to the current crisis on Zephras Isle. We have made several surprising discoveries in our search for the missing wind spirits, and we are developing a plan of action that could help us gain the means to save the island.\r\n\r\nWe'll need strong young adventurers like yourself for this to work however. Please, if you have a moment, let us speak on this further.",
},
[92460] = {
["o"] = "Speak with Rorian the Dayseeker in Thendal Grove.",
["d"] = "Look at you, bright eyed and ready for adventure! We need all the help we can get here in Thendal Village and your arrival is most welcome. I imagine you are brimming with nerves for what is to come. After all, you only get to come of age once in a lifetime.\r\n\r\nGo, seek out our village leader Rorian the Dayseeker at the entrance to the greatfather tree just west of here. He will get you started on your journey.",
},
[92464] = {
["o"] = "Speak to Yala Windwatcher in Thendal Grove.",
["d"] = "Ever since our elemental benefactors left us, it seems that we are simply moving from one unrest to another. The problem we face now is that the manifestations of the winds near the standing stones to the northeast are agitated.\r\n\r\nNot truly self-aware like the sentient wind spirits that once lived here, these simple sprites respond in kind to forces, emotions, and intentions of the creatures around them. \r\n\r\nMy apprentice Yala Windwatcher went to observe them. Seek her out and discover what she's learned.",
},
[94484] = {
["o"] = "Find and speak with Elegael Thornpaw in the northeastern part of Shadowgale Forest.",
["d"] = "A moment if you will, N. Are you headed towards Shadowgale Forest? There is a druid conclave there in a cave to the northeast. I have been waiting on word from them but their correspondence is long overdue.\r\n\r\nWith Ban'aethall in ruins and all the unrest lately I worry something dire may have happened. Please, if you are able, go seek out Elegael Thornpaw and put my mind at ease.",
},
[92598] = {
["o"] = "Use your Skysight racial ability at the Elemental Convergence in Thendal Grove.",
["d"] = "As a Windshaper, you have the ability to use the sacred skysight gifted to us by the elemental spirits. Travel to the standing stones to the northeast of the village. Find the elemental convergence there and use your gift.\r\n\r\nYou'll find that you may draw upon the skysight anywhere, but its boon is much more powerful if you do so in the presence of an elemental convergence. You may at times receive other bits of wisdom from the spirits that are drawn to such places of power, as well.",
},
[93948] = {
["o"] = "Deliver the Shadowsong Family Signet to Talaanis Shadowsong in Valanaar.",
["d"] = "Since you are going to Valanaar anyway, please deliver the signet ring you recovered from the tower to Talaanis Shadowsong in Valanaar. \r\n\r\nHe will want this back, and more importantly, he will want to learn the fate of his nephew. Talaanis is the High Elder of Zephras Isle and more importantly, he is a good man who is well loved by the people, despite our current hardships. It pains me to think of how he will react to this news. Please express my condolences for his loss.",
},
[94414] = {
["o"] = "Speak with Halaan Hawk-Eye and borrow his gift to view the anchor pylon in the distance.",
["d"] = "Greetings, young N. I oftentimes come here to look upon the ancient anchor pylon. Gifts from the spirits of the winds, they bind and sustain our island. Of late however, their magic has grown unstable and inconsistent.\r\n\r\nThey suffer no distress I can see. Their splendor has not changed.\r\n\r\nIf you'd like, I can lend you my gift to look upon them yourself.",
},
[97965] = {
["o"] = "Speak with Naleeia Tattermend in Shen'dar Village to learn to craft a camping item for your profession once you have shown proficiency in your skill.",
["d"] = "So you've taken up First Aid? That's an honorable... and pragmatic pursuit as a hunter.\r\n\r\nI reckon I know someone that can teach you how to craft a First Aid Kit for your camp. Injuries are a reality in the world of adventuring and offering some much-needed healing at your camp could even save lives.",
},
[96646] = {
["o"] = "Speak with Zerril Softbreeze in Shen'dar Village to learn to become a cook.",
["d"] = "So you want to learn more about camping, huh? Good for you, hunter. The first step any adventurer needs to take is to become a cook and learn how to make a campfire.\r\n\r\nCooking's not just about making tasty foods. It's also the foundation for your camp.",
},
[92465] = {
["o"] = "Slay 6 Roiling Winds and 7 Al'Aketh Converts in Thendal Grove.",
["d"] = "The Al'Aketh cult is a blight upon this island. These cultists are surely the ones responsible for agitating the simple wind sprites that reside here and turning them violent.\r\n\r\nRegrettably, we'll need to disperse these roiling winds here before they harm someone. We also need to send a clear message to the cult that they are not welcome in the grove.\r\n\r\nWill you lend me your aid, hunter?",
},
[92685] = {
["o"] = "Loot 7 Blood-Stained Bandit Masks from Highwayman Bandits in the Gustberry Lowlands.",
["d"] = "The bandits have camps all over and there's a small one in the hills just north of here. Head up there and start cracking skulls. If we can catch them off guard and take them out before they come for us, we might just even the odds enough to stand a chance.\r\n\r\nBring me their masks. The bloodier the better.",
},
[93949] = {
["o"] = "Kill Skyhoppers in Valanaar until you've eliminated 8 Enchanted Skyhoppers.",
["d"] = "We've been bugged.\r\n\r\nIt's skyhopper season in the lowlands, which means the pests are everywhere. One of the High Order mages reported that one of the insects that they killed had an enchantment of some kind placed upon it. When we inspected it closely it seems to be some sort of listening spell.\r\n\r\nWe suspect that the cult is using these enchanted insects as spies. Go and exterminate them for us. You won't be able to tell which are enchanted by looking at them, so you'll just have to kill them all.",
},
[92693] = {
["o"] = "Speak with Aamelia Windfield when you are ready to confront the bandit leader.",
["d"] = "You've done a lot to give us a fighting chance. Even if we die today, we'll at least know we gave it our best shot.\r\n\r\nThis is your last chance, stranger. If you want to head back to Valanaar and live another day, I wouldn't blame you.\r\n\r\nOn the other hand, if you really have a thing for lost causes just let me know when you are ready to go. We'll walk out there with our heads held high and whatever happens, happens.",
},
[93159] = {
["o"] = "Speak with the Strange Hermit in the Shadowgale Forest and learn more about him.",
["d"] = "Uh, um... h-hello, I mean to say, hi! Greetings, even! I'm sorry... it's um, been so long since I've actually spoken to another person. I'm afraid I'm a bit rusty at this.\r\n\r\n<The strange hooded figure shifts uncomfortably before you.>\r\n\r\nSo er, um... how is your day going?",
},
},
},
["lootFilter"] = {
["enabled"] = false,
["classOnly"] = false,
["recipes"] = false,
["schools"] = {
},
["matchAll"] = true,
["resists"] = {
},
["armorTypes"] = {
},
["stats"] = {
},
["weaponTypes"] = {
},
},
}
