
SpokenQuestsSettings = {
["char"] = {
["Rondine Signalborn"] = {
["hasSeenGossipForNPC"] = {
["Creature-0-7074-2991-2-251361-127D3A5406"] = {
["582647e7"] = true,
},
["Creature-0-6805-2991-4-251902-343DF3F803"] = {
["7e15e287"] = true,
},
["Creature-0-6805-2991-4-254089-343DF3F803"] = {
["5800ca19"] = true,
},
["Creature-0-7074-2991-2-257554-127D3A5406"] = {
["126f193a"] = true,
},
["Creature-0-7074-2991-2-263113-127D3A5406"] = {
["6fb686a1"] = true,
},
["Creature-0-7074-2991-2-249363-127D3A5406"] = {
["1f531c06"] = true,
},
["Creature-0-7074-2991-2-251362-127D3A5406"] = {
["3e2d362e"] = true,
},
},
},
},
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
["Bidwick Signalborn"] = "Bidwick Signalborn",
},
["global"] = {
["startedOnlyDefaultOn"] = true,
["Compendium"] = {
},
},
["profiles"] = {
["Rondine Signalborn"] = {
["Developer"] = {
},
},
["Bidwick Signalborn"] = {
["Developer"] = {
},
},
},
}
