
DialogKeyNumyDB = {
["showGlow"] = true,
["handlePlayerChoice"] = true,
["customFrames"] = {
},
["dialogBlacklist"] = {
},
["dontAcceptAbandonVote"] = true,
["dontAcceptVoteKick"] = true,
["ignoreWithModifier"] = false,
["postAuctions"] = false,
["dontAcceptInvite"] = true,
["keys"] = {
"SPACE",
},
["ignoreDisabledButtons"] = false,
["treatNumpadAsNumbers"] = true,
["numKeysForGossip"] = true,
["dontClickRevives"] = true,
["numKeysForPlayerChoice"] = true,
["ignoreInProgressQuests"] = true,
["handleSpecFrame"] = true,
["dontClickDuels"] = true,
["dontAcceptInstanceLocks"] = false,
["useSoulstoneRez"] = true,
["numKeysForQuestRewards"] = true,
["handleCraftingOrders"] = true,
["dontClickReleases"] = true,
["dontClickSummons"] = true,
}
