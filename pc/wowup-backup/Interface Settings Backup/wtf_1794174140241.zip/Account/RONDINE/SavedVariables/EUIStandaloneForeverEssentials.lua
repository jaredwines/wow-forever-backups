
EUICoreStandaloneForeverEssentialsDB = {
["unlockGridMode"] = "dimmed",
["unlockHeightMatch"] = {
},
["worldMapFade"] = {
["enabled"] = false,
},
["profileKeybinds"] = {
},
["ppUIScaleAuto"] = false,
["lastSpecByChar"] = {
["Rondine - PvP"] = 1485,
},
["macroManager"] = {
["enabled"] = true,
},
["activeProfile"] = "Default",
["bagsAutoDisabled"] = true,
["unlockWidthMatch"] = {
},
["unlockAnchors"] = {
},
["lastNonSpecProfile"] = "Default",
["_migrations"] = {
["forever_np_buff_showall_v1"] = true,
["forever_np_rare_box_v1"] = true,
["forever_snapshot_legacy_v1"] = true,
},
["specProfiles"] = {
},
["threatMeter"] = {
["enabled"] = true,
},
["profileOrder"] = {
"Default",
},
["gfxBackup"] = {
["RAIDsettingsEnabled"] = "0",
["graphicsViewDistance"] = "9",
["graphicsProjectedTextures"] = "1",
["Sound_EnableReverb"] = "1",
["graphicsParticleDensity"] = "4",
["graphicsLiquidDetail"] = "3",
["graphicsShadowQuality"] = "4",
["graphicsSSAO"] = "4",
["graphicsSpellDensity"] = "2",
["graphicsDepthEffects"] = "3",
["ResampleAlwaysSharpen"] = "0",
["graphicsComputeEffects"] = "4",
["graphicsTextureResolution"] = "2",
["graphicsEnvironmentDetail"] = "9",
["Contrast"] = "50.000000",
["graphicsOutlineMode"] = "2",
["graphicsGroundClutter"] = "9",
},
["ppUIScale"] = 0.6399999856948853,
["profiles"] = {
["Default"] = {
["darkMode"] = {
},
["unlockLayout"] = {
["heightMatch"] = {
},
["widthMatchExtra"] = {
},
["anchors"] = {
},
["widthMatch"] = {
},
["heightMatchExtra"] = {
},
["phantomBounds"] = {
},
},
["fonts"] = {
["global"] = "Expressway",
["outlineMode"] = "shadow",
},
["customColors"] = {
["resource"] = {
},
["class"] = {
},
["classResource"] = {
},
["power"] = {
},
},
},
},
["fonts"] = {
["global"] = "Expressway",
["outlineMode"] = "shadow",
},
["sidebarUnlockTipSeen"] = true,
["customColors"] = {
},
["lootFeed"] = {
["enabled"] = true,
},
["panelScale"] = 1,
["unlockSnapEnabled"] = true,
["lastLoginVersion"] = "9.7.5",
["restoreOnUninstall"] = {
["fresh"] = true,
["cvar"] = {
["actionbuttonusekeydown"] = {
["a"] = "1",
["b"] = "1",
},
["tooltipshowauraspellids"] = {
["a"] = "1",
["b"] = "1",
},
["scripterrors"] = {
["a"] = "0",
["b"] = "0",
},
},
["chars"] = {
["Player-6934-0043A935"] = {
["cvar"] = {
["mapfade"] = {
["a"] = "0",
["o"] = "EUIStandaloneForeverEssentials",
["b"] = "0",
},
},
["held"] = {
["mapfade"] = {
["e"] = false,
["o"] = "EUIStandaloneForeverEssentials",
["v"] = "0",
},
},
},
},
},
}
EUIStandaloneForeverEssentialsDB = nil
