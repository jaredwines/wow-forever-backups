
PetTargetDB = {
["point"] = {
"BOTTOM",
"BOTTOM",
-418.3338928222656,
77.33373260498047,
},
}
