
HunterThreatDB = {
["enabled"] = true,
["relevantOnly"] = true,
["showMinimap"] = true,
["scale"] = 1,
["soundWarning"] = true,
["showWarningDot"] = true,
["displayStyle"] = "normal",
["petRole"] = "tank",
["position"] = {
["y"] = 151.8330535888672,
["x"] = -422.4998168945313,
["point"] = "BOTTOM",
["relativePoint"] = "BOTTOM",
["relativeName"] = "UIParent",
},
["resetAfterCombat"] = true,
["locked"] = true,
["visibilityMode"] = "always",
["minimapPosition"] = {
["minimapPos"] = 225,
["hide"] = false,
},
}
SharedForeverUIDB = {
["appearance"] = {
},
["windowPositions"] = {
},
}
