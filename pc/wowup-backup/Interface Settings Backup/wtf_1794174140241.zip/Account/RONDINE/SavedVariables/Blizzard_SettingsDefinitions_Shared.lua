
NewSettingsSeen = {
["voiceUseDiscordSettings"] = true,
["voiceProvider"] = true,
}
