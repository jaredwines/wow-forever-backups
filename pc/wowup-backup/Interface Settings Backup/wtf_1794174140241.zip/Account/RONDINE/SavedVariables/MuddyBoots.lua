
MuddyBootsDB = {
["chars"] = {
["Player-6934-0043A935"] = {
["money"] = 40,
["played"] = 2176,
["stats"] = {
["played"] = 1616,
["hardcore"] = false,
["class"] = "HUNTER",
["data"] = {
["deaths"] = {
["zones"] = {
},
["total"] = 0,
["rev"] = {
["heal"] = 0,
["run"] = 0,
["pl"] = 0,
},
["how"] = {
["df"] = 0,
["dp"] = 0,
["dd"] = 0,
["db"] = 0,
["dw"] = 0,
["dh"] = 0,
["cr"] = 0,
},
["rows"] = {
["hh"] = {
["v"] = "--",
},
["ls"] = {
["vd"] = "27m (levels 1 to 2)",
["tip"] = {
"Levels 1 to 2 (Nov 4 to Nov 4)",
},
["v"] = "27m",
},
["ws"] = {
["v"] = "0",
},
["td"] = {
["v"] = "0m",
},
["wl"] = {
["v"] = "0",
},
["cc"] = {
["v"] = "0",
},
["dt"] = {
["v"] = "0",
},
},
["enemies"] = {
},
},
["spells"] = {
["ic"] = {
},
["io"] = {
},
["sc"] = {
{
"Raptor Strike",
1,
},
},
["so"] = {
{
"Walk on Air",
2,
},
{
"LOGINEFFECT",
1,
},
{
"Shen'dorei Windwell",
1,
},
{
"Summon Pachimari",
1,
},
{
"Summon Panda",
1,
},
},
["rows"] = {
["cm"] = {
["v"] = "1",
},
["mf"] = {
["tip"] = {
"Zephras Isle (11s)",
"Nov 4",
},
["cmp"] = "Zephras Isle (11s), Nov 4",
["v"] = "1",
},
["po"] = {
["v"] = "0",
},
["ds"] = {
["v"] = "6",
},
["iu"] = {
["v"] = "0",
},
["fd"] = {
["v"] = "0",
},
["sc"] = {
["v"] = "7",
},
["tc"] = {
["v"] = "0m",
},
["dl"] = {
["v"] = "1",
},
["bd"] = {
["v"] = "0",
},
["el"] = {
["v"] = "0",
},
["fl"] = {
["v"] = "0",
},
},
},
["travel"] = {
["zones"] = {
{
"Zephras Isle",
1608,
},
["keepAll"] = true,
},
["played"] = 1616,
["dist"] = {
["tram"] = 0,
["portal"] = 0,
["ghost"] = 0,
["ride"] = 0,
["swim"] = 0,
["boat"] = 0,
["fly"] = 0,
["foot"] = 1852,
["hearth"] = 0,
},
["sessions"] = 2,
["rows"] = {
["zones"] = {
["v"] = "1",
},
["played"] = {
["v"] = "27m",
},
["jump"] = {
["v"] = "4",
},
["afk"] = {
["v"] = "13m",
},
["long"] = {
["v"] = "15m",
},
["camp"] = {
["v"] = "0",
},
["boat"] = {
["tip"] = {
"Boats 0, Zeppelins 0",
},
["cmp"] = "(Boats 0, Zeppelins 0)",
["v"] = "0",
},
["port"] = {
["tip"] = {
"Mage portals 2, Warlock summons 0",
},
["cmp"] = "(Mage portals 2, Warlock summons 0)",
["v"] = "2",
},
["sess"] = {
["v"] = "2",
},
["hs"] = {
["v"] = "0",
},
["fl"] = {
["v"] = "0",
},
},
["afk"] = 756,
},
["dungeons"] = {
["r"] = {
},
["pr"] = {
},
["d"] = {
},
["rows"] = {
["rlf"] = {
["v"] = "--",
},
["dlf"] = {
["v"] = "--",
},
["rc"] = {
["v"] = "0",
},
["dc"] = {
["v"] = "0",
},
["rbk"] = {
["v"] = "0",
},
["dbk"] = {
["v"] = "0",
},
},
["pd"] = {
},
},
["kills"] = {
["bossD"] = {
},
["types"] = {
{
"Beast",
20,
},
},
["rows"] = {
["ra"] = {
["v"] = "0",
},
["rb"] = {
["v"] = "0",
["tip"] = {
"0 raid runs.",
},
},
["pk"] = {
["v"] = "0",
},
["ck"] = {
["v"] = "0",
["tip"] = {
"Hunter pets count.",
},
},
["db"] = {
["v"] = "0",
["tip"] = {
"0 runs.",
},
},
["el"] = {
["v"] = "0",
},
["cr"] = {
["v"] = "21",
["tip"] = {
"21 of them gave XP.",
},
},
},
["bossR"] = {
},
["enemies"] = {
{
"Juvenile Vuldren",
10,
nil,
"Zephras Isle",
},
{
"Pesky Cirrusfly",
10,
nil,
"Zephras Isle",
},
},
},
["loot"] = {
["es"] = {
},
["nd"] = {
0,
0,
},
["eq"] = {
},
["gr"] = {
0,
0,
},
["rows"] = {
["tr"] = {
["v"] = "0",
},
["ra"] = {
["v"] = "0",
},
["il"] = {
["v"] = "0",
},
["ep"] = {
["v"] = "0",
},
["un"] = {
["v"] = "0",
},
["rw"] = {
["v"] = "0",
},
["pr"] = {
["v"] = "0",
["nocmp"] = true,
},
},
["pieces"] = 0,
},
["gold"] = {
["ob"] = {
},
["s"] = {
["cls"] = 10,
},
["money"] = 40,
["e"] = {
["quest"] = 50,
},
["rows"] = {
["ts"] = {
["v"] = "10c",
},
["te"] = {
["v"] = "50c",
},
["gh"] = {
["vd"] = "40c (40c, 1 character)",
["cmp"] = "40c",
["tip"] = {
"Rondine: 40c",
},
["v"] = "40c",
},
["bp"] = {
["vd"] = "35c (Quests)",
["tip"] = {
"Quests: Infestation Investigation (Nov 4)",
},
["v"] = "35c",
},
["mh"] = {
["vd"] = "50c (level 2)",
["v"] = "50c",
["nocmp"] = true,
},
["bpu"] = {
["vd"] = "10c (Track Beasts)",
["tip"] = {
"Track Beasts, Class skills (Nov 4)",
},
["v"] = "10c",
},
},
["best"] = {
},
["accountLines"] = {
"Rondine: 40c",
},
},
["prof"] = {
["top"] = {
},
["cur"] = {
},
["ab"] = {
},
["chart"] = {
},
["gathered"] = 0,
["made"] = 0,
},
["guilds"] = {
["guilds"] = {
},
["played"] = 1616,
["level"] = 2,
},
["leveling"] = {
["top"] = 1,
["played"] = 1616,
["lzones"] = {
{
"Zephras Isle",
1,
"2",
},
["keepAll"] = true,
},
["act"] = {
{
["dungeon"] = 0,
["combat"] = 52,
["travel"] = 194,
["afk"] = 0,
["town"] = 544,
["dead"] = 0,
},
["keepAll"] = true,
},
["xpTotal"] = 924,
["rows"] = {
["mxs"] = {
["vd"] = "839 (Nov 4)",
["tip"] = {
"Levels 1 to 2, Nov 4",
},
["v"] = "839",
},
["axp"] = {
["v"] = "2,058",
},
["days"] = {
["v"] = "0",
["vd"] = "0 (Nov 4 to Nov 4)",
},
["mdl"] = {
["vd"] = "0 days (level 1)",
["tip"] = {
"Level 1 (Nov 4 to Nov 4)",
},
["v"] = "0 days",
},
["atl"] = {
["v"] = "27m",
},
["rxs"] = {
["v"] = "0%",
["tip"] = {
"About 0 of 924 XP",
},
},
["bxp"] = {
["vd"] = "924 (level 1)",
["tip"] = {
"Level 1, Zephras Isle (Nov 4)",
},
["v"] = "924",
},
["lsl"] = {
["vd"] = "13m (levels 1 to 2)",
["tip"] = {
"Levels 1 to 2 (Nov 4)",
},
["v"] = "13m",
},
},
["xp"] = {
{
["dungeon"] = 0,
["kill"] = 343,
["explore"] = 0,
["quest"] = 40,
},
["keepAll"] = true,
},
["lt"] = {
790,
["keepAll"] = true,
},
},
["pvp"] = {
["ng"] = {
},
["kb"] = {
},
["dw"] = {
},
["rows"] = {
["tq"] = {
["v"] = "--",
},
["rk"] = {
["v"] = "--",
["tip"] = {
"No rank yet.",
},
},
["wk"] = {
["v"] = "0",
},
["rx"] = {
["v"] = "--",
["tip"] = {
"No rank yet.",
},
},
["hk"] = {
["v"] = "0",
},
["tb"] = {
["v"] = "0m",
},
["bk"] = {
["v"] = "0",
},
["ho"] = {
["v"] = "0",
},
["mb"] = {
["v"] = "0",
},
},
["tg"] = {
},
["duels"] = {
},
["worldKills"] = 0,
["faction"] = "Horde",
["db"] = {
},
["worldDeaths"] = 0,
["kw"] = {
},
["bgs"] = {
},
},
},
["v"] = 1,
["race"] = "Skyborne",
["name"] = "Rondine",
["level"] = 2,
["money"] = 40,
},
["guid"] = "Player-6934-0043A935",
["hardcore"] = false,
["class"] = "HUNTER",
["lastSeen"] = 1793836541,
["preview"] = {
[2521] = "4281,2321;4306,2766;4656,2630;4333,2434|4334,2434;4376,2406",
},
["first"] = {
["y"] = 2314,
["x"] = 4281,
["m"] = 2521,
["t"] = 1793834366,
["level"] = 1,
},
["race"] = "Skyborne",
["name"] = "Rondine",
["sex"] = 2,
["pins"] = {
{
["y"] = 2478,
["x"] = 4342,
["k"] = "level",
["m"] = 2521,
["l"] = 2,
},
},
["level"] = 2,
["faction"] = "Horde",
["realm"] = "CAMWOW US2 Realm 8 PvP",
},
},
["settings"] = {
["shareSelfBars"] = false,
["colorblind"] = true,
["statsBar"] = "meter",
["recordRate"] = 2,
["saveReminder"] = true,
["lowHealthFlash"] = true,
["slimming"] = "medium",
["tool"] = {
["gear"] = true,
["zoom"] = "in",
},
["computerName"] = "Blastoise",
["gearWeapon"] = "auto",
["unexplored"] = false,
["distance"] = "auto",
["shareCard"] = {
},
["markers"] = {
["dungeon"] = true,
["pvp"] = true,
["loot"] = true,
["death"] = true,
["mount"] = true,
["level"] = true,
["worldboss"] = true,
["big"] = {
["dun"] = true,
["boss"] = true,
["loot"] = true,
["death"] = true,
["mount"] = true,
["level"] = true,
["pvp"] = true,
},
},
["awaySave"] = true,
["newZoneSave"] = true,
["trailColor"] = "single",
["shots"] = {
["lastBoss"] = false,
["level"] = false,
},
["minimapButton"] = true,
["bigMapHidden"] = true,
},
["errors"] = {
},
["schema"] = 1,
["computer"] = "60249f",
["backups"] = {
["Player-6934-0043A935"] = {
["played"] = 2176,
["name"] = "Rondine",
["blob"] = "1VpJjCPXeW72zEjW+CIEQtAdIDEVO4lkz0i1vVqabkTs5taj2dw9o6Z9Sg1ZJEtdrKKqit3Tk4Jh6BIktwA55GA4kDWKtwA5B7An0gA+OIcgCJxDgAA+6WTAF8tIgABKvv9VvWKxSHa3J75EwjT5s/7le//7l7fU9/ZOQjeOHX/ntCm9Jr+mdCInitzAj/78b9sTzz51+tJaw7Oj+Hfe/vmPnu6OgpOmFwxdv9MLxpNp7IQtXVI0a5AxyxutZhTbIWf/eq5i44bQ8WSbdLRCxwvsflnJTPQnub4PZ0p+nCv51hlKhORm5eVc35PdXMtm5Q9yNf98hpqZ7OOZxq8U1LyVq/nZGWpmsr2Zxp8W1AyEmo/+6ww1M9mPc42Xk8cFCaHm6dpKr3706czu5T/LBSYFLStln16Z2f1lQc1/CjU/Pgt+LvuZP81H8nTa6I3s8AeN4dTt37tLsRZe1y1Vuy5Jmlq3VNbsIfCiVuf+7XvN/Wbo2N74rd36rcM7h9X7B0p1n36omtW7x3f3+o4dj+5MHP+TRmj3nM7B0emDIPSdhm+PnfZ+4Pdd39mNnIfr7YHdixHgzU4Q9p2m5xw73npz4IZR/EH9dPOFq/WHmy/+Q328+cK/19MoTnkq7WgakrYbB+7Qtz1S34xD2/W+XT+utHqjqX8U/cUH9YgS5esF+Xfr/VvSNU0x5WuKKmvXrtf9Ssb2kwLbP61ke7I7Y3vSKLIpckHbk8cFtser2X5aYPu31WwfF9g+rve/+sKVfBBktqaLIalaTVFA6AzjY0ZN0UAwIjQ8ITZVJUKvqcSmWSB0paYSm04+0Y2aSmy6BILJNdUkNoMIpaaRVU0Hocg1jSswQahGTSMFKilgag0cmiIrIDSrxoiQBAFtssWxKTWYAFsGVCdtChFAYJA2btTUawaHo11TNFmpGQTHABxI1kzuBIwHcGsmFKgSFGgYqQkFqoIhaLpUM6FAxQih0aiZUKBqJGNYNYtkVGJjIEiG4Gjwm0VGCagGV8lSTjETFKmQ4DnNVGqyDBAqDZbJMijSKAMfIzkEGGBACzPpGccB07pMz0gLTYYOJ8nACk54VodXeqBV0gNJ3WCYXxlKYBPPDckAZRCFp4amgrLEMx16VXqGyVUMTtEzhkkydCDXZFAmbBoG8MALoEinoZBNjWzAJUSDgh6NRmIY0IpA0TQEhmIwUAySYCWKo8Nf+In0kk1GkpRgKS9JciuMjwxRpmncioJxQwgUjUQCPkStxiTSIxk0ah2aGHklfQpNDIGmGAgE2YAepnMKNg3oYTQy1CxQpMck75kWjcyEHp306ggM6MWvKW0gimSLNHFEKmStmSbgAzQ8Q4To5AWL8BBanbxgEZ6MghUFITGjr9cUGXp1hABmWAcFvTqyCbImKOjV4XBQMsnC0XhKNKaOZAkhQgs0uJHjwAuP6ppcUwihTvGnY/YpSDUdDAr+gCI9XK/KQJEWJCC0SDUVCvAM80vxp8IdkINFZlmghBYaUK9GoZdqJfo6qoAYOYN/VfIfwwQgrllN5f6jGsMMosh/ZJOhEqiEjqFsIB+AgPsPJUlhOioL9x9VBoa81AgdEgqURRS0wJnAKjFQ0KIhsIEc1QWxgcjMkGvkdTLDrWvkcxUVA9ZRocjnKmlhCuRoTGnqWxooaEmrgmmBIi1UcTRTQmUjTspNzYAczzbym2aYNWQlPYMFDVmCb6Ao+zFboCCnwB28ahBgFCbixNiBnyoXUSrsUa4pFqIBSQWKsKBug4IWyrUUCzJEQ3yAh5DJsE6Zp1JkAyMowkmlHrpAkRbKj/QZaeE4FchRnvGqgJGC4uMje1TUKcvSwqdDp05yFLVAVNMoy3hdIoqCLquxwKmTrxUEBpBpoGhERCEeQNHYUVEVFXOrc++i/OEZOCmacyw6r3QUPYSaAjKdP8wkKEKGio1nsM7rHBKd+1Pn88DHLkOOzwOSG1hUUFwLIYPndV4R+TzAgzrKVuZBQp1WROJEhFDiwDrNH7yk81nhFlBzdUa1HO1H0STIUbtSU51AplMt53MkQQs1LJVinjqrzjsWEgadEXK8ZVGeUzvVqWdR2QAl1QykAuxyCo1Ogj2FYiJ9Rh2I2haKOZ7BHuIPlAE56itpv0aNMqivKBQhKhqcwfsK2DOKUMONmAdYoLUBejdRkFNoDJgMBbmOBkxjgCo+WkOjZ7y3oo4YqOOgoAUVAhTppCxGUQdFqCkDmEQUIaOxaxbJcWScU0NX580bFlDwQZEneBajD6CLCAs0Iu5dQkbRahhkneemqtX9jQ/S1dtHn85WSB/9T7qQSrMbjX+2yHt6Zcb29Ll6v/svXBuPduoMtKbhbZYCjq9p0hxN1zRY9QCEgmQmf1CVpVUIdweyNCVIQRpBSo2HDE8QxeDrIBXJhVkEQQo4G4ZLnuB9OM0AEBgx2BDWPObIY8RGTqEWR8nOfYI2h0hliAfSRqVF0uv+i6lH5oa6n3mEr5yot+bL3jm2e0vYmgPPHkaPb3vBSQdr/HjUwj5g9Ks3TxwPu07nwHH8X3Wwdej3gtD55G7keINWMPX7dQ8STv+TRuTbk3e/28RGNI66G5aib2s1S5W3sdBUrW10cqwOt1kr3d+utWPbc/w4WutwgdvByWqZxtCxw+6WdI3+x6qA8jD/CnfQL4z/krLwZxI6PfUj5JfUio5cz4u+WrEPHXsS+NUDTm/tBCfRtvY6q9XDcRBW74bBwO25jo9/0dauF8Sjbfl1uTYv1LCHQydM5UpPnIHjRw7XeNP2h1N7CD3i21a1YWMvg42+7W+rkvQ6/tXEwyLbnbDnRqOcZRm2m7TzckKObpf2a2JEt+zwKBrbfjRyJ4tPD6bhsXtse0tGdXCCnVmEB6w03HsnwfWO7fedfnUlz33fDsdOn6T3HjhR3HKHo/hxE1Pdc25+zZmMQjuq7kUebQZ7n+U7vH/8FkJzd3I8+c5ePAqdaBR4/c31X9zw3IETu2On8+ZaM3Zjz+nsuseuB5/dGAV+EN4LEDhrrUngUvC0R7AEg2vYgPpHa3+XRdfmpd9uPAr8edvNMX453fg8N//hXzZ7OF+JrjR5JLzf7k/9oRP4MEoGXtp5OPmtWWQ+lCVjm5aQKKPb/EMHWX1lxyEdr2KPZW4zqYfSp/JPdNL0U9X4p6yZxjbDNmQhJ7DU5Iply6RP/NVrFsOfNFuybErtS/P2pXn7Kkvt0yfZ55+wT5/n2Idibl8i+wrZF9n6m8u84XyqZJknS8+YehCcV9jIcw+PlmXV/4vkWxjWsuxbYJqlnyzhkC+Knf7abzq1Wj0U+zj6+w4d5By78en3W3Fw4m/Jm5VPOziRwYHOlrLxIdjGD+x4Q0ufKpuV91rp083Ku4JP3ni6aw+ONtc/aZCOzUt/QydgENuSN7Qmnmwp9GwcHDsfNAZBEG9WvtmiTzz/Dyohm5/Za+Gp6w/zJ2Q7NfS4+fZ0PIkut/nHlryefVHW25MgRHJH62kp+E5j5Hj9jVda70zhsy9tKIQPJ1bh9astNBzf6W8oexPHPrrJj6sa9HVDaUY48IqvtvCBlvKD/WDrYDpGaanetXsjd2yHbmUvHc2B09tgHSoz91DQ/vuN5wb8v0YPJ2jP3Qq2Dm3vqArBuhuu3y6o8ft2BY9v3mnv3W62Ws3dezjp4v6ppNXp+fvgHjn+H/XRit3qoev30aW9yp3e1r49idHJDuLQPXIqqGLfa6KLOeHGFxpU6DYrh20+WnjyX7NvmKM7bc60Jb+YfVFe2rXBfembTc69uf5yi8Rptg87kzAYIsqi91v8HC+qpA6Mnnuz70Y9TFqI9rkunBm9l54oXk0r7Xe7Vf/R1o3pseO7nlN9a+r1Q8d/o9gkrmY1uB1v8QL70lf8rbtOdHRa3XXDcBoNvNOrDT94OFnf9xc0XaXK3f0cbJRE5k00PITT+003dsbR5Z135Es770iVDvDHtt9zHmfRtnnph2n8Pf9ldByKnbX0ibJ56Rt7dJCKbHDCb7e9NF4qzQfTwSC63IqCnmt77zXfRpuKrrQG1A+j99tegCYTxZ+lGN5gdf95ytJvtKLeyBnbFSw4hn/9V93PyYaF9R9tO5IEO1o5wdpaTugYMwmjROp+/gwG10/4TUH3C2cwTXpJen/QfVlwGdKCrdhOJFj7kzNYhk4iJ+ma61mWZRnUasGCXh7xxEv07qtncYRHwCkWCd3XBKtuJUZZWd9N7iFv+rZXfQvhjOVZ90uC31ASs8z/KEiKgdl9JWdmiSyVuaOjhNoaXMIKiFdw8tUlWOUCghWs2YKT653BXcWc9kHO/OXz4Io+WVyaJliW0r+ueXHpdMWaS54LMlu+8uFL55kpLmm5xLXzJMQyl3N/8VxuvvLlDmPn8S60Yy527nizBs2ZRXpjY5kg60oJ7vW7Ih2WMwTTOK8QOB1byFpeIUTyL2NAhUjvAbu/n41W05TEWIh9JJ5h5mAYMxLZUubgojIBrighKziKeJmuzuOFhjm8yxhmeMWomM4SRUJFLNRGaAJg/JojxkFOgjOJMlcB8QqOImKdWWcjxjH+AsMiYl0HWmu+HGWILSNHjIOhBBuMMxCv4CgixpnRAqA5Hy9jWERsoLzh9qiMBT7GrzPEspWoDLMxPxMFHxvLOeYQK9o5iBW2wLAEsaInOIgrYyHEutK1slg3EOg4OhRccBZdXiXvxIlFd0iJhpaX7AZjLC2rwaBaR4cwzhZ9OCEhvkwqCe6eLegFCd0JAQKyOJWv08mDH1c7jhtigTJGdxD9zFStRDOEq3HZhCGYUhI9yjtaO8TSa8aPpMY9WDZQVcVAcTmQFDpgyt/OQJqGlTCsMNKpxCl3gkNsLTlyk9I6Chy44bISvjRLsCMf214CoB2hCFWCKcIwU2CYQg6Kyos+aJJMQ13QJObKkgBJE5CYiW+6aSRwOJOgz/MWNHZvZCAsGSA0AQJXQhC1SGhBZCkI6JfzkLFUNWG6qI+4J4Eupp8JAzeDfAmHe/WE5UUeNzsQRbQN305u2SePql87scdJ0ti/v9dIlO72uUI7Tj8aOU4cIUCwjTkNpkly0Knfqt+GeO61lTbb4bQ/PK3eDfw4CPxcVO6Ktrcabn1c3UFA9nHolyT7d9r3m3BQ7mxVxyhFPcaVAI3y4jPOnZ17DDGHi6osDDOPycnQQ5SUB9/dEh6Di3F/VBZCoCAMeKCUY1jr7uWyKmTF7OYGLxj30C93a7kqI9HxS5pCuSqCwZbHa6LNnIj8wyViWfiiEQsL8swf2C7g7q+sqwDkDH+Y8If8zP6Yh6EnuAQqw0D0341Oj4LqnUenOKnsu3Y0i6ncl6giuBYqy9IQ1PN9aWkJFbvSRFzYl2rRl8j3JboKQM7wJVo+7nmX4CjLLKupGGghtpATOjK7NKQCjIXqmscWk1B4dCRpSfjX8kc2MdBlJriPLuu6IBAZQPJVRZ4hzwZEQaCyPFBpFYI7PyrLIumXeCSrGLi0QoRgbZd5hNTQRBWEyzNU8CZ6Ly37Mln0Wbpov3Bv4SUjqz7AgRShXssXULi0z3WV7S+NEKo+X0yrD27XkDF6njE87xC7qJx5rxEFArzwXd7S0hwF75nDzyGrGP6spwk7mMMLQ85jCQsnvPciRi9UFWAsmcKs6+BeB+PNFzj5GC4cS4XKDV0IBxTgbBqKQM6t3BBGlpt5lgvhCwMplEwmMSSImWeq0EUeobUYljxlJ2vdbDu8ShYBUOjeou+BGyFg5ukjLF10GrVZiWQSIgnX2Eu8hyxbClqdwcC6wZAWBnxBGNCfdz2sJVmCe/Bng4F1paEsm8Oyv5fl4RwMGcXWmBVb4VhM4fnekOFFA0WsFIe/jjdezcoBbnQS3NJnqvCODr5paYrrCT/t7WYnLwyvkiV4FSxjxXU1sSrFrYU4LJOFcixiDVqP87KFG3KMDesGhFq5s3ez/QXDu2QQEUNTqdLhNRux8UIyoqSgsuz5AxyQ2vSuaHXPP8Z3d8ipbkPYXq6IUgQq0n3Uai3ZmccqON4xVtLZvm0Vz9gnoOcZyg4roARTaomozMdNpyuW1H2QDwqxa4k+kHPhfFX5v5yv4v3bYd4gZGxajPwIBy/mYAaQueLUEqkkda/neFbxisPIi7Jnx5GcXVSq1UjSG2ZsiIEl23fDg6uwLDuNu9AgZudxYH89G7OC5DPRkbKgRmemV6MoqOc3TuJsF7EvQUDULty5pgKU6VKWYm9kuvFOF4aUpyPeBcK5AzY+2bmDnGArjyV8B9fogX9adf3qju3RTYTYFbJVGmANsmk0PoM4ghl2V4pnm/qV1ukMg+GVIqAXZxjZjU614/ad6g69F47jJ3k2DhREeEKsU3JP0DgEkBbunugA5tCNR7jKOvWc7h8LR64QTx1pYAYZDnCWKMhnArmL23yRaihCmAkUjqJ93BFUD+1TOgDC3Vm1g4tPJ+zuCAgrNKQQsBDgEJbryLa5DC/4EApRQXMUXpjcg8uOqumbBej6lpYnwiqh+EHC39kviUr5cm+VICb/OmI4u/WcExfHuni9ErUZ7w+ItKA9CJ1M44xP1NJVLIVDPqjJjyXxulaqongsuZRhdsj3u5nvGbraEiS/Jx4j8cqP51DMThJXoFjCMEPxh7kZHIbjleayKRR1+jn3HW1w8IZ3XiFotYq3Wgun5ixjEemAtygzFkccK4AFG0G8uyesCZbJ/OVU+pgXL9zaZafyEEblXSI8O6JdzVKEoEMLbhuy2nghCPXMW3i9mYQXvFDOOBx+joIwoqzLLt3yTrxKBaUc7jiyrKeUW6IkdwWKuYz3u8uDKEQy7QGXsRRjCK+Z5jEm/DAXycsYFmOI9qp4v19sfvKJpxjCz+KSl1lUW2eHOXhXEwGChZM9SOT/BQ==",
["t"] = 1793836541,
["level"] = 2,
},
},
["minimap"] = {
["angle"] = 250,
["hide"] = false,
},
}
