
RXPTT_DB = {
["showMinimap"] = true,
["showWorldMap"] = true,
}
