
GatherLiteSettings = {
["char"] = {
["Rondine Signalborn"] = {
["minimap"] = {
["tracking"] = {
["mining"] = false,
},
},
["professionTrackingInitialized"] = true,
["worldmap"] = {
["tracking"] = {
["mining"] = false,
},
},
},
["Bidwick Signalborn"] = {
["professionTrackingInitialized"] = true,
["minimap"] = {
["tracking"] = {
["herbalism"] = false,
["mining"] = false,
["fishing"] = false,
},
},
["worldmap"] = {
["tracking"] = {
["herbalism"] = false,
["mining"] = false,
["fishing"] = false,
},
},
},
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
["Bidwick Signalborn"] = "Default",
},
["global"] = {
["lastSeenVersion"] = "8.2.2",
["controlsGuideSeen"] = true,
},
["profiles"] = {
["Default"] = {
["minimap"] = {
["minimapPos"] = 32.69674001362082,
},
},
},
}
