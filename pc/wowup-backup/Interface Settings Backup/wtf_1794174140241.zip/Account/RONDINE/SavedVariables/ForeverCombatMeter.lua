
ForeverCombatMeterProfiles = {
["profiles"] = {
["Default"] = {
["windows"] = {
{
["y"] = -982,
["x"] = 268,
["point"] = "TOP",
["locked"] = true,
},
{
["y"] = -983,
["x"] = -271,
["point"] = "TOP",
["locked"] = true,
["mode"] = "threat",
},
},
["windowCount"] = 2,
["locked"] = true,
["threatWarn"] = true,
},
},
}
