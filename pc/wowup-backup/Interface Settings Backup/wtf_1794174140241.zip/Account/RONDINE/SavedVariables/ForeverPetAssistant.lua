
ForeverPetAssistantDB = {
["enabled"] = true,
["smartGrowl"] = true,
["point"] = "CENTER",
["showThreat"] = true,
["scale"] = 1,
["criticalHealth"] = 25,
["lowHealth"] = 45,
["combatOnly"] = false,
["x"] = 0,
["relativePoint"] = "CENTER",
["locked"] = true,
["showButtons"] = true,
["sound"] = true,
["y"] = -155,
}
