
SYNDICATOR_CONFIG = {
["show_inventory_tooltips"] = true,
["debug"] = false,
["show_tooltips_on_shift"] = false,
["show_currency_tooltips"] = true,
["show_equipped_items_in_tooltips"] = true,
["tooltips_connected_realms_only_2"] = true,
["show_character_race_icons"] = true,
["tooltips_character_limit"] = 4,
["show_blank_line_before_inventory"] = false,
["tooltips_faction_only"] = false,
["tooltips_sort_by_name"] = false,
["debug_timers"] = false,
["show_total_line_after_characters"] = false,
["auction_value_source"] = "auctionator-latest",
["show_guild_banks_in_tooltips"] = true,
["no_auction_value_source"] = false,
}
SYNDICATOR_DATA = {
["Characters"] = {
["Rondine Signalborn-PvP"] = {
["containerInfo"] = {
["bags"] = {
{
["itemCount"] = 1,
["itemID"] = 2101,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2101::::::::6:1485:::::::::|h[Light Quiver]|h|r",
["iconTexture"] = 134409,
},
{
["itemCount"] = 1,
["itemID"] = 256935,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:256935::::::::6:1485:::::::::|h[Simple Leather Satchel]|h|r",
["iconTexture"] = 5160585,
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 277114,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:277114::::::::6:1485:::::::::|h[Apprentice's Skinning Satchel]|h|r",
["iconTexture"] = 133634,
},
},
},
["bankTabs"] = {
},
["details"] = {
["guild"] = "Peaked in Vanilla-CAMWOWUS2Realm4PvP",
["class"] = 3,
["realmNormalized"] = "PvP",
["show"] = {
["inventory"] = true,
["gold"] = true,
},
["race"] = "Skyborne",
["faction"] = "Horde",
["sex"] = 2,
["character"] = "Rondine Signalborn",
["className"] = "HUNTER",
["realm"] = "PvP",
},
["bags"] = {
{
{
["itemCount"] = 1,
["itemID"] = 6948,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:6948::::::::6:1485::75:::::::|h[Hearthstone]|h|r",
["iconTexture"] = 134414,
},
{
["itemCount"] = 2,
["itemID"] = 255663,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:255663::::::::6:1485:::::::::|h[Windstone]|h|r",
["iconTexture"] = 5172975,
},
{
["itemCount"] = 1,
["itemID"] = 279981,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:279981::::::::6:1485:::::::::|h[Basic Campfire Kit]|h|r",
["iconTexture"] = 7808148,
},
{
["itemCount"] = 4,
["itemID"] = 252031,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:252031::::::::6:1485:::::::::|h[Crisp Spring Water]|h|r",
["iconTexture"] = 132820,
},
{
["itemCount"] = 11,
["itemID"] = 4540,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:4540::::::::6:1485:::::::::|h[Tough Hunk of Bread]|h|r",
["iconTexture"] = 133964,
},
{
["itemCount"] = 5,
["itemID"] = 159,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:159::::::::6:1485:::::::::|h[Refreshing Spring Water]|h|r",
["iconTexture"] = 132794,
},
{
},
{
["itemCount"] = 1,
["itemID"] = 4471,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:4471::::::::6:1485:::::::::|h[Flint and Tinder]|h|r",
["iconTexture"] = 135237,
},
{
["itemCount"] = 3,
["itemID"] = 257945,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:257945::::::::6:1485:::::::::|h[Pilfered Windstone]|h|r",
["iconTexture"] = 5172975,
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 7097,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:7097::::::::6:1485:::::::::|h[Leg Meat]|h|r",
["iconTexture"] = 133974,
},
{
},
{
["itemCount"] = 5,
["itemID"] = 2589,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2589::::::::6:1485:::::::::|h[Linen Cloth]|h|r",
["iconTexture"] = 132889,
},
{
["itemCount"] = 3,
["itemID"] = 118,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:118::::::::6:1485:::::::::|h[Minor Healing Potion]|h|r",
["iconTexture"] = 134829,
},
{
["itemCount"] = 6,
["itemID"] = 5469,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:5469::::::::6:1485:::::::::|h[Strider Meat]|h|r",
["iconTexture"] = 133972,
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 2672,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2672::::::::6:1485:::::::::|h[Stringy Wolf Meat]|h|r",
["iconTexture"] = 133970,
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
},
{
{
},
{
["itemCount"] = 1,
["itemID"] = 1181,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:1181::::::::6:1485:::::::::|h[Scroll of Spirit]|h|r",
["iconTexture"] = 134937,
},
{
},
{
["itemCount"] = 1,
["itemID"] = 252028,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:252028::::::::6:1485:::::::::|h[Fresh Gustberry Bread]|h|r",
["iconTexture"] = 2466573,
},
{
["itemCount"] = 1,
["itemID"] = 252032,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:252032::::::::6:1485:::::::::|h[Red Delicious Stormapple]|h|r",
["iconTexture"] = 133975,
},
{
},
},
{
},
{
},
{
{
["itemCount"] = 1,
["itemID"] = 7005,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:7005::::::::6:1485::14:::::::|h[Skinning Knife]|h|r",
["iconTexture"] = 135637,
},
{
["itemCount"] = 9,
["itemID"] = 2318,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2318::::::::6:1485:::::::::|h[Light Leather]|h|r",
["iconTexture"] = 134252,
},
{
["itemCount"] = 18,
["itemID"] = 2934,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2934::::::::6:1485:::::::::|h[Ruined Leather Scraps]|h|r",
["iconTexture"] = 134360,
},
{
},
},
{
{
},
{
},
{
},
{
},
},
},
["auctions"] = {
},
["currencyByHeader"] = {
{
["name"] = "Unknown",
["currencies"] = {
},
},
},
["currencies"] = {
},
["void"] = {
},
["mail"] = {
},
["money"] = 1017,
["equipped"] = {
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 271668,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:271668::::::::6:1485::75:::::::|h[Thendal Survivalist's Shirt]|h|r",
["iconTexture"] = 7813752,
},
{
["itemCount"] = 1,
["itemID"] = 263408,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:263408::::::::6:1485::11:::::::|h[Exterminator's Vest]|h|r",
["iconTexture"] = 7734196,
},
{
["itemCount"] = 1,
["itemID"] = 257263,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:257263::::::::6:1485::11:::::::|h[Thendal Ranger's Belt]|h|r",
["iconTexture"] = 7734168,
},
{
["itemCount"] = 1,
["itemID"] = 1366,
["isBound"] = false,
["quality"] = 0,
["itemLink"] = "|cnIQ0:|Hitem:1366::::::::6:1485:::::::::|h[Ragged Leather Pants]|h|r",
["iconTexture"] = 134586,
},
{
["itemCount"] = 1,
["itemID"] = 271665,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:271665::::::::6:1485::75:::::::|h[Thendal Survivalist's Boots]|h|r",
["iconTexture"] = 132540,
},
{
["itemCount"] = 1,
["itemID"] = 1370,
["isBound"] = false,
["quality"] = 0,
["itemLink"] = "|cnIQ0:|Hitem:1370::::::::6:1485:::::::::|h[Ragged Leather Bracers]|h|r",
["iconTexture"] = 132609,
},
{
["itemCount"] = 1,
["itemID"] = 2125,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2125::::::::6:1485::14:::::::|h[Cracked Leather Gloves]|h|r",
["iconTexture"] = 132952,
},
{
["itemCount"] = 1,
["itemID"] = 264908,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:264908::::::::6:1485::11:::::::|h[Ancient Heirloom]|h|r",
["iconTexture"] = 629694,
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 257277,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:257277::::::::6:1485::11:::::::|h[Windblown Short Cloak]|h|r",
["iconTexture"] = 133763,
},
{
["itemCount"] = 1,
["itemID"] = 258882,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:258882::::::::6:1485::11:::::::|h[Worn Greatsword]|h|r",
["iconTexture"] = 135335,
},
{
},
{
["itemCount"] = 1,
["itemID"] = 2504,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cnIQ1:|Hitem:2504::::::::6:1485::75:::::::|h[Worn Shortbow]|h|r",
["iconTexture"] = 135493,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
["bank"] = {
},
},
["Bidwick Signalborn-PvP"] = {
["containerInfo"] = {
["bags"] = {
{
},
{
},
{
},
{
},
{
},
},
},
["bankTabs"] = {
},
["details"] = {
["class"] = 1,
["realmNormalized"] = "PvP",
["show"] = {
["inventory"] = true,
["gold"] = true,
},
["race"] = "Troll",
["faction"] = "Horde",
["sex"] = 2,
["className"] = "WARRIOR",
["character"] = "Bidwick Signalborn",
["realm"] = "PvP",
},
["bags"] = {
{
{
["itemCount"] = 4,
["itemID"] = 117,
["isBound"] = false,
["hasLoot"] = false,
["iconTexture"] = 133972,
["itemLink"] = "|cnIQ1:|Hitem:117::::::::1:1491:::::::::|h[Tough Jerky]|h|r",
["quality"] = 1,
},
{
["itemCount"] = 1,
["itemID"] = 6948,
["isBound"] = true,
["hasLoot"] = false,
["iconTexture"] = 134414,
["itemLink"] = "|cnIQ1:|Hitem:6948::::::::1:1491::75:::::::|h[Hearthstone]|h|r",
["quality"] = 1,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
{
},
{
},
{
},
{
},
{
},
{
{
},
{
},
{
},
{
},
},
},
["auctions"] = {
},
["currencyByHeader"] = {
{
["name"] = "Unknown",
["currencies"] = {
},
},
},
["money"] = 0,
["mail"] = {
},
["void"] = {
},
["currencies"] = {
},
["equipped"] = {
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 6125,
["isBound"] = false,
["iconTexture"] = 132719,
["itemLink"] = "|cnIQ1:|Hitem:6125::::::::1:1491::75:::::::|h[Brawler's Harness]|h|r",
["quality"] = 1,
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 139,
["isBound"] = false,
["iconTexture"] = 134582,
["itemLink"] = "|cnIQ0:|Hitem:139::::::::1:1491::75:::::::|h[Brawler's Pants]|h|r",
["quality"] = 0,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 37,
["isBound"] = false,
["iconTexture"] = 132402,
["itemLink"] = "|cnIQ1:|Hitem:37::::::::1:1491::75:::::::|h[Worn Axe]|h|r",
["quality"] = 1,
},
{
["itemCount"] = 1,
["itemID"] = 2362,
["isBound"] = false,
["iconTexture"] = 134955,
["itemLink"] = "|cnIQ1:|Hitem:2362::::::::1:1491::75:::::::|h[Worn Wooden Shield]|h|r",
["quality"] = 1,
},
{
["itemCount"] = 1,
["itemID"] = 3111,
["isBound"] = false,
["iconTexture"] = 132410,
["itemLink"] = "|cnIQ1:|Hitem:3111::::::::1:1491::75:::::::|h[Crude Throwing Axe]|h|r",
["quality"] = 1,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
["bank"] = {
},
},
},
["Guilds"] = {
["Peaked in Vanilla-CAMWOWUS2Realm4PvP"] = {
["money"] = 0,
["details"] = {
["show"] = {
["inventory"] = true,
["gold"] = false,
},
["guild"] = "Peaked in Vanilla",
["faction"] = "Horde",
["visited"] = false,
["realm"] = "CAMWOWUS2Realm4PvP",
},
["bank"] = {
},
},
["Peaked in Vanilla-CAMWOWUS2Realm8PvP"] = {
["money"] = 0,
["details"] = {
["show"] = {
["inventory"] = true,
["gold"] = false,
},
["guild"] = "Peaked in Vanilla",
["faction"] = "Horde",
["visited"] = false,
["realm"] = "CAMWOWUS2Realm8PvP",
},
["bank"] = {
},
},
},
["Version"] = 2,
["Warband"] = {
{
["money"] = 0,
["details"] = {
["inventory"] = true,
["gold"] = true,
},
["bank"] = {
},
},
},
}
SYNDICATOR_SUMMARIES = {
["Characters"] = {
["Pending"] = {
},
["ByRealm"] = {
["PvP"] = {
["Rondine Signalborn"] = {
["item:271668"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2934"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 18,
["equipped"] = 0,
["bank"] = 0,
},
["item:1370"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2504"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:257277"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:159"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 5,
["equipped"] = 0,
["bank"] = 0,
},
["item:1366"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:5469"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 6,
["equipped"] = 0,
["bank"] = 0,
},
["item:257945"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 3,
["equipped"] = 0,
["bank"] = 0,
},
["item:258882"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:255663"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
["item:2125"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:277114"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:7097"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:252028"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:257263"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:4540"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 11,
["equipped"] = 0,
["bank"] = 0,
},
["item:1181"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:252031"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 4,
["equipped"] = 0,
["bank"] = 0,
},
["item:279981"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:256935"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:7005"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:271665"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:264908"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:118"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 3,
["equipped"] = 0,
["bank"] = 0,
},
["item:2672"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2101"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2318"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 9,
["equipped"] = 0,
["bank"] = 0,
},
["item:4471"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2589"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 5,
["equipped"] = 0,
["bank"] = 0,
},
["item:263408"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:6948"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:252032"] = {
["auctions"] = 0,
["void"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
},
["Bidwick Signalborn"] = {
["item:139"] = {
["mail"] = 0,
["bags"] = 0,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:117"] = {
["mail"] = 0,
["bags"] = 4,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 0,
["bank"] = 0,
},
["item:37"] = {
["mail"] = 0,
["bags"] = 0,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:6948"] = {
["mail"] = 0,
["bags"] = 1,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 0,
["bank"] = 0,
},
["item:2362"] = {
["mail"] = 0,
["bags"] = 0,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:6125"] = {
["mail"] = 0,
["bags"] = 0,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:3111"] = {
["mail"] = 0,
["bags"] = 0,
["void"] = 0,
["auctions"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
},
},
},
},
["Guilds"] = {
["Pending"] = {
},
["ByRealm"] = {
},
},
["Version"] = 5,
["Warband"] = {
["Summary"] = {
{
},
},
["Pending"] = {
false,
},
},
}
