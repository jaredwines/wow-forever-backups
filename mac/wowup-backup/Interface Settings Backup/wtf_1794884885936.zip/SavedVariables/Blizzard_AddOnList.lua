
g_addonCategoriesCollapsed = {
}
