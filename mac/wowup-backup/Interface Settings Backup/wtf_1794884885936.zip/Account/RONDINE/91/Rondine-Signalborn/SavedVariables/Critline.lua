
CritlinePerCharDB = {
["namespaces"] = {
},
["profileKeys"] = {
["Rondine - CAMWOW US2 Realm 8 PvP"] = "Rondine - CAMWOW US2 Realm 8 PvP",
},
["profiles"] = {
["Rondine - CAMWOW US2 Realm 8 PvP"] = {
},
},
}
CritlineDiag = {
["log"] = {
"19:04:02 target (secret values) -> skipped: Combat values are secret",
"19:04:03 target (secret values) -> skipped: Combat values are secret",
"19:04:05 target (secret values) -> skipped: Combat values are secret",
"19:04:05 target (secret values) -> skipped: Combat values are secret",
"19:04:06 target (secret values) -> skipped: Combat values are secret",
"19:04:07 target (secret values) -> skipped: Combat values are secret",
"19:04:07 target (secret values) -> skipped: Combat values are secret",
"19:04:07 player (secret values) -> skipped: Combat values are secret",
"19:04:08 target (secret values) -> skipped: Combat values are secret",
},
["version"] = "v4.7.2",
["project"] = 18,
["steps"] = {
"OnInitialize",
"Files loaded: Templates, Core, UnitCombat, SpellList, FilterCore, FilterGUI, Splash, Display, Minimap, Reset, Announce, Advanced, Broker, Profiles",
"LibDualSpec ok",
"UnitCombat enabled",
"Tracking: UNIT_COMBAT",
"OnInitialize done",
},
["errors"] = {
},
["session"] = "2026-11-16 19:01:00",
["build"] = 16001,
}
