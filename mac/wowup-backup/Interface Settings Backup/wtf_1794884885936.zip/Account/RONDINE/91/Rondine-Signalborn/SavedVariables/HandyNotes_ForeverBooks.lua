
HandyNotes_ForeverBooksCharDB = {
["collected"] = {
["baxtan"] = true,
},
}
