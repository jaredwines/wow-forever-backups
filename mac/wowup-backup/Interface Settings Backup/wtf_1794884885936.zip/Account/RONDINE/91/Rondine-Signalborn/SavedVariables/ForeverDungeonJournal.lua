
ForeverDungeonJournalCharacterDB = {
["favouriteItems"] = {
},
["trackedDungeons"] = {
},
["trackerSlots"] = {
},
["rpgQuests"] = {
[5728] = true,
[959] = true,
[914] = true,
[1221] = true,
[1491] = true,
[962] = true,
},
["hearthSpot"] = {
["y"] = 0.6845757365226746,
["mapID"] = 1454,
["name"] = "Orgrimmar",
["x"] = 0.5419030785560608,
},
["flightPoints"] = {
["sun rock retreat, stonetalon mountains"] = true,
["grom'gol, stranglethorn"] = true,
["camp taurajo, the barrens"] = true,
["brackenwall village, dustwallow marsh"] = true,
["crossroads, the barrens"] = true,
["orgrimmar, durotar"] = true,
["undercity, tirisfal"] = true,
["tarren mill, hillsbrad"] = true,
["ratchet, the barrens"] = true,
["the sepulcher, silverpine forest"] = true,
["hammerfall, arathi"] = true,
["booty bay, stranglethorn"] = true,
["thunder bluff, mulgore"] = true,
},
["rpgKills"] = {
},
["runTracker"] = {
},
["flightPointsVersion"] = 2,
["hiddenDungeons"] = {
},
["journalMode"] = "gamer",
["runLog"] = {
["nextID"] = 2,
["runs"] = {
{
["deathTimes"] = {
1794532313,
},
["deaths"] = 1,
["lastSeen"] = 1794532320,
["endedAt"] = 1794532320,
["otherXP"] = 0,
["needs"] = {
},
["closed"] = true,
["dungeon"] = "Ragefire Chasm",
["kills"] = {
},
["created"] = 1794532313,
["id"] = 1,
["instanceName"] = "Ragefire Chasm",
["seenN"] = 0,
["exits"] = {
{
["why"] = "released",
["t"] = 1794532320,
},
},
["map"] = 389,
},
},
},
["arrowChains"] = {
},
}
