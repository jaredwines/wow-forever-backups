
OpenMapCharDB = {
["worldmap"] = {
["flightsKnown"] = {
["Sun Rock Retreat, Stonetalon Mountains"] = true,
["Booty Bay, Stranglethorn"] = true,
["Tarren Mill, Hillsbrad"] = true,
["Orgrimmar, Durotar"] = true,
["Undercity, Tirisfal"] = true,
["Ratchet, The Barrens"] = true,
["Hammerfall, Arathi"] = true,
["Grom'gol, Stranglethorn"] = true,
["Camp Taurajo, The Barrens"] = true,
["Crossroads, The Barrens"] = true,
["Thunder Bluff, Mulgore"] = true,
["Brackenwall Village, Dustwallow Marsh"] = true,
["The Sepulcher, Silverpine Forest"] = true,
},
["cvars"] = {
},
["flightsKnownV"] = 2,
},
}
