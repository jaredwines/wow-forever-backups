
ForeverCombatMeterChar = {
["active"] = "Default",
}
