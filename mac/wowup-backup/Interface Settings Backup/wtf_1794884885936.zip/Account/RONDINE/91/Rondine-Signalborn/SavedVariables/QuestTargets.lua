
QuestTargetsDB = {
["masterAppearance"] = "modern",
["minimapHidden"] = false,
["autoTargets"] = {
["locale"] = "enUS",
["entries"] = {
["821:1"] = {
["signature"] = "item:Savannah Lion Tusk",
["names"] = {
["Savannah Huntress"] = true,
},
},
},
},
["masterModernScale"] = 1,
["masterPosition"] = {
["y"] = -402.4996643066406,
["x"] = 91.666015625,
},
["ellesmereTrackerButtons"] = true,
["masterScaleY"] = 1,
["muteDeadTargetSound"] = false,
["masterScaleBaseline"] = 2,
["watchedOnly"] = false,
["transparencyMode"] = false,
["minimap"] = {
["minimapPos"] = 225,
["hide"] = false,
},
["ellesmereTrackerOffset"] = 0,
["autoMark"] = true,
["focusBindingsNative"] = true,
["markerIcon"] = 8,
["hidden"] = true,
["masterScaleX"] = 1,
["showTooltips"] = false,
["masterHidden"] = false,
["questieTrackerButtons"] = true,
["position"] = {
["y"] = 25.0001220703125,
["x"] = 1190.0029296875,
},
["restedXPIntegration"] = false,
["questieTrackerOffset"] = 35,
["menuScale"] = 1,
["masterText"] = "Target quest objective",
}
