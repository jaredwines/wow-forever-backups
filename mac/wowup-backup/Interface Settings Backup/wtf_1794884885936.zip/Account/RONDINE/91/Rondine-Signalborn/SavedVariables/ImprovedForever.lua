
ImprovedForeverCharDB = {
["nativeMacros"] = {
},
["recent"] = {
},
["wheels"] = {
},
["groupSpells"] = {
"spell:13163",
"spell:2641",
"spell:136",
},
["groupCast"] = 1,
}
