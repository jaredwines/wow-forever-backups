
QuestieAutomaticArrowDB = {
["showObjectiveProgress"] = true,
["panelShown"] = false,
["debug"] = false,
["panelPoint"] = {
"CENTER",
"CENTER",
0,
-160,
},
["prioritizeTurnins"] = true,
["excludePetBattleQuests"] = true,
["showQuestName"] = true,
["onlyTrackedQuests"] = true,
["showTargetName"] = true,
["throttle"] = 2,
["settingsVersion"] = 6,
["enabled"] = true,
["excludeScenarioQuests"] = true,
["excludeGroupContent"] = true,
["preferCurrentZone"] = true,
["overrideManual"] = false,
}
