
SpokenBossesCharacter = {
["storiesRead"] = {
},
["found"] = {
},
}
