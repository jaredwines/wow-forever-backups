
QuestieConfigCharacter = nil
