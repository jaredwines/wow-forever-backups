
ImprovedForeverDB = {
["combos"] = {
["L2"] = "emotes",
["L1"] = "quest",
["R1"] = "consumables",
["R2"] = "native",
["R3"] = "native",
},
["touch"] = {
["quarters"] = true,
["doublesReset"] = 2,
["downleftLTMoved2"] = true,
["upleftMoved"] = true,
["doubles"] = {
},
["layers"] = {
["RT"] = {
},
["LT"] = {
["downleft"] = "professions",
["upleft"] = "talents",
["upright"] = "questlog",
},
},
["regions"] = {
["downleft"] = "character",
["upleft"] = "character",
["downright"] = "bags",
["upright"] = "spellbook",
},
["downleftLTMoved"] = true,
},
["upgrades"] = {
["bags"] = true,
},
["keyBinds"] = {
},
["phraseChannel"] = 1,
["wheelKeys"] = {
},
["overrides"] = {
},
["emoteSlots"] = {
"emote:wave",
"emote:hello",
"emote:thank",
"emote:cheer",
"emote:dance",
"emote:laugh",
"emote:bow",
"emote:roar",
},
["keyActions"] = {
},
["recentSlotLayouts"] = {
["layout:WoW Forever Desktop"] = {
},
},
["menuTab"] = "general",
}
