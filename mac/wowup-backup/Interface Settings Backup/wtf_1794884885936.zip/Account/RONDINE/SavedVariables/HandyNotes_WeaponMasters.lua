
HandyNotes_WeaponMastersDB = {
["global"] = {
["setupDone"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
