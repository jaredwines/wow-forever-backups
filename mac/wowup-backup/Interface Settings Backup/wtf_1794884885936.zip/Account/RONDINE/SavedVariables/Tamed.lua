
__TAMED_ADDON_DB__ = nil
__TAMED_ADDON_V2_SAVED_VARIABLES__ = {
["npc_tooltips"] = true,
["minimapIcon"] = {
["hide"] = false,
},
}
