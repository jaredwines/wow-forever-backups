
CritlineDB = {
["namespaces"] = {
["display"] = {
["profiles"] = {
["Rondine - CAMWOW US2 Realm 8 PvP"] = {
["pos"] = {
["y"] = 24.33352279663086,
["x"] = 465.0005187988281,
["point"] = "BOTTOM",
},
},
},
},
},
["profileKeys"] = {
["Rondine - CAMWOW US2 Realm 8 PvP"] = "Rondine - CAMWOW US2 Realm 8 PvP",
},
["profiles"] = {
["Rondine - CAMWOW US2 Realm 8 PvP"] = {
},
},
}
