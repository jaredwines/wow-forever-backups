
TalentsForeverBookDB = {
["prices"] = {
},
["version"] = 1,
["settings"] = {
["cards"] = false,
["path"] = true,
["noTrainer"] = {
["Thunder Bluff|WARLOCK"] = true,
},
["scale"] = 1,
["marks"] = false,
["minimap"] = {
["minimapPos"] = 200,
["angle"] = 200,
["hide"] = false,
},
["sounds"] = true,
["starter"] = false,
["repliesSeen"] = "2026-10-05",
["popFor"] = {
},
["talentsKey"] = false,
["autoApplyChosen"] = true,
["greetedVersion"] = "0.38.28.20261116",
["autoApply"] = false,
["trainerAlerts"] = true,
["trainAll"] = true,
["seenIntro"] = true,
["trainerAlertsSet"] = true,
["overlay"] = true,
["levelUpNudge"] = true,
["showPlan"] = true,
["pickRates"] = false,
["motes"] = true,
["sideTab"] = "builds",
},
["addon"] = "0.38.28.20261116",
["builds"] = {
},
["sent"] = {
},
["diag"] = {
["loaded"] = {
["Blizzard_TimeManager"] = "19:07:12",
["Blizzard_GroupFinder_VanillaStyle"] = "19:07:12",
["Blizzard_CombatLog"] = "19:07:12",
["Blizzard_ProfessionsTemplates"] = "19:06:43",
["Blizzard_Settings"] = "19:01:17",
["Blizzard_Professions"] = "19:06:43",
["Blizzard_ProfessionsBook"] = "19:06:43",
["Blizzard_BattlefieldMap"] = "19:07:12",
},
["framesSeen"] = {
},
},
["chars"] = {
["Rondine-CAMWOW US2 Realm 8 PvP"] = {
["plan"] = {
["orderKnown"] = true,
["cls"] = "HUNTER",
["cv"] = "12",
["level"] = 60,
["order"] = {
{
1,
1,
},
{
1,
1,
},
{
1,
1,
},
{
1,
1,
},
{
1,
1,
},
{
1,
3,
},
{
1,
3,
},
{
1,
5,
},
{
1,
5,
},
{
1,
2,
},
{
1,
6,
},
{
1,
6,
},
{
1,
7,
},
{
1,
8,
},
{
1,
8,
},
{
1,
11,
},
{
1,
8,
},
{
1,
8,
},
{
1,
10,
},
{
1,
10,
},
{
1,
10,
},
{
1,
13,
},
{
1,
14,
},
{
1,
14,
},
{
1,
10,
},
{
1,
10,
},
{
1,
15,
},
{
1,
15,
},
{
1,
15,
},
{
1,
15,
},
{
1,
16,
},
{
2,
3,
},
{
2,
3,
},
{
2,
3,
},
{
2,
3,
},
{
2,
3,
},
{
2,
6,
},
{
2,
6,
},
{
2,
6,
},
{
2,
6,
},
{
2,
6,
},
{
2,
7,
},
{
2,
7,
},
{
2,
1,
},
{
2,
1,
},
{
2,
1,
},
{
2,
10,
},
{
2,
11,
},
{
2,
11,
},
{
2,
11,
},
{
2,
11,
},
},
["ranks"] = {
{
5,
1,
2,
0,
2,
2,
1,
4,
0,
5,
1,
0,
1,
2,
4,
1,
},
{
3,
0,
5,
0,
0,
5,
2,
0,
0,
1,
4,
0,
0,
0,
0,
0,
},
{
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
},
},
},
["talented"] = 0,
["shelf"] = {
["HUNTER"] = {
},
},
["planNames"] = {
["HUNTER"] = "Leveling",
},
["toldSpells"] = {
["Eyes of the Beast|1"] = true,
["Eagle Eye|1"] = true,
["Track Undead|1"] = true,
["Scare Beast|1"] = true,
},
},
},
}
