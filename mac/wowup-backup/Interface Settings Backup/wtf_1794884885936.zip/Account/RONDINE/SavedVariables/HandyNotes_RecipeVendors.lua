
HandyNotes_RecipeVendorsDB = {
["global"] = {
["setupDone"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["mine"] = true,
},
},
}
