
HandyNotes_ProfessionTrainersDB = {
["global"] = {
["setupDone"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["mine"] = true,
},
},
}
