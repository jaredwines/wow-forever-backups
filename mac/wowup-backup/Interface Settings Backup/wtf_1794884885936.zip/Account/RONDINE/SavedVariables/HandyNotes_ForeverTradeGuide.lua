
HandyNotes_ForeverTradeGuideDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["only_my_professions"] = true,
},
},
}
