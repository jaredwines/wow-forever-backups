
ForeverCombatMeterProfiles = {
["profiles"] = {
["Default"] = {
["minimapAngle"] = 294,
["threatWarn"] = true,
["windows"] = {
{
["y"] = -982,
["x"] = 268,
["point"] = "TOP",
["locked"] = true,
["view"] = "overall",
},
{
["y"] = -983,
["x"] = -271,
["point"] = "TOP",
["locked"] = true,
["mode"] = "threat",
["view"] = "overall",
},
},
["locked"] = true,
["windowCount"] = 2,
["minimapShow"] = false,
["themeSets"] = {
["seedRevision"] = 0,
["revision"] = 15,
["comicGreyPinned"] = true,
["themeColors"] = {
},
},
},
},
}
