
TomTomDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["arrow"] = {
["arrival"] = 9,
["lock"] = true,
["theme"] = "classic",
["scale"] = 0.9500000476837158,
["stickycorpse"] = true,
["position"] = {
"BOTTOM",
nil,
"BOTTOM",
2.411833047866821,
179.9570922851563,
},
["alpha"] = 0.9500000476837158,
},
["worldmap"] = {
["create_modifier"] = "C",
},
["block"] = {
["enable"] = false,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-75.83352661132812,
-291.6669006347656,
},
},
["paste"] = {
["button"] = {
["showInCompartment"] = true,
},
["autoclose"] = true,
},
},
},
}
TomTomWaypointsM = {
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["global"] = {
["pinFlagsLive"] = true,
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
