
AKForeverBagsDB = {
["diag"] = {
["savedStateSource"] = "none (first run, or the client did not load it)",
["log"] = {
{
["d"] = "backpack key(s) B F12 -> Open All Bags",
["k"] = "keys",
["t"] = 14668.442,
},
{
["d"] = "Blizzard's place (its action bars are on the screen)",
["k"] = "bagbar",
["t"] = 14668.442,
},
{
["d"] = {
["loads"] = 1,
["character"] = "Rondine Signalborn - CAMWOWUS2Realm8PvP",
["savedState"] = "none (first run, or the client did not load it)",
["version"] = "0.5.1",
},
["k"] = "login",
["t"] = 14668.442,
},
{
["d"] = "bags closed",
["k"] = "reagents",
["t"] = 14668.442,
},
},
["addonVersion"] = "0.5.1",
["errors"] = {
},
["unknownEvents"] = {
},
["character"] = "Rondine Signalborn - CAMWOWUS2Realm8PvP",
["sort"] = {
["state"] = "idle",
["stats"] = {
["movesThisRun"] = 0,
["rounds"] = 0,
["filled"] = 0,
["runs"] = 0,
["stopped"] = 0,
["filledThisRun"] = 0,
["moves"] = 0,
},
["hooked"] = true,
["pins"] = {
},
["follow"] = true,
["pouch"] = "none",
},
["performance"] = {
["metricsMs"] = {
["SessionAverageTime"] = 0.000491995544239338,
["CountTimeOver100Ms"] = 0,
["CountTimeOver5Ms"] = 0,
["RecentAverageTime"] = 0.0001983333333333334,
["CountTimeOver1Ms"] = 2,
["EncounterAverageTime"] = 0,
["CountTimeOver10Ms"] = 0,
["CountTimeOver500Ms"] = 0,
["PeakTime"] = 1.963,
["LastTime"] = 0,
["CountTimeOver50Ms"] = 0,
["CountTimeOver1000Ms"] = 0,
},
["memoryKB"] = 248.494140625,
["profilerEnabled"] = true,
},
["capturedAt"] = "2026-11-16 18:51:39",
["build"] = {
["toc"] = 16001,
["date"] = "Nov 12 2026",
["version"] = "1.60.1",
["build"] = "70938",
},
["options"] = {
["bagBar"] = "window",
["bagBarShown"] = true,
["reagentsShown"] = true,
["backpackKeyOpensAll"] = true,
["merge"] = true,
},
["layout"] = {
},
["inCombat"] = false,
["windows"] = {
["ContainerFrameCombinedBags"] = {
["strata"] = "MEDIUM",
["itemButtons"] = 0,
["shown"] = false,
["samples"] = {
},
["width"] = 338,
["protected"] = false,
["scale"] = 1,
["anchor"] = {
["relativeTo"] = "nil",
},
["level"] = 1,
["height"] = 424,
["bag"] = 0,
},
["ContainerFrame6"] = {
["strata"] = "MEDIUM",
["itemButtons"] = 0,
["shown"] = false,
["samples"] = {
},
["width"] = 256.0000305175781,
["protected"] = false,
["scale"] = 1,
["anchor"] = {
["relativeTo"] = "nil",
},
["level"] = 2,
["height"] = 256.0000305175781,
["bag"] = 0,
},
["AKForeverBagsReagentSlots"] = "absent",
},
["bagBar"] = {
["state"] = "Blizzard's place (its action bars are on the screen)",
["hooks"] = {
["UpdateContainerFrameAnchors"] = true,
["ContainerFrame_ClearFullScreenFrame"] = true,
["EditModeManager.UpdateBottomActionBarPositions"] = true,
["ContainerFrame_SetFullScreenFrame"] = true,
},
["moved"] = {
},
["shown"] = true,
["mode"] = "window",
["inDefaultPosition"] = false,
["arrow"] = false,
},
["reagents"] = {
["state"] = "bags closed",
["moved"] = 0,
["combinedSetting"] = "1",
["keys"] = "B F12",
["hooks"] = {
["anchors"] = true,
["size"] = false,
},
["raises"] = 0,
["orderWanted"] = "bottom",
},
["blockedActions"] = {
},
["savedVariableLoads"] = 1,
["work"] = {
["layoutMs"] = 0.01630000025033951,
["slowestLayoutMs"] = 0.01630000025033951,
["layoutPasses"] = 1,
["raisesOnClicks"] = 0,
},
["header"] = {
["titleBar"] = {
["visible"] = false,
["strata"] = "MEDIUM",
["parent"] = "ContainerFrameCombinedBags",
["shown"] = true,
["level"] = 510,
["anchor"] = {
["y"] = -1.00000011920929,
["relativeTo"] = "ContainerFrameCombinedBags",
["point"] = "TOPLEFT",
["relativePoint"] = "TOPLEFT",
["x"] = 35,
},
["width"] = 0,
},
["sortButton"] = {
["visible"] = false,
["strata"] = "MEDIUM",
["parent"] = "ContainerFrame1",
["shown"] = false,
["level"] = 3,
["anchor"] = {
["relativeTo"] = "nil",
},
["width"] = 28.00000190734863,
},
["columnsImplied"] = 8,
["searchBox"] = {
["visible"] = false,
["strata"] = "MEDIUM",
["parent"] = "ContainerFrame1",
["shown"] = false,
["level"] = 3,
["anchor"] = {
["relativeTo"] = "nil",
},
["width"] = 149.9999847412109,
},
["backdrop"] = "absent",
["portrait"] = {
["visible"] = false,
["strata"] = "MEDIUM",
["parent"] = "ContainerFrameCombinedBags",
["shown"] = true,
["level"] = 400,
["anchor"] = {
["y"] = 0,
["relativeTo"] = "ContainerFrameCombinedBags",
["point"] = "TOPLEFT",
["relativePoint"] = "TOPLEFT",
["x"] = 0,
},
["width"] = 1.00000011920929,
},
},
["bagSlots"] = {
["1"] = 12,
["0"] = 20,
["3"] = 8,
["2"] = 8,
["5"] = 6,
["4"] = 8,
},
["labels"] = {
["markMode"] = false,
["menu"] = false,
["active"] = "off",
["button"] = false,
["borders"] = 0,
["labelled"] = 0,
["auto"] = true,
},
},
["loads"] = 1,
["schema"] = 1,
["chars"] = {
["Rondine Signalborn - CAMWOWUS2Realm8PvP"] = {
["options"] = {
},
},
},
}
