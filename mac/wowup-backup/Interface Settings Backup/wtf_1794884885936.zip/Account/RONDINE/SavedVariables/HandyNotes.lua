
HandyNotesDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
HandyNotes_HandyNotesDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
