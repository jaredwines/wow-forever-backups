
ForeverFlightTimeAccountDB = {
["routes"] = {
["id:80:23"] = {
["sourceName"] = "Ratchet, The Barrens",
["history"] = {
210.2310000000007,
},
["destID"] = 23,
["destName"] = "Orgrimmar, Durotar",
["sourceID"] = 80,
["samples"] = 1,
["duration"] = 210.2310000000007,
["last"] = 1794344876,
},
["id:55:22"] = {
["duration"] = 224.9170000000013,
["last"] = 1794353815,
["destID"] = 22,
["destName"] = "Thunder Bluff, Mulgore",
["sourceName"] = "Brackenwall Village, Dustwallow Marsh",
["sourceID"] = 55,
["samples"] = 1,
["history"] = {
224.9170000000013,
},
},
},
["position"] = {
},
["inFlights"] = {
["Rondine-Signalborn"] = {
["earlyLanding"] = false,
["sourceName"] = "Crossroads, The Barrens",
["destID"] = 23,
["destName"] = "Orgrimmar, Durotar",
["sourceID"] = 25,
["startClock"] = 1794376594,
["routeKey"] = "id:25:23",
},
},
["mergedChars"] = {
["Rondine-Signalborn"] = true,
},
["locked"] = false,
}
