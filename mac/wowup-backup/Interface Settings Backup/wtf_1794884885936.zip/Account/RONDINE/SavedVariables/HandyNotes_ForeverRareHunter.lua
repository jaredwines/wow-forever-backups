
HandyNotes_ForeverRareHunterDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
