
MuddyBootsDB = {
["chars"] = {
["Player-6934-0043A935"] = {
["played"] = 212352,
["stats"] = {
["played"] = 212347,
["hardcore"] = false,
["class"] = "HUNTER",
["data"] = {
["deaths"] = {
["zones"] = {
},
["total"] = 76,
["rev"] = {
["heal"] = 0,
["run"] = 0,
["pl"] = 0,
},
["how"] = {
["df"] = 2,
["dp"] = 0,
["dd"] = 0,
["dw"] = 2,
["dh"] = 0,
["cr"] = 72,
},
["rows"] = {
["hh"] = {
["v"] = "--",
},
["ls"] = {
["vd"] = "58h 59m (levels 1 to 20)",
["tip"] = {
"Levels 1 to 20 (Nov 4 to Nov 16)",
},
["v"] = "58h 59m",
},
["ws"] = {
["v"] = "0",
},
["td"] = {
["v"] = "0m",
},
["wl"] = {
["v"] = "0",
},
["cc"] = {
["v"] = "0",
},
["dt"] = {
["v"] = "76",
},
},
["enemies"] = {
},
},
["spells"] = {
["ic"] = {
},
["io"] = {
},
["sc"] = {
{
"Raptor Strike",
1,
},
},
["so"] = {
{
"Walk on Air",
2,
},
{
"LOGINEFFECT",
1,
},
{
"Shen'dorei Windwell",
1,
},
{
"Summon Pachimari",
1,
},
{
"Summon Panda",
1,
},
},
["rows"] = {
["cm"] = {
["v"] = "1",
},
["mf"] = {
["tip"] = {
"Zephras Isle (11s)",
"Nov 4",
},
["cmp"] = "Zephras Isle (11s), Nov 4",
["v"] = "1",
},
["po"] = {
["v"] = "51",
},
["ds"] = {
["v"] = "6",
},
["iu"] = {
["v"] = "121",
},
["fd"] = {
["v"] = "48",
},
["sc"] = {
["v"] = "7",
},
["tc"] = {
["v"] = "0m",
},
["dl"] = {
["v"] = "1",
},
["bd"] = {
["v"] = "22",
},
["el"] = {
["v"] = "0",
},
["fl"] = {
["v"] = "0",
},
},
},
["travel"] = {
["zones"] = {
{
"The Barrens",
209960,
},
{
"Zephras Isle",
2379,
},
["keepAll"] = true,
},
["played"] = 212347,
["dist"] = {
["tram"] = 0,
["portal"] = 0,
["ghost"] = 0,
["ride"] = 0,
["swim"] = 0,
["boat"] = 0,
["fly"] = 0,
["foot"] = 2179,
["hearth"] = 0,
},
["sessions"] = 2,
["rows"] = {
["zones"] = {
["v"] = "2",
},
["played"] = {
["v"] = "58h 59m",
},
["jump"] = {
["v"] = "7",
},
["afk"] = {
["v"] = "14m",
},
["long"] = {
["v"] = "19m",
},
["camp"] = {
["v"] = "38",
},
["boat"] = {
["tip"] = {
"Boats 0, Zeppelins 0",
},
["cmp"] = "(Boats 0, Zeppelins 0)",
["v"] = "0",
},
["port"] = {
["tip"] = {
"Mage portals 0, Warlock summons 0",
},
["cmp"] = "(Mage portals 0, Warlock summons 0)",
["v"] = "0",
},
["sess"] = {
["v"] = "2",
},
["hs"] = {
["v"] = "23",
},
["fl"] = {
["v"] = "31",
},
},
["afk"] = 846,
},
["dungeons"] = {
["r"] = {
},
["pr"] = {
},
["d"] = {
},
["rows"] = {
["rlf"] = {
["v"] = "--",
},
["dlf"] = {
["v"] = "--",
},
["rc"] = {
["v"] = "0",
},
["dc"] = {
["v"] = "0",
},
["rbk"] = {
["v"] = "0",
},
["dbk"] = {
["v"] = "0",
},
},
["pd"] = {
},
},
["kills"] = {
["bossD"] = {
},
["types"] = {
{
"Beast",
20,
},
},
["rows"] = {
["ra"] = {
["v"] = "0",
},
["rb"] = {
["v"] = "0",
["tip"] = {
"0 raid runs.",
},
},
["pk"] = {
["v"] = "0",
},
["ck"] = {
["v"] = "3",
["tip"] = {
"Hunter pets count.",
},
},
["db"] = {
["v"] = "0",
["tip"] = {
"0 runs.",
},
},
["el"] = {
["v"] = "0",
},
["cr"] = {
["v"] = "1,102",
["tip"] = {
"1,041 of them gave XP.",
},
},
},
["bossR"] = {
},
["enemies"] = {
{
"Juvenile Vuldren",
10,
nil,
"Zephras Isle",
},
{
"Pesky Cirrusfly",
10,
nil,
"Zephras Isle",
},
},
},
["loot"] = {
["es"] = {
},
["nd"] = {
0,
0,
},
["eq"] = {
},
["gr"] = {
0,
0,
},
["rows"] = {
["tr"] = {
["v"] = "0",
},
["ra"] = {
["v"] = "0",
},
["il"] = {
["v"] = "0",
},
["ep"] = {
["v"] = "0",
},
["un"] = {
["v"] = "0",
},
["rw"] = {
["v"] = "0",
},
["pr"] = {
["v"] = "0",
["nocmp"] = true,
},
},
["pieces"] = 0,
},
["gold"] = {
["ob"] = {
},
["s"] = {
["cls"] = 10,
},
["money"] = 3516,
["e"] = {
["quest"] = 50,
},
["rows"] = {
["ts"] = {
["v"] = "10c",
},
["te"] = {
["v"] = "50c",
},
["gh"] = {
["vd"] = "35s 16c (35s 16c, 1 character)",
["cmp"] = "35s 16c",
["tip"] = {
"Rondine: 35s 16c",
},
["v"] = "35s 16c",
},
["bp"] = {
["vd"] = "35c (Quests)",
["tip"] = {
"Quests: Infestation Investigation (Nov 4)",
},
["v"] = "35c",
},
["mh"] = {
["vd"] = "4g 34s",
["v"] = "4g 34s",
["nocmp"] = true,
},
["bpu"] = {
["vd"] = "10c (Track Beasts)",
["tip"] = {
"Track Beasts, Class skills (Nov 4)",
},
["v"] = "10c",
},
},
["best"] = {
},
["accountLines"] = {
"Rondine: 35s 16c",
},
},
["prof"] = {
["top"] = {
},
["cur"] = {
},
["ab"] = {
},
["chart"] = {
},
["made"] = 0,
["gathered"] = 0,
},
["guilds"] = {
["guilds"] = {
},
["played"] = 212347,
["level"] = 20,
},
["leveling"] = {
["top"] = 19,
["played"] = 212347,
["lzones"] = {
{
"The Barrens",
18,
"3–20",
},
{
"Zephras Isle",
1,
"2",
},
["keepAll"] = true,
},
["act"] = {
{
["dungeon"] = 0,
["combat"] = 52,
["travel"] = 194,
["afk"] = 0,
["town"] = 544,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 252,
["afk"] = 846,
["town"] = 210455.809,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
{
["dungeon"] = 0,
["combat"] = 0,
["travel"] = 0,
["afk"] = 0,
["town"] = 0,
["dead"] = 0,
},
["keepAll"] = true,
},
["xpTotal"] = 949,
["rows"] = {
["mxs"] = {
["vd"] = "839 (Nov 4)",
["tip"] = {
"Levels 1 to 2, Nov 4",
},
["v"] = "839",
},
["axp"] = {
["v"] = "16",
},
["days"] = {
["v"] = "12",
["vd"] = "12 (Nov 4 to Nov 16)",
},
["mdl"] = {
["vd"] = "12 days (level 2)",
["tip"] = {
"Level 2 (Nov 4 to Nov 16)",
},
["v"] = "12 days",
},
["atl"] = {
["v"] = "3h 06m",
},
["rxs"] = {
["v"] = "0%",
["tip"] = {
"About 0 of 949 XP",
},
},
["bxp"] = {
["vd"] = "949 (level 1)",
["tip"] = {
"Level 1, Zephras Isle (Nov 4)",
},
["v"] = "949",
},
["lsl"] = {
["vd"] = "19m (level 2)",
["tip"] = {
"Level 2 (Nov 4)",
},
["v"] = "19m",
},
},
["xp"] = {
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 40,
["kill"] = 343,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 530,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
{
["dungeon"] = 0,
["explore"] = 0,
["quest"] = 0,
["kill"] = 0,
},
["keepAll"] = true,
},
["lt"] = {
790,
211553.809,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
["keepAll"] = true,
},
},
["pvp"] = {
["ng"] = {
},
["kb"] = {
},
["dw"] = {
},
["rows"] = {
["tq"] = {
["v"] = "--",
},
["rk"] = {
["v"] = "--",
["tip"] = {
"No rank yet.",
},
},
["wk"] = {
["v"] = "0",
},
["rx"] = {
["v"] = "--",
["tip"] = {
"No rank yet.",
},
},
["hk"] = {
["v"] = "0",
},
["tb"] = {
["v"] = "0m",
},
["bk"] = {
["v"] = "0",
},
["ho"] = {
["v"] = "0",
},
["mb"] = {
["v"] = "0",
},
},
["tg"] = {
},
["duels"] = {
},
["worldKills"] = 0,
["faction"] = "Horde",
["db"] = {
},
["kw"] = {
},
["worldDeaths"] = 0,
["bgs"] = {
},
},
},
["v"] = 2,
["race"] = "Skyborne",
["name"] = "Rondine",
["level"] = 20,
["money"] = 3516,
},
["hardcore"] = false,
["guid"] = "Player-6934-0043A935",
["money"] = 3516,
["class"] = "HUNTER",
["preview"] = {
[2521] = "4281,2321;4306,2766;4656,2630;4333,2434|4334,2434;4376,2406|4377,2407;4429,2553;4723,2191",
},
["first"] = {
["y"] = 2314,
["x"] = 4281,
["m"] = 2521,
["t"] = 1793834366,
["level"] = 1,
},
["sex"] = 2,
["race"] = "Skyborne",
["name"] = "Rondine",
["faction"] = "Horde",
["pins"] = {
{
["y"] = 2478,
["x"] = 4342,
["k"] = "level",
["m"] = 2521,
["l"] = 2,
},
},
["level"] = 20,
["lastSeen"] = 1794884394,
["realm"] = "CAMWOW US2 Realm 8 PvP",
},
},
["settings"] = {
["shareSelfBars"] = false,
["colorblind"] = true,
["statsBar"] = "meter",
["recordRate"] = 2,
["saveReminder"] = true,
["lowHealthFlash"] = true,
["slimming"] = "medium",
["tool"] = {
["gear"] = true,
["zoom"] = "in",
},
["computerName"] = "Blastoise",
["gearWeapon"] = "auto",
["unexplored"] = false,
["distance"] = "auto",
["markers"] = {
["dungeon"] = true,
["pvp"] = true,
["loot"] = true,
["death"] = true,
["mount"] = true,
["level"] = true,
["worldboss"] = true,
["big"] = {
["dun"] = true,
["boss"] = true,
["loot"] = true,
["death"] = true,
["mount"] = true,
["level"] = true,
["pvp"] = true,
},
},
["shareCard"] = {
},
["bigMapHidden"] = true,
["awaySave"] = true,
["reminderPos"] = false,
["trailColor"] = "single",
["shots"] = {
["lastBoss"] = false,
["level"] = false,
},
["minimapButton"] = true,
["newZoneSave"] = true,
},
["errors"] = {
},
["schema"] = 1,
["computer"] = "60249f",
["backups"] = {
["Player-6934-0043A935"] = {
["played"] = 212352,
["name"] = "Rondine",
["blob"] = "7ZtNjGTXVYCnZvyDx0KKkIW6IyWu4ATsZMZ+/z9dlEhPd1V32+OZyfx4Klnxpup1d7mr32u/V93jNk8RAiEWsEFiwSpS7HF+FBZsQEIKJh6LoLAABEECCcTKKyQ2JALJKPCd+37qdXVVd8fOBpREnq5T9/zdc88599xzb31z434yHI/D6MphR3tef95aT8M0HcZR+jtfW9sbBYfhQDu3OgrS8cdf/bc/e7iyHd/vjOKtYbTej3f39sdh0nU0w/I3C2R9odtJx0Gi0L9csVh4seTxTlt4dJNwFAeDaSYT0u9V/L4zYfIXFZOvnMCkpFxsfKri985KxWWx8ZmKzV+fwGZC+2DC8Qs1Nq9UbP71BDYT2v6E4/drbDZLNu/+1wlsJrTvVxwfyR7UKEo2D8/Nteq7P5rIfeS3K4K9Gpe5tA8fncj9jxqb/yzZfPdvTmBT0T5xq5rJw/0Z6n/w3tMlwgfvfWJam0rux89daN8vJH/w3jNnkCwUvzZh/cxqfztIvrW6tT8c3L4hfp5cdnzTuqxplrnsm3anj9On3fU71253bnaSMBjtvrKy/PLd63ebd24ZzZvyRdNr3ji4sTEIg/H29b0w+sFqEvTD9Vs7h/fiJApXo2A3XLsZR4NhFK6k4evn1zaD/pjg6qzHySDsjMKDcPRUZ3OYpOO3lw8Xn7i4/Prix/50eXfxiX9aziMox2mspfuJcHvx1nArCkbCvjNOguHozeWDRre/vR/tpL/79nIqQfrlGv1vLA9e1i5ZhqdfMkzdunR5OWoUaN+rof3VXLR3ViZo76zW0Qy9xu2dBzW0B/PRvl9D+4f5aO/X0N5fHnzxiUerSYjYllNOybRahgHg2MzPdluGBWALYDEiaKYpgNMyBc3yARyjZQqaIzZx3JYpaI4GYOst0xM0VwCjZYlUywEw9JalGHgAptuyhIEpDGyzBYZl6AaA5bdsAbQSgJvuK92MFiJAKxR1hJshABq4wk0J9ZyWq9SxLhmWbrRcUcdFHShbnjIC80HdlgcDU4OBxUw9GJgGU7AcreXBwGSGcHRbHgxMS2hcv+ULjSloNoDQiDoWdvNFqChqYSpdqyDbAxIWGpazPKOl6yhhymRtXQcSjjr62UKHg6EGXGxPxpQeiHZ0GRMushgORtLRFUws62CVPrApfKB0XJv11WGCTMZdzQVyBWLUtUwgvxxz4GvKGItruAqSMZtFch00t3QgD5muiz5YAUh4uobItEQGJhEYCD6WzMR14YqjWBaOYbg2kA0lqAIp7fgXOwlfkWkLpQRYjiuUSoqtZoaXWZaSYjBviIBkJhr64bWWrQkfzZVZO3CyxSr5KJxsHM1wcQTdhY/tKAiZLnxsmRk5C0j4eGI9z5eZefBxhK+DY8CXb3PYxYt0XzgpjUxo/Qkn9EM1xvAQR6zgiz6irSNW8EWfAkKKgUtM4MstQ4evgwuwwg4QfB2iCVoPCL4OBgfShRZDMyowSye0oiGuBQw2MY6+WNSx9JYhGjrifw6rL05qOSAY/AMkfBRf0wYSLgQgXLSWCQPGWF/xPxNzQIdE2/eBSi4yoX5LXC/nKvBlskA5cxv7mmI/mwXAr+2WqewnOcZ2BRL7iUybTGCKdjZpg3hAA2U/UpJhO2QWZT/JDDZxaYl2BBSQLxBcMCa6ajYQXCwcG83JLvgGnllobonVRYySbonNTTIG0slQYnNTuNgGdDKnPPR9CwgueVbwfCDhIhnH8jQym2BKbFoudCraxG6W67WIShlDgkWU8AlIop/VAoLOwBwqa4jCJCbBZO7oL5lLIBN5EmuGjzcQVECiC3kbCC4Sa7kuRIiFf4AjmulIl8gzxbPREUj0lFQPLyDhIvGRjwkXpacBncSZygrMFEjNT+RJUpcoyxOfA09H6MRr0ahlSZSpvCSQOF2RY9HTEVsbOAaaWUAyI4HwByCZOxnVMFlbR1mX9McYmOLNlS6OynTiPaK1OGS+fqwkkGhGxmYM6SrPEejKno5aBzV3HTq1DgQ3uphAiotohuUdlRHVOmBBh7RVWFC0zjOiYOIhEjhIl/XDSo5aFSWBnOvYksvZfgxLg062KzPniWaO5HK1RhpcZMMyxedlZ3XUjkXAsDNCp7YsiXPZTh3ZsyRtAGktl1BAroLY6DTkGeIT+ZjsQLJtkcwZQx7+B+RCJ/tKvl+To1zZVwzxEJMNzlX7CugFJFpjRtYBCVIbsHcLBJ0hc2AxDGKdDVjmACs1W9eSMbW3kkdc8jgQXMgQQMJTopikDiRaSwTYmkCimczd8oVOaaYwLXZ1tXkjgYQPJJZQUcw+wC5SSpAZKeuKZuKtrivSVWya1nK08HZevb37o0mF9O7/5IVUHt1s/JMi7+GjE7SHjy0Pen+ruClvl51Bahq1zYrDqZomj9G8pqHqQQmDYBZ7SJaVKkSZgyjNAWGQe5DRUi6jAsRwVR1kElysIoAwUGhMVyyh9uE8AgCYMWi4tfI5sZigiVFki5NgVzZhm8NTbfxBuElq0Zzl6GO5RY5M9WZhEVU5yd5alb1H0G7PR9uvGe6ACrTxXSVUIkft1cqZlHYEixSNKu+qbFOZWJKU2EeqCouV9TEu5hbIt6mrNMEUN7OlGNAkHgqfYLfVpAjLXRIH1TVVd0mdo+ouTRVeLAWgGhXLSUVik19BVrZjmdmZBESuqM0+RCWhSZAgSUYpADQpoCUJQ0t1wGEeUBYuFyRFtKUWVakhYWOr0FCsKCbxUuVPMgUpsm1VbZJsAGFli1Ym8QAIK/ZMQFVWitVsyWGEIaNSbDuYxCCPCggrtc9T9AkIK7WZo6WAsHKEM9W4gLByJAkYSq64qCQUw9Bk+hKyrgQUpQ8h9LRyGE6XLPGjvyXnrA/e+2TuCS4bATnbVA7T2RwFW+mDa6P4/jqnvfF2lxPh9g9fuh+O6H2Et8Iw+uGNNBxtduP9aLA8Ai8c/GCdY+WgHyfhD1bTKNj7/W90aIeM096Cbzhtq+WbehuHMf02K8E5oW138y7LubVxMAqjcXpuXRFci+/Pp1ndCoOkt6Rdkv9TH0pGrj4SGPKNrb7JUdSYRs0nDoNhtI17YTruDre2xw86yO+HV78U7m0nQdrcSEdyVu0/qQ6gf/4VIqeb7gxHo/SLjeBuGOzFUfOWgpeuxPfTtvWC3VpOduOkeSOJN4f9YRjxX7q0MorH2239Bb11lGg12NoKk5xuaiTcDKM0VByvBtHWfrAFn/LTUnM14AhMbyqI2qamvcB/rXKwjnY96Q/T7Qpllm5X5cAeJkq7FTnmlzN6OUh20t0gSreHe8dHb+0nB8ODYDRjVrfuc6BPGbCnpnv7fnx5PYgG4aA5F+dOFCS74UCoV/YO9r6+Md5OwnQ7Hg0Wz//7i6PhZjge7obrL53rjIfjUbi+MjwYjjDDi9txFCe3YxznXHcvHorzrG2zqKztOVoR0c65Pyy8a/HCz6++EUdHl7mzyzeHC8+olf7O73X6dPnSRztqcd9aG+xHW2EcIVQEPHXl9b2fm3jm67rmtuUwwYbaVn8cwOazV0Lh8Rynba9ta302QVP9pabK/5qW+quTUto2B9JjMcGhQzHWfU/+8i+J0+afPFqKaMrlk1Tq8rWj8k07ly9/Rb76i3z5e4p8GCv5msg3RH4ZrR858qpg2jrq/UUw6dqHjCYIjzJcrcKJoVmB8n8ino5Na1ZAHUOaRJSu0WpOx+Hg3E86tN5c2Qr2Gvn28cz/N+CbeZx98fwCm65htDmVS8TT/SEQJOaoXzhttTltN59d3ydlxsPBc+B4bU7BEvxbTddJm6aex6DlpU2DMDTNtmvwdRGRW00fJIeA9HW/zUeXnEHF3mZFaVSJWJMN0zRT/holgm/obR1SuNByIrHocBRCgtvaappW2vQsxihM2hxoddcifmlJeHrbUaAn/HUbkToHET6QZKRHRbGSf7A1vY1ovudfpBls3AAc4i2rTalM3wuW5JurdHaj5hUSPJsVaQ9JlqQ1dAVwhNxy25zK6CHBm7+upbUtONgWk6DmhZUkFx2+eVbK+0+e11ZFouX5fLCaz74UjIa7gzh5rpY0qYV1yiXRSxUUPjYiGUsKZaWEN+mL6oijpdaWAhSIopR0pv4UU/GLWoRpSpLF6nmu5WRJQ7NNUUiTs53XaIq/5pCP11SVkrv/Z6uN4acO81OHmeMwRaZUWTPfRa/mxWlRv1py3ucf5xJncznncPCz5TNHTV9OezSOOdnnNBxVrEt0TxxgWw7nWlk+P1lUPNz3PPX3P+mc3+1T6o/TP1qXa5yD4fjwW91xfD9a0hcbP1rnPobrnCVj4b9B270XjBesfNRYbPxLNx9dbLxT4ukLDzvB5s6SsXjh2qpwWbzw/gpfAMq1F/RL+oK1pvgb2sWCwYPOq/u7e+nja+rPkn6++GBwPRcnFGrp+dXd+CB8e3UzjseLjX/syl84/bMU9YtPfKbL6DDaqkZQd30vibfYJdO3uupGKm10X9tn00wff2kwTPtwS6joz+fl4tdXt0MK05/9do7zuQVDJkQaTC5f7KRcgo0vbuyFwc5Vuds6vyofBZnzShQOFowuKJwlvnUzXrq1v0sB2rwR9LeHu0EybGzk074V9hfsdSlGb1P2fvD5xzbV/1b73Lg99nK8dDcY7TQhXB4m56/V2JCDGwxfvb62ca3T7XZWbnMzpgzZyGvYx++AvR1Gv0QaDYfNu8NowFlu1LjeX7oZ7I05wtwaJ8OdsEGt+80Ox5cwWfj0qpTDi427a8okGPLvik+s6vaaQlrSP1Z8MJ5aCcC+8Mcdhb14fqkr5OIfd/O6+hu9ZvTG0ov7B2E0HIXNV/ZHgySMPl8/fV0sKu618ZIqp5/6QrR0I0x3DpsrwyTZTzdHhxdXo/j1vfM3o2OcLkqd3nsaGVMkR0Wss7DjIOqHDwr/WLzw7dxjfuY3OUqII53LR4zFR/5yQ+5KcfkwebA2yley0bm3v7mZPrK+Fyo1k8YNPkWicZJdG+7e208bG0G/H4+CQZi+uc6pcDsgdB7J6RqrI9zyrc5wHO6mj1x5Tb9w5TWtUXpS+tX89vViN437w2D01c6rnG7SR7ubcmJN31obxZxN0vGT4tML9nL0uAT6r3fT/na4GzQ4em79wZ/0ntZdnwYSfREny0gnekZzTs/kHjRL0kzrPXMCwjDK1DOH3qdPQNrrZ/njh96nSixXOyZrHGQa0n71BJStMNOzI9lQndjlGH+W03yharMmwZme8d4oc3rPnYSR7KBnebbsPV+iOn7mTjMbDLPbBNIgGDVfwb+pfXqfK/FdI/Om8d+Is7qH956tkO1M16ax051MTkOYxK5pPAdT9RlA1WsazEEtWg+K70Tdecj58Ukh//Jp6pbHq3qTIqNBIf/1vLNT572LivJUJYtGhpq+dpqYenNDUVw6jaJseCjsz56KrXogymA0JfPQc+dY99gpTpGdOt/iXKeQy/CmM50RdVMBPhr0ynCYjRDvj6sMwfXasahVGaIM/lkIZIj8EVPvF4rZ0lTN3GO+T+C5XqWMbbuZ7htH1CUzoW6ZQuZg1PWlp3pUXzgc0XcWwkTfcla2Y2eGRkas5UY4oTDfVhpzE5RxqTGNVdN4DkZdY8f2T9aYdwDHEI5r7Dho6x9NR4XGvltpzM1Sxhn1BI3nYNQ15tLpmEJHbDwL4bjGLumNg+C0LtiYbyca635m2qzG0ZWo2didjXFEY8M6RWPDPoYwQ2PDybjJm9ZFNHaMnl/4uoujc/dYYmEsef2SvTbOfHmEkllsedlKvEup2Yw3m8vsEO7JpK/vCZGqm6YIV04mHMVZfjYgLRT0y9KDjsbN9XCYUGjssjuU+5ln+plFWspNzWsVPnlalr5R7WhrCRXvBJ+g5iFNiW8yUV4XZLUdMMdfK5T0XD+zqTBy/lyTZ9yCW9nOMJsqyMDgiYyfqRovo5G7G4wyFF0vGZElbKMUbBsIFpeD0XT1CCfNc81jnMq18jVUskqVuHJhCp6bYXBbg99odIxj78VCCV9HCatUgjclkPpCdIxkphLw1yuX8U0zs50yP/LQAl62c6IaXJ2pfYSHeZldJXmehkCKt229mr0c3H+j+aX7wW6Wrd68s7GaGb32qURXwkG6HYbjFAfhxHQY72fZrfXll5evQV5Zba7MtWR/sHXYvBFH4ziOKlK9V25789Vd3m1ewSEH3Bpl2c3ra3c6GKgytukwyzIf86ZAZnn2FVfGriyGz/HSpXDDwmJ6tjXCS6Yn31sqLYaJeYAyTYSj4AbKUaZ92OptVLQmtOXqVgLP6Pfw13utipWbOXyTh1DFStSwZ/trZk2MSPzxCmma+KweiwR9Yg+OCzQGp3nVFDnBHh720D+0PY6q4WRchU6rgfffSA934ub1Nw5pwA6GQTrxqcqWZBHelUzTyhTM023pW5kku6mFOLMtzbotifcZvGqKnGBLtnweis3QY5pmVk5lojXfIiYcIntqSjU1jmXXyrdsjcTjEKRTxD+WPYqFgZeX8aBtmtcZFdFRpKoqqgj5cIoYOKpdOapUITwakrRcBv0MixQZg1cveAi1XWERYSMLVSOeXqGaNdl7pewraNln5aXemfcWlTKK7IMehIjstaqA4s6i4jUtf6aHSPb5bJ59eJ5DxDhVxKi4w3fJnNVeUyYIcLFdtaXlMQruidOvVDaZ/mRPK+WwhmdWufIlCicezpazL1nV1JixhMWuw3MA5lsVONUczuxLtcwNL9yBBFwsQ12RUzM3xES5V0V5SXxmRWopkxcqBIhXRWrJSywitRglz7SRrV5xHJ5HiwPUdu9y3wMbF/Cq8CklnXUZrUmKtDU8iWcrM6xHlM1U2pyoQd3gascmfEY14F/tetSSdsZDug+nBnWla8xaw2l7z4rDI2rwbClzJ8m2NCxLeLo1uPOC9pgf/jjWeK5IB9yhZTzzK6zBiyk+WXmIO5lq//aKzovNW/SMt+QFKu/dBNWoHy3KZpleMqeIdaUeV2mL20PmRt2Aq03v7L3ifGFzkQhJOTVTMh3vdMuDF8FISiGzbESbNEgD+bFJcyM64PNwS0G91VL2bEYSIrDIz2HzuRQ9j3nqjA6opItz2zyc3UgUPU1Q0ayACUvql15ZzVu6K77Wu1dNCt/1y32gwqK/anyU/io/4NmqNgidQ4tbtXC4l2YFiNyya0koab3LlT7zcMtm5FnRi3akQi8z1XxN8rdGHIjRpTh3Y8F5uszqxp1pEpN+HOgvFHM2CD6PHalwanZmbvYMceqjB6eyt4vvaxCUuYunOjmBRLpWhNjnC948CmdKVTjymJi+Awefou+gZxzlKeHXeVAVR4fNodzNj+SeozwVcu0+mwPSoM298UOQ48zInUteHOrnSpcehs1dJ9qXPYziaqi5PhyEzSvywzLaT/pkHiRELFHWKZUlZB6lIl0uo6QBc3c43uZu63AU9n6lNOQc8tyQLito08CZwaBaCWKXJyFlqJGEWAkSR10+dwTNu8GhNIC4TGuuc3caJr0rpQpzOOQqUAgoFWbzKI65vDWV1UTd3NkqLUZJdhuT7TTzB2ns+r5VBcI8ovG9TP3ob4pUq8q9eYQs/mV8uLgHPUJetnX5fQa5mWdnZVjIGUQ60/T4ylw6D6XW5INN1ZbkuUvOot6WnIkwafJ9orA9b1/KVmDFBk0+WQ4TeNOKHtFi0kmsyI9qMQNhosUvVmJohvObqGlRJHX5urKdHHD4iViVIaRa5T1zrWtuFyhlOPAzjAIlLNsKoHAQ5ClyKa1E2Tt6OZUPK3/i1q7oykNM5p1BPGnRzkepq+DAhduGIjeeSYXlwlr8PkqIj1lhOuJofm7HSSpRV1y6VTvxPBYSctxxFFEvITeDSWUKkrnOD8SmJ1HzZDkDzkKp+xC/U6l8rLTDER+ahXDch+Ssyg8Ey8NPtfDiQ3xdXvLavuTWSTOHt104CIVTsElSfSY3MS/KWRp+w1ROTSHRBAKp2t94WY3DGlXJP6vOy1vCxfHMcWij8Mi9dDxXes66r1IlH/M9g9/57tKx5kL1TiQPFss8P5c4z5J0+WChZcfIi8XiVMiM+IlLMaNK9mSx5qLIYklqsjyPxMe+xO8pTXrhuIm8kZcbJ977eeqGfB7OZL2knp6HxfWw+NyVIOEtRNqTJJWjcs01JbRIUvOGj+qMg02RH9f5OM5EZ2kJ5JJYO6KfPW6KH16WD9SUxtaCaz7vUZ3wP2ph8+Rh6+Rh++Rh5+Rh9+Rh7+RhX+0JuRFmTIyyT/aM+eP6KePGKePmKePWKeP2KePOKePuKePeKeOn2M/Q1FsIZT8ywmwn4wEJ/T6td1haei6mnHO4eONRXPWzEOujPavLn5b8Lw==",
["t"] = 1794884394,
["level"] = 20,
},
},
["minimap"] = {
["angle"] = 250,
["hide"] = false,
},
}
