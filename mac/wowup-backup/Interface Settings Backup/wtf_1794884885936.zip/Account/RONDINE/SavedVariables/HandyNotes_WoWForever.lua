
HandyNotes_WoWForeverDB = {
["profileKeys"] = {
["Rondine Signalborn"] = "Rondine Signalborn",
},
["profiles"] = {
["Rondine Signalborn"] = {
},
},
}
