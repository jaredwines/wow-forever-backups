
RXPTT_DB = {
["showMinimap"] = true,
["managerOpen"] = false,
["managerTransparency"] = 2,
["managerOrder"] = {
},
["managerAfterRxp"] = {
},
["managerControlsTransparency"] = 0,
["showWorldMap"] = true,
["managerLocked"] = false,
["managerMinimap"] = {
["minimapPos"] = 75.63629790902579,
["hide"] = false,
},
}
