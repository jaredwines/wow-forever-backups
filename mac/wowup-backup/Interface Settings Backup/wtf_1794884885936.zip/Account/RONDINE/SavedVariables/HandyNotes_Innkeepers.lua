
HandyNotes_InnkeepersDB = {
["global"] = {
["setupDone"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
