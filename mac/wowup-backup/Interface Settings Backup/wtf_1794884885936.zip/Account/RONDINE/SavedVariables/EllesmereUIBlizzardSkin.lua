
EllesmereUIBlizzardSkinDB = nil
EllesmereUIDragonRidingDB = nil
