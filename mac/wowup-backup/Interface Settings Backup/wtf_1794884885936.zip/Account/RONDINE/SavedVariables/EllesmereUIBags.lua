
EllesmereUIBagsDB = {
}
EllesmereUIBagsInventoryDB = nil
