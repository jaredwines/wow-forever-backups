
ForeverDungeonJournalDB = {
["lastView"] = "home",
["portraitCacheVersion"] = 2,
["minimap"] = {
["minimapPos"] = 106.2340428515163,
["hide"] = false,
},
["displayIDs"] = {
[7023] = 5285,
[262297] = 143122,
[261974] = 143035,
[16059] = 15981,
[250034] = 2424,
},
["bossHintShown"] = true,
["spotFixes"] = {
[2425] = {
1287.700073242188,
331.2000122070313,
0,
["y"] = 0.9220303297042847,
["x"] = 0.5649012327194214,
["name"] = "Varimathras",
["map"] = 1458,
},
[3446] = {
-929,
-3701.699951171875,
1,
["y"] = 0.3761758208274841,
["x"] = 0.6241375207901001,
["name"] = "Mebok Mizzyrix",
["map"] = 1413,
},
[11862] = {
822.5,
939.9000244140625,
1,
["y"] = 0.6431245803833008,
["x"] = 0.4722025394439697,
["name"] = "Tsunaman",
["map"] = 1442,
},
[266484] = {
1306,
318.7000122070313,
0,
["y"] = 0.8935685753822327,
["x"] = 0.577999472618103,
["name"] = "Morbin Lightbane",
["map"] = 1458,
},
[3665] = {
-928.4000244140625,
-3769.10009765625,
1,
["y"] = 0.3760783076286316,
["x"] = 0.6307878494262695,
["name"] = "Crane Operator Bigglefuzz",
["map"] = 1413,
},
[3448] = {
-542.6000366210938,
-2671.300048828125,
1,
["y"] = 0.3189763426780701,
["x"] = 0.5224536061286926,
["name"] = "Tonga Runetotem",
["map"] = 1413,
},
[3216] = {
1801,
-4375.39990234375,
1,
["y"] = 0.505544900894165,
["x"] = 0.4953507781028748,
["name"] = "Neeru Fireblade",
["map"] = 1454,
},
[3419] = {
-995.5,
279.6000061035156,
1,
["y"] = 0.2091276049613953,
["x"] = 0.2271538376808167,
["name"] = "Apothecary Zamah",
["map"] = 1456,
},
[3442] = {
-904,
-3756.800048828125,
1,
["y"] = 0.3724693059921265,
["x"] = 0.6295743584632874,
["name"] = "Sputtervalve",
["map"] = 1413,
},
[4949] = {
1922.099975585938,
-4129.2001953125,
1,
["y"] = 0.3760800361633301,
["x"] = 0.3198534846305847,
["name"] = "Thrall",
["map"] = 1454,
},
[211022] = {
1666.900024414063,
165.9000091552734,
0,
["y"] = 0.3297181725502014,
["x"] = 0.7372193336486816,
["name"] = "Owen Thadd",
["map"] = 1458,
},
[10181] = {
1289.200073242188,
318.3000183105469,
0,
["y"] = 0.9198166728019714,
["x"] = 0.5783829689025879,
["name"] = "Lady Sylvanas Windrunner",
["map"] = 1458,
},
},
["rpgAccount"] = {
["rpgQuests"] = {
[5728] = true,
[959] = true,
[914] = true,
[1221] = true,
[1491] = true,
[962] = true,
},
["rpgBosses"] = {
},
["rpgKills"] = {
},
["rpgMaps"] = {
},
},
["questFaction"] = "Horde",
["lastMode"] = "bosses",
["lootFilter"] = {
["enabled"] = false,
["classOnly"] = false,
["recipes"] = false,
["schools"] = {
},
["matchAll"] = true,
["resists"] = {
},
["weaponTypes"] = {
},
["stats"] = {
},
["armorTypes"] = {
},
},
["learnedQuestIDs"] = {
},
["trackerHintShown"] = true,
["lastDungeon"] = "Ragefire Chasm",
["lastQuest"] = 1,
["flightTimes"] = {
["Ratchet, The Barrens>Thunder Bluff, Mulgore"] = 250,
["Crossroads, The Barrens>Orgrimmar, Durotar"] = 142,
["Thunder Bluff, Mulgore>Orgrimmar, Durotar"] = 207,
["Sun Rock Retreat, Stonetalon Mountains>Ratchet, The Barrens"] = 201,
["Sun Rock Retreat, Stonetalon Mountains>Thunder Bluff, Mulgore"] = 174,
["Crossroads, The Barrens>Sun Rock Retreat, Stonetalon Mountains"] = 150,
["Ratchet, The Barrens>Crossroads, The Barrens"] = 68,
["Orgrimmar, Durotar>Crossroads, The Barrens"] = 110,
["Crossroads, The Barrens>Thunder Bluff, Mulgore"] = 182,
["Ratchet, The Barrens>Orgrimmar, Durotar"] = 209,
["Camp Taurajo, The Barrens>Ratchet, The Barrens"] = 131,
["Ratchet, The Barrens>Camp Taurajo, The Barrens"] = 158,
["Brackenwall Village, Dustwallow Marsh>Thunder Bluff, Mulgore"] = 225,
},
["learnedItemIDs"] = {
["veilpiercer girdle"] = {
["id"] = 280070,
["name"] = "Veilpiercer Girdle",
},
["shamanic wristguards"] = {
["id"] = 280069,
["name"] = "Shamanic Wristguards",
},
["impish chain hood"] = {
["id"] = 280058,
["name"] = "Impish Chain Hood",
},
["burnished pridescales"] = {
["id"] = 280073,
["name"] = "Burnished Pridescales",
},
["flameslash crescent"] = {
["id"] = 280056,
["name"] = "Flameslash Crescent",
},
["scalding flamehoof"] = {
["id"] = 280074,
["name"] = "Scalding Flamehoof",
},
["reward voucher"] = {
["id"] = 8070,
["name"] = "Reward Voucher",
},
["behemoth bones"] = {
["id"] = 280065,
["name"] = "Behemoth Bones",
},
["tidesong wand"] = {
["id"] = 276735,
["name"] = "Tidesong Wand",
},
["lunarlight robe"] = {
["id"] = 280079,
["name"] = "Lunarlight Robe",
},
["cutthroat chestguard"] = {
["id"] = 276739,
["name"] = "Cutthroat Chestguard",
},
["bleak eye shoulderplates"] = {
["id"] = 280075,
["name"] = "Bleak Eye Shoulderplates",
},
["withering grips"] = {
["id"] = 280064,
["name"] = "Withering Grips",
},
["grips of control"] = {
["id"] = 276733,
["name"] = "Grips of Control",
},
["lucky shovelnose tuft"] = {
["id"] = 280060,
["name"] = "Lucky Shovelnose Tuft",
},
["trousers of the ebon giant"] = {
["id"] = 280066,
["name"] = "Trousers of the Ebon Giant",
},
["satyr's touch"] = {
["id"] = 287036,
["name"] = "Satyr's Touch",
},
["lost researcher's hood"] = {
["id"] = 279931,
["name"] = "Lost Researcher's Hood",
},
["expeditionary legplates"] = {
["id"] = 279901,
["name"] = "Expeditionary Legplates",
},
},
["portraitTexturesByNpcID"] = {
},
["questText"] = {
["enUS"] = {
[92579] = {
["o"] = "Deliver Aonda's Written Report to Valennia Stormfist in Valanaar.",
["d"] = "For now it seems the pylon and the village are safe, so I'd like you to deliver this report to Valennia Stormfist in Valanaar, at the southeastern edge of the island. Valennia is the leader of the peacekeepers on the island and she needs to know what happened here.\r\n\r\nThe cult is expanding rapidly and the peacekeepers have avoided direct conflict until now, but those days are over. Valanaar will need to be ready for a fight.\r\n\r\nAt any rate, thank you. You'll always have friends in Shen'dar, N.",
},
[871] = {
["o"] = "Of the Razormane tribe, kill 8 Water Seekers, 8 Thornweavers and 3 Hunters, and then return to Thork in the Crossroads.",
["d"] = "All the quilboars are our enemies, N. Some just prove to be more of a nuisance than others.\n\nThe Razormane tribe has been attacking our supply lines from Durotar, causing us no end of annoyance. I have scouts seeking the leader of these raids, but until then, any losses you can inflict on the filthy pig men would aid us.\n\nStart in the northeast towards Durotar. You can always tell their dens from the huge thorny vines that come up from the earth. Seek them out, and slay them.",
},
[903] = {
["o"] = "Collect 7 Prowler Claws from Savannah Prowlers for Sergra Darkthorn in the Crossroads.",
["d"] = "Now it's time to go after something that really bites.  The prowlers of the Barrens are a tough breed.  Tough, resourceful, sly... and deadly.  You'll find them among the tall grasses.  You'll find many to the southwest of the Crossroads.\n\nBe wary as you hunt them, N, or you may find yourself no longer the predator, but instead the prey.",
},
[97249] = {
["o"] = "Bring Migi's Lunch to him behind Grommash Hold.",
["d"] = "Now that I know his parents worry about how much he's actually filling that belly, I've got an idea. \r\n\r\nThey made me promise not to pack the same meal every day, so Migi grows a taste for more than one thing. Still, whenever the smoker's full and we're making sweetglazed hog belly sandwiches, he always shows up for lunch. We've started crumbling the leftover crispy glazed bits as a topping--something we can add daily. \r\n\r\nTake this to him. Maybe he'll start showing up early and bringing friends!",
},
[79192] = {
["o"] = "You tear the note from the plank and read the scrawled writing.",
["d"] = "The note begins, \"Mission said they were both making deliveries for New Plague. Looks like simple apothecary accidents to me. Find my cozy spot in the mountains between The Barrens and Desolace if you want a safe place to talk.\"",
},
[840] = {
["o"] = "Follow the western road from Razor Hill to the Barrens over a bridge.\n\nStop at the orc outpost across the bridge.\n\nGive Kargal Battlescar at the Barrens outpost your recruitment letter.",
["d"] = "Hmm, you look pretty strong.\n\nListen, my good friend Kargal needs some new recruits for Barrens duty. I know you want to do what's right for the Horde. Well, this is your chance.\n\nTake this recruitment letter to Kargal and see if he'll sign it.",
},
[872] = {
["o"] = "Kill 8 Razormane Geomancers, 8 Razormane Defenders, and Kreenig Snarlsnout.\n\nThen bring Kreenig Snarlsnout's Tusk to Thork at the Crossroads.",
["d"] = "One of my scouts witnessed an attack on a caravan from Durotar, N. The culprits are indeed the Razormane tribe of quilboars. One of the quilboars in particular is leading the raids: Kreenig Snarlsnout. He was seen northeast of here, just south of the road from Durotar. If the threat is to be ended, then Kreenig must die.\n\nTo be sure the attacks cease, though, I say we add insult to their injury. Kill Kreenig along with more of their tribe, and return to me when you have his tusk.",
},
[92516] = {
["o"] = "Slay 8 Hippogryph Youths, 6 Hippogryph Protectors and a Hippogryph Matriarch in the Shen'dar Highlands.",
["d"] = "A flock of Hippogryph have recently established nesting grounds southeast of Shen'dar Village and they've been wreaking havoc on travelers on the road. I need someone to head down there and thin them out for us.",
},
[93552] = {
["o"] = "Collect 15 Windstone Clusters from Raw Windstones in Thendal Grove.",
["d"] = "Windstones are a critical resource on Zephras Isle as they contain the raw, concentrated energy of the winds themselves. The wind elementals who used to live here on Zephras with us vanished a number of years ago, and since then, the magic that sustains this island is slowly fading. Not without limitations, the windstones are still a reliable energy source, and are incredibly valuable to us.\r\n\r\nYou'll find raw windstones scattered around the grove. Think you can help me harvest them?",
},
[97967] = {
["o"] = "Speak with Fenn Fairweather in Shen'dar Village to learn to craft a camping item for your profession once you have shown proficiency in your skill.",
["d"] = "You might not think so, but your skill as a fisherman can actually come in handy at camp.\r\n\r\nI reckon I know someone that can teach you how to craft a Fish Bowl for your camp. You can use this fixture to help provide a bit of joy to yourself and your fellow adventurers. A happy adventurer is a strong adventurer and I'm sure your combat capabilities will reflect that.",
},
[97250] = {
["o"] = "Slay Alliance soldiers encroaching into the Barrens at the border to Dustwallow Marsh, then return to Grunt Logmar at Camp Taurajo.",
["d"] = "Traveler, have you plans to head toward Dustwallow Marsh? I have heard mutterings that a few human soldiers have taken a stand at its border and are toppling the landmarks left behind by our tauren pathfinders.\r\n\r\nRumor has it that a favored tavern has burned to the ground, and in typical Alliance fashion, they immediately cast their blame onto the Horde! I cannot know whether there is any truth to their claim, but their incursion onto OUR land must not stand.\r\n\r\nKill first, investigate later!",
},
[93951] = {
["o"] = "Collect 8 Hippogryph Down feathers in the Shen'dar Highlands.",
["d"] = "The hippogryphs that have taken up residence southwest of the village can be a nuisance, but they also present a rather unique opportunity to obtain their feathers. Many skyborne love to adorn their hair with vibrant plumes and the down feathers of a hippogryph are exceptionally vibrant and, more importantly, silky soft.\r\n\r\nIf you are heading that way, try and gather as many of the fallen feathers as you can from around their nesting grounds. Do be careful, as wild hippogryph are not tolerant of guests.",
},
[92708] = {
["o"] = "Listen to what Ayessa Dawnsinger has to say.",
["d"] = "The Windshapers have been hard at work trying to respond to the current crisis on Zephras Isle. We have made several surprising discoveries in our search for the missing wind spirits, and we are developing a plan of action that could help us gain the means to save the island.\r\n\r\nWe'll need strong young adventurers like yourself for this to work however. Please, if you have a moment, let us speak on this further.",
},
[79974] = {
["o"] = "Dusting off a messenger bag emerging from the soil, you find a parchment nestled among the supplies.",
["d"] = "\"Always like to keep a reserve stash nearby in the off chance I've got to flee in a hurry.\r\n\r\nThe face of this mountainside is so beautiful you might say it was carved from the waterfalls of time. \r\nThat's the eagles nest, that's what you're looking for.\"",
},
[92517] = {
["o"] = "Kill 10 Highlands Bandits and their leader, \"Badwind\" Bennic in the Shen'dar Highlands.",
["d"] = "There's a cave not far to the north, hidden behind a waterfall. It's well known to me that there's a group of bandits that are operating out of that cave. They were a problem for us before the cult arrived, but now they are a real terror. I can't spare the people to go and clear them out, unfortunately.\r\n\r\nI need you to go there and take care of them for me. Kill as many as you can, and if possible, take out their leader, the one they call \"Badwind\" Bennic. That cave is dangerous, so be careful.",
},
[875] = {
["o"] = "Collect 6 Harpy Lieutenant Rings from Witchwing Slayers and return them to Darsok Swiftdagger at the Crossroads.",
["d"] = "Hahaha, N. Back for more? Good, I like to hear that.\n\nThis time I want you to assassinate some of the harpy lieutenants in the Dry Hills. Only Witchwing Slayers can be lieutenants, and you can tell them apart by the rings they carry. They are a nasty bunch, but they lead some of the underlings in that area. Taking out 6 of them will be a decisive strike against their matriarchy.\n\nMake sure they die painfully, N. We want those harpy wenches to know the idiocy of picking fights with the Horde.",
},
[94414] = {
["o"] = "Speak with Halaan Hawk-Eye and borrow his gift to view the anchor pylon in the distance.",
["d"] = "Greetings, young N. I oftentimes come here to look upon the ancient anchor pylon. Gifts from the spirits of the winds, they bind and sustain our island. Of late however, their magic has grown unstable and inconsistent.\r\n\r\nThey suffer no distress I can see. Their splendor has not changed.\r\n\r\nIf you'd like, I can lend you my gift to look upon them yourself.",
},
[1492] = {
["o"] = "Bring the Secure Crate to Wharfmaster Dizzywig in Ratchet.",
["d"] = "I have need to send a crate of potions, reagents and other items to my associates in the Old World. Little time I have to actually see them to the dock at Ratchet, and the last caravan has already left.\n\nIf you could, please take this to Wharfmaster Dizzywig. He will ensure that it is placed on the next boat to Blackwater Cove.",
},
[92693] = {
["o"] = "Speak with Aamelia Windfield when you are ready to confront the bandit leader.",
["d"] = "You've done a lot to give us a fighting chance. Even if we die today, we'll at least know we gave it our best shot.\r\n\r\nThis is your last chance, stranger. If you want to head back to Valanaar and live another day, I wouldn't blame you.\r\n\r\nOn the other hand, if you really have a thing for lost causes just let me know when you are ready to go. We'll walk out there with our heads held high and whatever happens, happens.",
},
[844] = {
["o"] = "Collect 7 Plainstrider Beaks and return them to Sergra Darkthorn in the Crossroads.",
["d"] = "Your first prey will be easy.\n\nThe plainstriders to the east have been harassing our food supplies and have become a nuisance.\n\nPut down the plainstriders and return to me with their beaks.",
},
[4921] = {
["o"] = "Find Mankrik's wife and then return to him in the Crossroads.",
["d"] = "We battled in a small tauren camp when we were separated--she held three of the Bristlebacks off by herself. But the odds began to overwhelm us. I led some away only to see her overwhelmed by newcomers. In my rage, I turned to face my enemies, but they brought me down easily with their vast numbers.\n\nI awoke to a tauren druid tending my wounds--he had come across me on the Gold Road as I fell.\n\nPlease, hunter, find some sign of my wife.",
},
[92550] = {
["o"] = "Travel to the ruins of Falaath Village and slay 6 Al'Aketh Stormcallers, 4 Living Lightning and take the head of Commander Cyclas.",
["d"] = "Our best defense here might just be a strong offense. The advantage we now have is that we expect an attack is coming. What they won't expect is for us to hit them first.\r\n\r\nI've already asked a lot of you, but please head back over to Falaath Village. Kill as many cultists as you can and if you can get close enough, kill the commander and bring me his head. I'll stay here and organize the citizens and our few peacekeepers to prepare a defense... just in case you don't return.",
},
[96646] = {
["o"] = "Speak with Zerril Softbreeze in Shen'dar Village to learn to become a cook.",
["d"] = "So you want to learn more about camping, huh? Good for you, hunter. The first step any adventurer needs to take is to become a cook and learn how to make a campfire.\r\n\r\nCooking's not just about making tasty foods. It's also the foundation for your camp.",
},
[92598] = {
["o"] = "Use your Skysight racial ability at the Elemental Convergence in Thendal Grove.",
["d"] = "As a Windshaper, you have the ability to use the sacred skysight gifted to us by the elemental spirits. Travel to the standing stones to the northeast of the village. Find the elemental convergence there and use your gift.\r\n\r\nYou'll find that you may draw upon the skysight anywhere, but its boon is much more powerful if you do so in the presence of an elemental convergence. You may at times receive other bits of wisdom from the spirits that are drawn to such places of power, as well.",
},
[97969] = {
["o"] = "Speak with Indari Sunseam in Shen'dar Village to learn to craft a camping item for your profession once you have shown proficiency in your skill.",
["d"] = "You've become a leatherworker. Good for you, hunter. I reckon I know someone that can teach you how to make yourself a tent that will keep you cool on hot days, and dry on rainy days.\r\n\r\nWith a good tent over your head, you'll ensure that you get all the rest you need to stay sharp on your travels.",
},
[6461] = {
["o"] = "Xen'zilla at Malaka'Jin needs you to kill 10 Deepmoss Creepers and 7 Deepmoss Venomspitters.",
["d"] = "We Trolls here at Malaka'Jin have prospered from the land; Stonetalon Mountain offers great hunting for us to live on.\n\nLately, we have attracted the wrong dinner guests... the spiders in these mountains have been raiding our camps at night looking to steal our hunt.\n\nIf you were to help us kill off these ghastly beasts we at Malaka'Jin would be in your debt. Spiders are everywhere in Stonetalon - just head north from here and you will see what I am talking about.",
},
[79976] = {
["o"] = "Whoever was here, you just missed them.",
["d"] = "\"So, I've decided to take my work back underground. To stop it falling into the wrong hands.\"\r\n\r\n<The paper is torn just large enough to fit the message. You aren't sure if these are the last words you'll read from the author, or if they're a clue to the next hideout. An inadequately secured sleeping bag is unrolling itself onto your feet...>",
},
[878] = {
["o"] = "Kill 6 Bristleback Water Seekers, 12 Bristleback Thornweavers and 12 Bristleback Geomancers and return to Mangletooth at Camp Taurajo in the Barrens.",
["d"] = "You must strike my enemies. <snort> You must help Mangletooth and the Razormane by weakening the Bristlebacks. Both tribes are very spiritual--tied to the earth and its power. <snort> It gives us strength in all things... especially war.\n\nIf you want to find out who really causes Thork <snort> and the Horde such anguish, then help Mangletooth! You attack the spiritual leaders of the Bristlebacks to the north; weaken them so the Razormanes can defeat them and rule the Barrens.",
},
[92551] = {
["o"] = "Collect 10 packs of Stolen Shen'dar Supplies from Falaath Village in the Shen'dar Highlands.",
["d"] = "I overheard you might be going to Falaath Village? While you are there, please keep an eye out for our stolen supply caches.\r\n\r\nThe Al'Aketh have been raiding our supply caravans carrying various goods such as food and windstones to and from the lowlands for months. They've been blaming the bandits, of course, but we all know that it all ends up in the same place. If there's any of that stuff left in Falaath, it would be a huge help if you could recover it.",
},
[98512] = {
["o"] = "Kill 10 Al'Aketh Assassins in the Shen'dar Highlands.",
["d"] = "You there, stranger. Get low and keep quiet. We are not alone here.\r\n\r\nI was on patrol near the border and noticed that there are a number of Al'Aketh skulking around the house just up the hill there to the north. I don't know what they are doing here, but it can't be good.\r\n\r\nIf you want to make yourself useful, get in there and take them out. I'll wait here and watch your back.",
},
[97253] = {
["o"] = "Collect 5 Handfuls of Complicated Parts from the upper pirate camp south of Ratchet, then return to Wrenix the Wretched in Ratchet.",
["d"] = "Hey, got a sec?\r\n\r\nSo, apparently, nobody I've sent to deal with the recent pirate problem has come back alive. After five or six attempts I thought, \"what if I sent a machine instead?\" Turns out, scimitars double as screwdrivers in a pinch, and before I could redirect it home, it was already in pieces and scattered across their camp!\r\n\r\nI need those parts back, and since this is a quick little retrieval mission, I'd wager your odds for survival are MUCH higher than the others. Whaddya say?",
},
[92679] = {
["o"] = "Listen to what Alvarion Windfield has to say and find Aamelia Windfield at the Windfield Orchard.",
["d"] = "H--Hello, stranger. You have the look of a capable adventurer about you. I...\r\n\r\n<The Skyborne man winces, clearly suffering terrible pain>\r\n\r\n...I was wondering if you were seeking employment? I came here to Valanaar to recruit fighters to help save my farm. If you are interested, please go find my wife Aamelia Windfield at our orchard to the west of Valanaar, in the lowlands.",
},
[848] = {
["o"] = "Bring 4 Fungal Spores to Apothecary Helbrim at the Crossroads.",
["d"] = "The oases of the Barrens hide a mystery.  Life energy flows from their waters, invigorating the plants and beasts that drink it.\n\nInvigorating, and altering.\n\nThere is a mushroom that grows near these oases.  Its spores hold properties that we, the apothecaries of Lordaeron, find useful.\n\nBring me these spores and you will earn our gratitude.",
},
[94050] = {
["o"] = "Speak to Quel'dora Quickgale in Valanaar.",
["d"] = "You now have the power to tame a pet, but you must also gain the skills to train it. For this, there is none better than my sister, Quel'dora. She will give you the ability to train your new pet. \r\n\r\nGo with the winds, young hunter.",
},
[97891] = {
["o"] = "Bring the Unstable Potion to Doctor Martin Felben in the Apothecarium within the time limit.",
["d"] = "You! Quickly, I need you to bring this potion across the slime canal to Doctor Martin Felben in the Apothecarium!\r\n\r\nIt has a very limited shelf life, and no I can't go myself, my knees rattle and pop out if I attempt to run.\r\n\r\nJust another lovely side effect of undeath, apparently.\r\n\r\nBut we're wasting time! Here, take this and go!\r\n\r\n<Alessandro makes a shooing motion.>",
},
[93317] = {
["o"] = "Collect 6 pieces of Windsong Crawler Meat.",
["d"] = "Are you familiar with Windsong Crawlers? You see, these crabs are native only to Windsong Lake here on Zephras, and they are only able to be harvested a few weeks of the year.\r\n\r\nWith all of the cult activity of late, I've not been able to get out to the lake to harvest them, and our window is rapidly closing. I'd be appreciative if you could go and gather some for me. They can generally be found along the shorelines around the lake and in rivers.\r\n\r\nDo be careful though, they are meaner than they look!",
},
[5725] = {
["o"] = "Bring the books Spells of Shadow and Incantations from the Nether to Varimathras in Undercity.",
["d"] = "Many denizens of the Legion bestow gifts on their followers as you may well know. Some of these gifts the Dark Lady feels would be better off in her hands than in the hands of those with... lesser vision.\n\nA sect of the Shadow Council hidden in caverns below Orgrimmar known as the Searing Blade are a prime example. The Lady tells me that members of the Searing Blade have come into the possession of two powerful spell books--she would like to \"borrow\" these books from them. You will get them for her.",
},
[5726] = {
["o"] = "Bring a Lieutenant's Insignia to Thrall in Orgrimmar.",
["d"] = "One thing I will not tolerate are traitors in our midst, N. But I would be a fool to play my hand so early--it would not sufficiently cut the corruption out of our lands and only cause the infection to grow worse.\n\nBut you, a young adventurer, could go places my agents could not... could learn the truth... could find the true head of the beast.\n\nIf you are brave enough, then enter Skull Rock to the east of Orgrimmar, find a lieutenant's insignia off one of the Burning Blade there, and return to me.",
},
[5727] = {
["o"] = "Take the Lieutenant's Insignia to Neeru Fireblade and speak to him. Gauge if he believes you are a member of the Burning Blade and then return to Thrall in Orgrimmar.",
["d"] = "Now let us see if this insignia you found is worth the effort.\n\nThere is a warlock within the city who believes he has my trust. He does not know that I realize where his true loyalties lie. He is in fact the leader of the Burning Blade. But do not rush off to do battle with him; he has a purpose, and we shall use him against our enemies.\n\nTake this insignia to him in the Cleft of Shadow here in Orgrimmar, speak to him and see if he believes you are one of his own, then return to me here.",
},
[5728] = {
["o"] = "Kill Bazzalan and Jergosh the Invoker before returning to Thrall in Orgrimmar.",
["d"] = "Hmm, leaders of the Searing Blade... this concerns me most. If they are the ones of value to Neeru, then those are who we must target first. This satyr... Bazzalan, and the other Neeru mentioned--what was he, a warlock?--must be slain.\n\nReturn to the Cleft of Shadow and enter Ragefire Chasm, N. Find these two leaders of the Searing Blade, and kill them. But be careful not to let Neeru know it was you who did this. You must retain your identity as one of his brothers in arms.",
},
[8368] = {
["o"] = "Bring 3 Warsong Marks of Honor to a Horde Warbringer outside the battlegrounds.",
["d"] = "The battle in Warsong Gulch against the Silverwing Sentinels is of great importance.  Under the guise of protecting a forest that doesn't belong to them, the Alliance seeks to deny the Horde one of our largest sources for lumber.\n\nDo not let this happen, N!  Come back to me with proof of serving the Horde in a worthy manner!",
},
[8370] = {
["o"] = "Bring 3 Arathi Basin Mark of Honor to a Horde Warbringer outside the battlegrounds.",
["d"] = "Our conflict with the Alliance has escalated to a true war.  No longer are false pretenses to enter into battle used or expected by either side at this point.\n\nThe battle for the Arathi Basin is one of resources, plain and simple.  Either the Alliance gets the resources and uses them against us or we get them and use them to keep our war efforts going.  Help the Defilers maintain the flow of resources we need, N!",
},
[850] = {
["o"] = "Bring Barak's Head to Regthar Deathgate, west of the Crossroads.",
["d"] = "The centaurs have plagued the Tauren for years.  And recently, the Kolkar centaurs of the Barrens have grown into a real threat.  Normally they were disorganized in these lands, but new leaders have risen among them.  Rallying them.\n\nTo preserve our holdings here, these centaur leaders must be destroyed.\n\nBring me the head of Barak Kodobane.  He camps near the Forgotten Pools to the north.\n\nDefeat him, then return to me.",
},
[93318] = {
["o"] = "Kill Vulgara the Insatiable in the Shen'dar Highlands and bring her head to Danarii Bellowveil.",
["d"] = "By order of Constable Aonda of the Peacekeepers, a bounty is hereby placed upon the scourge of the highlands, Vulgara the Insatiable. Last spotted on a hilltop rise just southwest of Shen'dar Village, the winged vuldren terror is highly dangerous and should be approached with caution.\r\n\r\nDeliver the beast's head to Danarii Bellowveil to receive your reward.",
},
[819] = {
["o"] = "Find someone who knows about Chen's Empty Keg.",
["d"] = "A small placard on one of the ends of the keg says,\n\n\"Chen Stormstout-\n\nMay your spirit be raised and always raise your spirits.\"",
},
[851] = {
["o"] = "Bring Verog's Head to Regthar Deathgate, west of the Crossroads.",
["d"] = "The centaur Verog the Dervish wanders the Barrens, and will be difficult to find.  But he is based at the centaur command tent at the Stagnant Oasis to the southeast.  It may be possible to draw him to you.\n\nTravel to the Stagnant Oasis to the southeast and attack centaur near the command tent.  It will be dangerous, but if you can kill enough centaur then they should raise an alarm.  And Verog will come.\n\nBring me his head and I will place it with Barak Kodobane's.",
},
[1061] = {
["o"] = "Speak with Seereth Stonebreak in the Stonetalon Mountains.",
["d"] = "The spirits of the Stonetalon Mountains are angered, for goblins and their servants are plundering and burning the land.  So the land has cried out, and those who listen for such things... have heard.\n\nSeereth Stonebreak, a promising shaman of the Horde, was sent to Stonetalon.  She reports massive deforestation at the hands of the goblins, and requests aid.\n\nMeet Seereth in Stonetalon.  To reach her, follow the road west of the Barrens' Crossroads.  She is camped near the Greatwood Vale.",
},
[93159] = {
["o"] = "Speak with the Strange Hermit in the Shadowgale Forest and learn more about him.",
["d"] = "Uh, um... h-hello, I mean to say, hi! Greetings, even! I'm sorry... it's um, been so long since I've actually spoken to another person. I'm afraid I'm a bit rusty at this.\r\n\r\n<The strange hooded figure shifts uncomfortably before you.>\r\n\r\nSo er, um... how is your day going?",
},
[1062] = {
["o"] = "Kill 15 Venture Co. Loggers, then return to Seereth Stonebreak on the border of Stonetalon and the Barrens.",
["d"] = "The goblin-run Venture Company moved into the Stonetalon Mountains, chopping down trees and burning huge stretches of forest.  The spirits of this place are nearly blind with pain and rage.  We must stop the Venture Company!\n\nHead northwest, beyond the Greatwood Vale and into the Windshear Crag.  You will find the goblins and their servants at work -- show them the Horde will not allow the exploitation of Stonetalon.  Show them in the language they best understand...\n\nViolence.",
},
[92474] = {
["o"] = "Jump from the top of the watchtower in Thendal Grove and use your Walk on Air ability to slow your fall.",
["d"] = "Well hello there, N! Want to play a game?\r\n\r\nAll you've got to do is step up on that ledge... then jump! Use your innate ability to walk on the air to slow your fall and see how far forward you can float.\r\n\r\nThe rules are made up and the points don't matter, but you get bonus points if you can land right in front of Rorian the Dayseeker and startle him! He won't like it but I'll certainly get a good laugh if you can get him all worked up! Hah!",
},
[79007] = {
["o"] = "Charred remains of the note serve as your only guide.",
["d"] = "<The faint radiance of the embers darkening, you stumble across the remnants of a recent fire.\r\n\r\nAmidst the scattered provisions, you discover a blistered note.>\r\n\r\n\"Not all that burns is lost. Find the twin land, find the place.\"",
},
[93319] = {
["o"] = "Collect 10 Pilfered Windstones from the Highlands Bandits in the Shen'dar Highlands.",
["d"] = "We are relying on windstones more and more for day-to-day living here on Zephras so we try and maintain a cache of them in reserve for emergencies. Lately I've noticed some go missing from our stores.\r\n\r\nWe've found windstones on bandits we've captured recently, and I suspect they are behind our shortages.\r\n\r\nIf you find yourself near the bandit cave to the north, mind knocking a few heads together and reclaiming some of our pilfered windstones for me?",
},
[821] = {
["o"] = "Bring 5 Savannah Lion Tusks, 5 Plainstrider Kidneys, and 1 Thunder Lizard Horn to Brewmaster Drohn in Ratchet.",
["d"] = "Would you like a taste of Chen's namesake? Ahh, the stormstout is a mighty brew. Chen taught the recipe to my mentor, and my mentor passed it on to me. I'll need you to get me a few things, but I can tell you this: the kick is worth it.\n\nBring me 5 savannah lion tusks from any savannah lion, 5 plainstrider kidneys from any plainstrider, and 1 thunder lizard horn from any species of thunder lizard. That should do the trick nicely.\n\nYou can find these ingredients throughout the Barrens.",
},
[94897] = {
["o"] = "Find Resaan in the Ruins of Ban'aethal.",
["d"] = "If you are traveling to Ban'aethal, I have a selfish request. My love, Resaan... I believe is no longer a part of this world. He had tried to go back to get supplies even though I begged him to stay. It has been over a week already and I fear the worst.\r\n\r\nPlease, if you find him, bring him home. If he has perished then I beg you to please bring me his heirloom.",
},
[6523] = {
["o"] = "Escort Kaya Flathoof to Camp Aparaje, and then return to Makaba Flathoof near the southeastern edge of Stonetalon.\r\n",
["d"] = "Thank you for rescuing me! We must leave quickly before they discover that I am free. Please escort me to Camp Aparaje. From there, I know my way.\n\nMy father, Makaba Flathoof, will be desperate to know that I am safe.",
},
[93160] = {
["o"] = "Gather 8 Shadowgale Acorns in Shadowgale Forest.",
["d"] = "I do appreciate you stopping by to talk with me! I-If you do want to help out, I could use a bit of help gathering up acorns from the forest floor. I've gathered most of the ones close by but there sure are a lot of raptor-bird things in the forest. It's dangerous out there and I'd rather not become a giant bird's lunch!\r\n\r\nSo if you want, you could maybe gather them for me? I'll make us something tasty if you do!",
},
[92682] = {
["o"] = "Gather 10 Ripe Stormapples and slay 5 Hungry Bandits at the Windfield Orchard.",
["d"] = "Oh, so you've got more courage than sense, then? Fine, I won't argue.\r\n\r\nFerauu and his goons aren't due to pick up their take of the harvest just yet, so I'm going to put you to work for your meals until they arrive.\r\n\r\nHead outside and gather today's batch of stormapples for me. Oh, and the bandits lurking around the stormapple trees... They think they are sneaky. They aren't. Kill them for me. \r\n\r\nLet's see what you've got in a fight.",
},
[92698] = {
["o"] = "Speak with Aamelia Windfield about the Malfunctioning Cyclone Construct.",
["d"] = "<You lean in close to try and hear the words coming from beneath the giant construct's armor plates.>\r\n\r\n...Function error...\r\n\r\n...Question...\r\n\r\n...What is....\r\n\r\n...Function...\r\n\r\n<These fragmented words and phrases seem to just repeat. Maybe someone nearby knows more about this construct?>",
},
[1130] = {
["o"] = "Speak with Melor Stonehoof in Thunder Bluff.",
["d"] = "N, Melor Stonehoof has heard of your deeds, and has set a path before you.\n\nIf you wish to take it, then go to Thunder Bluff and speak with Melor.  You will find him on Hunter's Rise.",
},
[79980] = {
["o"] = "Find what awaits you.",
["d"] = "\"Not so bad, eh? Since you're reading this, it means my stash is still there. Take a hundred paces due north and don't break your ankles going down the steep cliffside. There should be enough to keep you going.\"",
},
[855] = {
["o"] = "Bring 15 Centaur Bracers to Regthar Deathgate, west of the Crossroads.",
["d"] = "The Kolkar are a threat to the Horde's claims in the Barrens; we must reduce the numbers of their troops.  And so, I have a bounty task for you.\n\nWhile in Kolkar territories, slay their warriors and collect centaur bracers.  Return when you have a heap of bracers and the Horde will reward you well.",
},
[887] = {
["o"] = "Kill 12 Southsea Brigands and 6 Southsea Cannoneers for Gazlowe in Ratchet.",
["d"] = "I sure wish Vice Admiral Grezzlik did a better job of keeping the seas safe for our trading vessels. With all the gold the trade princes have poured into the Trade Fleets, it ticks me off to see so many pirates running willy-nilly, raiding my ships and stealing my goods!\n\nI heard that the Southsea Freebooters have set up a camp just south of here. They've been a real thorn in my side and if Grezzlik won't take care of them, well, maybe you can help me get rid of them.",
},
[1069] = {
["o"] = "Bring 15 Deepmoss Eggs to Mebok Mizzyrix in Ratchet.",
["d"] = "Spider egg omelettes are a new fad in Booty Bay!  The problem is... Booty Bay's got no eggs.\n\nI smell an opportunity!\n\nIn Windshear Crag and Sishir Canyon, in the Stonetalon Mountains to the northwest, lives the deepmoss spider.  Bring me its eggs and I'll pay a bundle!\n\nIn Windshear Crag, the eggs will be clustered under what trees remain.\n\nIn Sishir Canyon... well, if you have a weak stomach then maybe you should just collect the eggs at Windshear Crag...",
},
[93926] = {
["o"] = "Find Peacekeeper Vaaniel at the western watchtower.",
["d"] = "Whatever reason the cult has for attacking the tower, it's not worth losing our people over.\r\n\r\nI'd like for you to head to the southwest and check in on that watchtower for us. Find the peacekeepers there and tell them to head back to the village. Holding that tower is not worth the lives it would cost and I'd rather concentrate the defenders we do have here to protect our citizens.\r\n\r\nPeacekeeper Vaaniel is in charge; let him know to head back here as quickly as possible. Hurry!",
},
[6541] = {
["o"] = "Report to Kadrak at the watch tower in northern Barrens.",
["d"] = "Have you ever been to Ashenvale, to the north? The horde has recently set up an outpost on the Zoram Strand there, and we can always use some new recruits to help defend our new fronts.\n\nIf you think you are up to it, see Kadrak in the northern Barrens, at the watch tower. He is heading up the Ashenvale campaign and can give you further orders.",
},
[94978] = {
["o"] = "Use the Taming Rod to tame a Windsong Crawler found near bodies of water. \r\nPractice your skills, then return the Taming Rod to Quel'ana Quickgale in Valanaar.",
["d"] = "Every hunter begins by learning the bond between beast and master. This is your first challenge. In time, you'll tame creatures from every corner of the world, but for now, start with our rivers and lakes on Zephras. \r\n\r\nTake this Taming Rod and seek out a Windsong Crawler.\r\n\r\nShow that you can earn its trust, and begin your path toward true mastery.",
},
[94484] = {
["o"] = "Find and speak with Elegael Thornpaw in the northeastern part of Shadowgale Forest.",
["d"] = "A moment if you will, N. Are you headed towards Shadowgale Forest? There is a druid conclave there in a cave to the northeast. I have been waiting on word from them but their correspondence is long overdue.\r\n\r\nWith Ban'aethall in ruins and all the unrest lately I worry something dire may have happened. Please, if you are able, go seek out Elegael Thornpaw and put my mind at ease.",
},
[92460] = {
["o"] = "Speak with Rorian the Dayseeker in Thendal Grove.",
["d"] = "Look at you, bright eyed and ready for adventure! We need all the help we can get here in Thendal Village and your arrival is most welcome. I imagine you are brimming with nerves for what is to come. After all, you only get to come of age once in a lifetime.\r\n\r\nGo, seek out our village leader Rorian the Dayseeker at the entrance to the greatfather tree just west of here. He will get you started on your journey.",
},
[888] = {
["o"] = "Retrieve the Shipment of Boots and Telescopic Lens for Gazlowe in Ratchet.",
["d"] = "While I'd like to recover all my goods, I'm sure that's not possible. Still, there's a few things that I absolutely must have!\n\nAs you see, my observatory is ready to go, but it needs the smaller of the two lenses. The first arrived by caravan from Durotar, but the second was bound by ship, and never arrived. Also, I never got my boot shipment from Drizzlik in Booty Bay!\n\nHead down to the pirate camp and see if you can find them.",
},
[6548] = {
["o"] = "Kill 8 Grimtotem Ruffians and 6 Grimtotem Mercenaries, and then return to Makaba Flathoof near the southeastern edge of Stonetalon.\r\n",
["d"] = "The Grimtotem Clan raided my village and killed most everyone. I killed all I could, but barely escaped with my life.\n\nN, all I wish now is that more of them are dead. You will find them just to the west of here.\r\n\r\n",
},
[96875] = {
["o"] = "Kamari in Orgrimmar wants you to collect 5 Rough Lizard Hide from beasts in Thunder Ridge, along with 2 Cured Light Hides.",
["d"] = "Orgrimmar is always expanding, hunter. And when the peons need hides to line the walls and roofs of our new buildings, they come to me!\r\n\r\nThe hides of the lizards in Thunder Ridge are typically too thick for armor, but they make excellent building material. Bring me some of their hides, along with a few lighter cured hides. Let's see your skill with leather!",
},
[93927] = {
["o"] = "Collect the note you found near the dead peacekeeper and read it to determine your next steps.",
["d"] = "<As you inspect the body of the dead peacekeeper, a bloody note falls free of his hands. Picking it up and reading it may give you a clue as to how to proceed from here.>",
},
[97003] = {
["o"] = "Bring the head of Chol'aruk to Gur'ak in the Barrens.",
["d"] = "You there, hunter. I need your aid. There are rumors of a beast that makes its lair deep in a cave at Thorn Hill, northeast of here. The Razormane call it Chol'aruk or \"The Ravener\". It's supposedly five times the size of a normal quilboar with a thirst for blood that can never be sated.\r\n\r\nMost don't believe the tales. But I do--because I've fought its like before.\r\n\r\nSeek out its lair and slay Chol'aruk. Bring me its head. I warn you though--prepare well and do not go alone.\r\n\r\nBlood and thunder, hunter.",
},
[92684] = {
["o"] = "Gather 7 Lowlands Galestrider Tenderloins from the Ornery Galestriders found throughout the Gustberry Lowlands.",
["d"] = "As if the harvest wasn't light enough this year already, the galestriders in the area have been getting into the orchard and stealing my stormapples. Think you can head out to the fields and cull them for me?\r\n\r\nTake care though stranger, these lowlands galestriders are bigger and angrier than the highlands variety. Watch yourself. A well-timed kick is all it takes to put you down for good if you aren't paying attention.\r\n\r\nBring me some of their meat and I can make us a hot meal with it as well.",
},
[92700] = {
["o"] = "Find Ayessa Dawnsinger in Valanaar.",
["d"] = "Now that you've arrived in Valanaar, you'll likely want to check in with the other members of the Windshapers here. The current Grand Skyseer and her people operate out of the lodge near the center of Valanaar.\r\n\r\nYou should also be aware, the Windshapers and High Order don't get along very well in these parts. Be careful and give the High Order a good, wide berth. We've got enough to worry about with the cult, I won't tolerate faction violence in the streets of Valanaar.",
},
[92461] = {
["o"] = "Slay 8 Vuldren Juveniles in Thendal Grove.",
["d"] = "We live in times of great uncertainty for our people. We face unprecedented challenges that may require bold solutions, but we also must contend with the ordinary and mundane here in Thendal Grove. Take, for example, the recent unsustainable rise in the vuldren population.\r\n\r\nThe vuldren are a vital part of our ecosystem. However, imbalances must be corrected to maintain the delicate harmony that all creatures in Thendal Grove share.\r\n\r\nHead east and cull some of the vuldren there.",
},
[890] = {
["o"] = "Bring Gazlowe's Ledger to Wharfmaster Dizzywig.",
["d"] = "I've been waiting forever for my last shipment of goods from Booty Bay! I'm pretty sure that it must have been stolen by the Freebooters, but just to make sure, will you go down to the dockside and ask Dizzywig if my goods were already put into my warehouse without my knowledge?\n\nHere, take my ledger down to Dizzywig and have him double check my inventory records against his logs.",
},
[891] = {
["o"] = "Captain Thalo'thas Brightsun of Ratchet wants you to collect 10 Theramore Medals and slay Captain Fairmount, Cannoneer Whessan and Cannoneer Smythe.",
["d"] = "Yet another ship from my fleet has been lost to those overzealous humans at Northwatch Hold!\n\nThose bastards must be dealt with. Their paranoia has them in a state of frenzy. Trigger happy, reckless louts are shooting at anything in their sights.\n\nTravel south along the Merchant Coast to the Hold and lay siege to their forces. Bring me the medals of their soldiers as proof. And for the love of my fleet, slay Captain Fairmount and her overzealous cannoneers!",
},
[5041] = {
["o"] = "Find and return Crossroads' Supply Crates to Thork in the Barrens.",
["d"] = "That attack on the caravan contained supplies we desperately needed.\n\nYou've been brave enough to take on the Razormane tribe so far, and I will ask you to do so again, but this time, I wonder if I could ask you to keep your eyes open for some of our lost supplies. You can probably find them throughout their camps, the quilboar getting fat off their dishonorable acts.\n\nThe people of the Crossroads would be in your debt.",
},
[98024] = {
["o"] = "Report To Thork at The Crossroads in The Barrens.",
["d"] = "After journeying here from the elemental plane, the problems our lands face may seem small. Rest assured, the dangers the horde faces are very real, and you will grow formidable should you survive your service.\r\n\r\nIf you'd like to get started doing some good in our world, travel southwest to the vast lands known as the Barrens. There is a settlement there known as the Crossroads. The proud citizens there are ever in need of aid.\r\n\r\nGo with honor, adventurer!",
},
[92685] = {
["o"] = "Loot 7 Blood-Stained Bandit Masks from Highwayman Bandits in the Gustberry Lowlands.",
["d"] = "The bandits have camps all over and there's a small one in the hills just north of here. Head up there and start cracking skulls. If we can catch them off guard and take them out before they come for us, we might just even the odds enough to stand a chance.\r\n\r\nBring me their masks. The bloodier the better.",
},
[94486] = {
["o"] = "Collect 20 feathers from the Shadowgale Shrieklings in Shadowgale Forest.",
["d"] = "The other ingredient I need for the poultice is feathers from the Shadowgale shrieklings that roam this forest. In their juvenile form, the shrieklings have insulative feathers which would be ideal to put over the moss. These feathers will prevent the antiseptic sap from drying out and will provide at least some protection against the elements.\r\n\r\nBe warned, the shrieklings are normally docile but they have been incredibly hostile of late. Their large talons can easily disembowel you if you aren't careful.",
},
[92462] = {
["o"] = "Slay 8 Pesky Cirrusflies in Thendal Grove.",
["d"] = "One of our rangers recently reported an infestation of cirrusflies here in Thendal Grove. \r\n\r\nCirrusflies can be dangerous if the swarm is allowed to grow too large, so please head to the eastern end of the Grove and exterminate as many as you can.",
},
[892] = {
["o"] = "Return Gazlowe's Ledger to Gazlowe in Ratchet.",
["d"] = "Everything looks square from my records, N. Go on back and tell Gazlowe he's out of luck. I wouldn't be surprised if it was the pirates that nabbed his goodies.\n\nNothing else I can do for him. Oh... though you could tell him that I've got some things from Undermine for him, when he has the time to come pick them up.",
},
[93036] = {
["o"] = "Speak with Sania Silverstream in Shen'dar Village.",
["d"] = "You may or may not be aware of this, but Sania Silverstream over there is a \"missionary\" for the Al'Aketh. They like to play at being a normal religious order and send non-threatening emissaries around to recruit. We've tolerated Sania so far to avoid direct conflict with the cult, but it's obvious the illusion of peace won't last much longer.\r\n\r\nYou are new here and unknown to most, so I'd like to see if you can use Sania to get close to the cult and find out what their plans are for the village.",
},
[5052] = {
["o"] = "Bring a Blood Shard to Mangletooth in Camp Taurajo in the Barrens.\n\nCollect more Blood Shards if you want him to bless you with Agamaggan's power.",
["d"] = "Along with the thorns, the blood affected <snort> other aspects of the earth: blood red stones mixed in with other minerals. The Bristleback dig up these shards and carry them as totems <snort> for strength in battle and as totems for their magics. <snort>\n\nI know the secrets of that magic.\n\nBring Mangletooth one of these blood shards to show you understand. Bring Mangletooth many of the shards, and he will bless you with quilboar magic--the magic of Agamaggan! <snort>",
},
[94485] = {
["o"] = "Collect 8 Lady's Tear Moss.",
["d"] = "If we are to save my fellows in the Nightclaw Den, I am going to need some ingredients for a poultice. The first and most important is a spindly moss called Lady's Tear. It typically grows on the base of the trees here in Shadowgale.\r\n\r\nThis moss secretes a sticky substance that acts as an antiseptic and is perfect for binding open wounds. I have gathered what little I can reach but I know there is more in this forest.\r\n\r\nGo and be swift. We are going to need a lot if the injured I left behind still live.",
},
[893] = {
["o"] = "Bring a Razormane Backstabber, a Charred Razormane Wand and a Razormane War Shield to Tatternack Steelforge at Camp Taurajo in the Barrens.",
["d"] = "The Razormane quilboars to the south, beyond the Field of Giants, have no skilled blacksmiths from what I am told, but they've apparently started to develop sturdier weapons. I'd like to get my hands on a few different types to learn their techniques if possible.\n\nIf you wish to help bring honor to the Horde, then bring me examples of their weapons. Find me a dagger from their stalkers, a wand from their seers, and a shield from their warfrenzy. That should do nicely!",
},
[98248] = {
["o"] = "Deliver the Shipping Label to someone at the Durotar Supply and Logistics trade hub near the Crossroads in the Barrens.",
["d"] = "<A torn shipping label can be found on the side of the now fully stocked crate. Though the intended recipient is torn off, details of its origin still remain.\r\n\r\n\"Return damaged shipments or empty crates to the Durotar Supply and Logistics trade outpost, now conveniently located due west of the Crossroads in the Barrens. Your time is valuable and we will compensate you for your efforts!\"\r\n\r\nBeside the text is a crudely drawn map of the area near the aforementioned destination.>",
},
[1491] = {
["o"] = "Bring 6 portions of Wailing Essence to Mebok Mizzyrix in Ratchet.",
["d"] = "Ok, so the raptor horns didn't work so well.  But that's all right -- no one got rich on their first try!  And besides, I think I found something that'll work even better in my smart drinks!\n\nThere is a substance called Wailing Essence, and I think it is the cause of the strange plants and animals in the Barrens.  Get me some and I'll try it in my drink!\n\nI heard the essence gathers in ectoplasmic creatures in the Wailing Caverns to the west.  Hunt those creatures and gather the essence.",
},
[3281] = {
["o"] = "Bring the Stolen Silver to Gazrog in the Crossroads.",
["d"] = "You may have killed the raptors, but the silver they stole must be recovered!  I have reports that the raptors have a large grouping of nests south of Ratchet, known as the Raptor Grounds.  It is likely that they brought our stolen silver there.\n\nGo to this raptor haven and search for the stolen silver.  When you find it, return it to me.",
},
[92683] = {
["o"] = "Gather 5 Flutterfly Dust from the Flutterflies around the Gustberry Lowlands.",
["d"] = "I'm sure you've noticed the giant flutterflies out in the outer fields near the orchard? They are pleasant to look at, but they also have other benefits; namely their wing dust. It can be a mess, but if you can gather it up in large amounts, it has useful household applications.\r\n\r\nTake this Flutterfly Swatter and give the big bugs a good swat for me. They'll usually just get scared and flee, but sometimes they'll take some offense. Either way, they'll give their rumps a shake and drop a pile of dust.",
},
[94487] = {
["o"] = "Collect 10 Bloodied Heirlooms from Al'Aketh Footsoldiers and Al'Aketh Stormchasers in the Shadowgale Forest.",
["d"] = "The Al'Aketh Cultists ambushed us with no warning, though their motives remain a mystery to me. I knew these cultists had clouds between their ears, but I never imagined they would upset the delicate balance here on Zephras with such brutality. Go, slay as many as you can and take their heirlooms if they wear any.\r\n\r\n<Elegael spits.>\r\n\r\nThese storm-cursed cultists don't deserve to be called shen'dorei. The beasts of the forest can have their bodies. Their ashes don't deserve the winds.",
},
[92463] = {
["o"] = "Destroy the Cirrusfly Queen in Thendal Grove.",
["d"] = "If the forest is as thick with these insects as it sounds, simply killing the workers won't be enough.\r\n\r\nGo deeper into the forest and find the queen. She'll be close to the hive and surrounded by bigger and more aggressive soldiers, so be careful.\r\n\r\nPut her down and return here when it's done. That'll be one less problem to think about around here.",
},
[94013] = {
["o"] = "Use the Taming Rod to tame a Vuldren Alpha in the Gustberry Lowlands. Practice your skills, then return the Taming Rod to Quel'ana Quickgale in Valanaar.",
["d"] = "You've returned triumphant from taming two beasts. It's time now for your last trial. The winds of Zephras whisper of greater challenges ahead. \r\n\r\nTake this Taming Rod and journey to the Gustberry Lowlands. There, tame a Vuldren Alpha and prove your mastery. \r\n\r\nComplete this lesson and you'll be ready to learn the deeper ways of the hunter.",
},
[894] = {
["o"] = "Access the control console at the Venture Company research site.",
["d"] = "The Venture Company set up a small research facility far to the north of here, southwest of the Sludge Fen. I don't know very much about what they're doing, but did manage to discover that they're experimenting with something called a \"samophlange\".\n\nNow what the heck is a samophlange? Well, whatever it is, I want to examine it, so I need someone to go get it.\n\nI obtained a copy of their control system operating manual, you should be able to figure out how to disengage the samophlange from it.",
},
[95507] = {
["o"] = "Collect 8 Trapped Game from traps found in Sprung Traps in the Barrens.",
["d"] = "While you are out there, it would be of great help to me if you could check on my traps for me. I've got them strewn all over the valley.\r\n\r\nBring back any small game that I've caught. Keep your eye out for the other wildlife, though. This area can be dangerous if you aren't paying attention.",
},
[92706] = {
["o"] = "Bring Bruuz's Dorsal Fin to Gazlowe in Ratchet.",
["d"] = "Calling all anglers!\r\n\r\nA giant shark has been circling the waters near the shipping dock, attacking sailors and small boats. Dockworkers have given it the nickname \"Bruuz\". A hefty reward will be given to whoever brings me its fin!\r\n\r\n-- Gazlowe",
},
[6282] = {
["o"] = "Maggran Earthbinder in Sun Rock Retreat wants you to slay 7 Bloodfury Harpies, 7 Bloodfury Ambushers, 7 Bloodfury Slayers and 7 Bloodfury Roguefeathers.",
["d"] = "Tauren take pride as the protectors of these lands. Undoubtedly you can guess why I am alarmed with the number of harpies that dwell here in Stonetalon.\n\nThe Bloodfuries are the source of the increasing number of harpies in Kalimdor; they encroach upon all likes of life preventing the innocent from leaving their boundaries.\n\nI need you to cull the harpies, N!",
},
[845] = {
["o"] = "Slay Zhevra Runners to collect 4 Zhevra Hooves for Sergra Darkthorn in the Crossroads.",
["d"] = "The zhevra, although not the fiercest beast in the Barrens, are a shade tougher than the plainstriders.  Don't worry -- we'll send you against bigger prey in good time, but for now your teeth could use a little more cutting.\n\nHunt the zhevra to the north and south, and collect their hooves.  Bring them to me and perhaps we'll next send you against something tougher.",
},
[264] = {
["o"] = "Place Clarice's Pendant on Yuriv's Tomb in Silverpine.",
["d"] = "Filthy scum! Leaves me for his damn crusade. Because \"the Light is the most important thing we have against the threats the undead pose.\"\n\nWell, what about his children?! What about ME?! Night after night I sat patiently waiting for him... always second to his blasted duty!\n\nWell, witness what \"justice\" brings you, N! He's dead and I'm bearing the very thing he was trying to stop!\n\nTake this piece of junk and put it on his tomb at the Sepulcher. I want nothing to do with it anymore... or him!",
},
[93738] = {
["o"] = "Report back to Ayessa Dawnsinger in Valanaar.",
["d"] = "Brightwish, eh? So the High Order wanted to remove these components for some reason. But why though?\r\n\r\nThe High Order has always been meddlesome, constantly wanting to experiment with the wind spirits' magic. They are too bold by a mile, and we've strictly forbidden them from meddling with knowledge under Windshaper purview, but lately they've been testing our patience.\r\n\r\nI think you should report what you've learned back to Ayessa Dawnsinger. She can instruct you further on what to do.",
},
[92421] = {
["o"] = "Collect 25 Intact Limbs within The Ruins of Lordaeron for Morbin Lightbane in the Undercity.",
["d"] = "As a paladin of the Forsaken, it is my duty to exact the will of our Dark Lady while tending to our people's needs. We are fortunate with an opportunity to accomplish both.\r\n\r\nAbove the Undercity, the scourge still roam unchecked in great numbers. Our forces dwindle trying to reclaim our land, and decaying flesh cannot be reknit. Not without replacements.\r\n\r\nWould that our glorious captain Garek Bandarion still be with us, I know what he would wish. To finish what he started and heal our kin. For Lordaeron!",
},
[895] = {
["o"] = "Bring the head of Baron Longshore to Gazlowe in Ratchet.",
["d"] = "WANTED!\n\nBaron Longshore, Captain of the Heedless\n\nCaptain Longshore of Gilneas leads vessels of the Southsea Freebooters, and is wanted on charges of piracy. Remains must be in identifiable condition!\n\n-- Gazlowe",
},
[97965] = {
["o"] = "Speak with Naleeia Tattermend in Shen'dar Village to learn to craft a camping item for your profession once you have shown proficiency in your skill.",
["d"] = "So you've taken up First Aid? That's an honorable... and pragmatic pursuit as a hunter.\r\n\r\nI reckon I know someone that can teach you how to craft a First Aid Kit for your camp. Injuries are a reality in the world of adventuring and offering some much-needed healing at your camp could even save lives.",
},
[93165] = {
["o"] = "Collect 5 Al'Aketh Cultist's Ears from the Al'Aketh cultists in Shadowgale Forest, the Shrine of Akir, or Gustberry Lowlands.",
["d"] = "The Al'Aketh have visited great tragedy upon our enclave, and blood must be repaid with blood.\r\n\r\nI have an offer for you, stranger. Should you find conflict with these accursed cultists, bring me the ears of those you kill. I will reward you for each that you return with in both coin and, in time, access to the Nightclaw's secrets should you prove yourself to be a true friend.",
},
[97242] = {
["o"] = "Take some cuttings from the Cattails and Speargrass growing around the water flows in the Valley of Honor and return to Kor'geld in Yelmak's Alchemy and Potions.",
["d"] = "Yelmak doesn't want his apprentice breaking anything. Well, anything more than he already has.\r\n\r\nHe told me the young mixer in training has too much pride to ask for help when he really needs it. Yelmak wants to give him a taste of a particular home-brewed recipe.\r\n\r\nGather a mix of cattail and speargrass cuttings taken from the plants growing around the water in the Valley of Honor. I'd get them myself, but if I left the shop, Whuut would surely know we're catering to his mood.",
},
[93739] = {
["o"] = "Speak with Nazgrel in Grommash Hold to receive further instructions. Use the instructions received to locate and speak with Vol'jin, Cairne Bloodhoof, and Lady Sylvanas Windrunner.",
["d"] = "Azeroth is a large world, and the territory of the Horde is vast. The Undercity, Orgrimmar, and Thunder Bluff all have very unique people and culture.\r\n\r\nIf you are to be a guest of the Horde here on Azeroth, it would do you good to visit each of our capital cities in turn. Speak with my advisor Nazgrel for directions.",
},
[94488] = {
["o"] = "Kill Commander Haalien and bring his head to Elegael Thornpaw in the Shadowgale Forest.",
["d"] = "The reason for cultists' presence here still baffles me, but I smell a familiar scent over the bloodshed.\r\n\r\nOne of our circle druids, Haalien, disappeared months back. It appears he's thrown his sorry hide in with the cultists.\r\n\r\nShow him what happens when he spills the blood of his kin! Take his head and return it to me.",
},
[92464] = {
["o"] = "Speak to Yala Windwatcher in Thendal Grove.",
["d"] = "Ever since our elemental benefactors left us, it seems that we are simply moving from one unrest to another. The problem we face now is that the manifestations of the winds near the standing stones to the northeast are agitated.\r\n\r\nNot truly self-aware like the sentient wind spirits that once lived here, these simple sprites respond in kind to forces, emotions, and intentions of the creatures around them. \r\n\r\nMy apprentice Yala Windwatcher went to observe them. Seek her out and discover what she's learned.",
},
[97275] = {
["o"] = "Give Yelmak's Potion to Whuut.",
["d"] = "Whuut is a prodigy. That much is true. But he doesn't yet have the experience, wisdom, and time on the stirring rod to know how to respect alchemical processes.\r\n\r\nHe is exhausting all of the rarest and most exotic reagents we have available without pausing to practice and refine his basic skills.\r\n\r\nGive him this potion I've brewed with a quick tonic method. He'll reconsider everything he's doing when he learns how local remedies and careful touch are the first true mastery.",
},
[896] = {
["o"] = "Retrieve the Cats Eye Emerald from one of the Venture Co. Overseers or Enforcers for Wharfmaster Dizzywig at Ratchet.",
["d"] = "Being Wharfmaster of a busy port like Ratchet, I keep my finger on the pulse of information. I know all about the exchange of goods and money between here and Booty Bay.\n\nThe latest bit of news I've heard is about the Venture Company's Boulder Lode mine northeast of the Sludge Fen. One of the miners discovered an emerald the size of your fist. I know a few buyers who'd be interested in getting their hands on something like that, and I'd be willing to go half and half on its sale.",
},
[1087] = {
["o"] = "Kill 4 Sons of Cenarius, 4 Daughters of Cenarius and 4 Cenarion Botanists for Braelyn Firehand near Sun Rock Retreat.",
["d"] = "You cannot imagine the hatred I possess for this wretched land. The ilk of Cenarius and the kaldorei druids at the peak employ their pathetic powers to stifle the flow of magic, even so far south of their pathetic holdings... their beloved forests.\n\nWould that I could return to Jaedenar and exult in the flow of magic, but my master will not allow me to return until my work is done.\n\nI have no doubt you love the night elves and their allies as little as I. Aid me, and both our ends might be satisfied.",
},
[92528] = {
["o"] = "Look around Falaath Village to learn about the cult's intentions in the Shen'dar Highlands.",
["d"] = "The faithful of Al'Akir grow ever stronger with each eager new recruit like yourself. As you can see, our strength gives form to the storm itself!\r\n\r\nNormally I'd send you straight to Skypriest Aanders for assessment, but he is occupied at present receiving a guest at the inn on the north side of town. Please avoid that place for now. An unshaven recruit like yourself in the presence of such a guest would be inappropriate.\r\n\r\nFor now, just don't get in anyone's way.",
},
[853] = {
["o"] = "Bring the Rendered Spores to Apothecary Zamah in Thunder Bluff, before the time limit is up.",
["d"] = "I have rendered the spores you gave me into an emulsion.  I must now send it to my associate, Apothecary Zamah.  If you were to carry this to her, she can offer you something from our stores of alchemical goods.\n\nShe is in the Pools of Vision, a cave beneath the shamans of Thunder Bluff.  The path to this cave is well hidden, but you may find it on the Spirit Rise bluff.\n\nDo hurry.  This emulsion will maintain its potency for only a short time, and must be resealed and processed before then.",
},
[93746] = {
["o"] = "Confront Belathaan Brightwish along the road to the Shrine of Akir.",
["d"] = "The High Order has been warned of the consequences of meddling with the Windshaper's affairs. I think we need to make an example out of Belathaan and send him back to the High Order with a few bruises and a healthy respect for the boundaries we set.\r\n\r\nBelathaan was seen leaving town, traveling north towards the Shrine of Akir. I don't know why he was going there, but confronting him alone on the road is the safest option. Find him, and put a bit of fear into his heart.",
},
[79975] = {
["o"] = "Water spray dampens the air, the view is incredible.",
["d"] = "<You find a carefully folded letter inside of the toolbox.>\r\n\r\n\"From here, with the right tools, you call the shots. Great place to launch a parachute glider.\r\n\r\nMy loyalty to the Eagle and Fist requires distance in order to serve them best. This barricade has had better days, like the Old Kingdoms it once defended, but I'll never abandon it.\"",
},
[842] = {
["o"] = "Follow the western road from Kargal's Far Watch Outpost.\n\nAt the T intersection, turn left and follow the road south. \n\nFind Sergra Darkthorn at the crossing of roads within the Crossroads.",
["d"] = "Take this signed recruitment letter to the Crossroads.\n\nSergra Darkthorn, curse her hide, is in charge there. She's a nasty shaman who will talk your head in circles before she lets you do anything useful. Thrall is convinced she's something special, but I'm not so sure.\n\nYou'll just have to decide for yourself, pup...",
},
[865] = {
["o"] = "Gather 5 Intact Raptor Horns from Sunscale Scytheclaws, and bring them to Mebok Mizzyrix in Ratchet.",
["d"] = "The raptors of the Barrens are smarter than raptors in other lands.  And I think all that smarts is hiding in their horns!  If so, then I could grind their horns into powder and use it to make \"smart drinks.\"  I could sell them for a fortune!!!\n\nAnd you can help me.  Find me intact raptor horns from sunscale scytheclaws.  They roam in the southern Barrens, and in the northern Barrens near the border of Ashenvale Forest.",
},
[92482] = {
["o"] = "Read the Scribbled Note and then speak with Tai'ree Farsight in Thendal Grove.",
["d"] = "While you were away dealing with our vuldren problem, our resident hunter trainer--Tai'ree Farsight--left this note for you. You can find her just over yonder near the center of the village. Read the note then seek her out.",
},
[92529] = {
["o"] = "Report to Missionary Jasaan near the entrance to Falaath Village.\r\n\r\nIf you lose your Mark of Akir, speak with Sania Silverstream in Shen'dar Village to regain the effect.",
["d"] = "It gladdens my heart that you wish to serve Al'Akir. Our current trials as a people stem from our own complacency. We grew prideful and took the bounty of the winds for granted. The stagnation that followed is the reason the spirits of the wind abandoned us.\r\n\r\nOnly through acts of contrition may we feel the wind's caress once more. If you seek the fellowship of like-minded shen'dorei, go to Falaath Village and find Missionary Jasaan there. I will mark you so that the faithful will know you as a recruit.",
},
[97246] = {
["o"] = "Visit Borstan's Firepit and tell him Thatog wants you to deliver Migi's lunch to him personally.",
["d"] = "My son, Migi, always takes off to play with his friends all day. I tell him to pick up a lunch at Borstan's, but I know he almost never does, because he comes home starving. These kids think their games are more important than their own bodies!\r\n\r\nPlease, stop at Borstan's Firepit and tell him you're there to deliver Migi's lunch. You can almost certainly find Migi behind Grommash Hold with the rest of his friends.\r\n\r\nDuties keep me here during the day and I can't watch over his every meal.",
},
[1094] = {
["o"] = "Deliver the Sealed Envelope to Sputtervalve in the Barrens.",
["d"] = "This envelope has all the information I was able to snatch as they booted me out the door... Venture Company internal documents, some manuals, technical things... Oh, and of course the Super Reaper 6000 blueprints.\n\nSputtervalve has taken up residence at Ratchet in the Barrens. Shouldn't have much trouble finding him, he's a little green fellow.",
},
[6629] = {
["o"] = "Kill Grundig Darkcloud and 6 Grimtotem Brutes, and return to Makaba Flathoof near the southeastern edge of Stonetalon.\r\n",
["d"] = "N, you've done a fine job killing Grimtotem. If you dare, Grundig Darkcloud and his personal band of brutes is by far the worst of the lot. He was the one who led the brutal attack on my village.\n\nYou will find him in Grimtotem Post a bit further up the path to the west. Kill him, and I will be forever grateful.\r\n",
},
[94489] = {
["o"] = "Enter the Nightfang Den and heal 7 druids and find Jorel Windsinger in Shadowgale Forest.",
["d"] = "I have finished the poultices. Quickly, take them to the druids in the cave, north just across the clearing. I know my brethren are in much more dire condition than I. They are likely too injured to heal their own wounds. There are so few of us shen'dorei druids that every life is precious.\r\n\r\nBefore you go, I have a selfish request. My mate, Jorel Windsinger was in dire condition when I left. Please, see to his wounds if he still lives.",
},
[92465] = {
["o"] = "Slay 6 Roiling Winds and 7 Al'Aketh Converts in Thendal Grove.",
["d"] = "The Al'Aketh cult is a blight upon this island. These cultists are surely the ones responsible for agitating the simple wind sprites that reside here and turning them violent.\r\n\r\nRegrettably, we'll need to disperse these roiling winds here before they harm someone. We also need to send a clear message to the cult that they are not welcome in the grove.\r\n\r\nWill you lend me your aid, hunter?",
},
[97326] = {
["o"] = "Return 8 Smooth Boulders to Thra behind Grommash Hold.",
["d"] = "Hey! You've got time to help us out! I know you do, I can tell by the way you smiled watching the game we're playing.\r\n\r\nThis spot behind Grommash Hold is nice because it's clear enough for us to set up our figures. But what stinks is we don't have enough rocks for chairs or tables.\r\n\r\nYou're big and strong... d'ya think you could carry back some medium-sized rocks, smooth enough to sit on if we need a rest?",
},
[898] = {
["o"] = "Safely escort Gilthares Firebough back to Captain Brightsun in Ratchet.",
["d"] = "Finally! Someone to rescue me!\n\nI can't believe you got past the guards. These zealots from Theramore are out of their minds. They sank our ship and imprisoned me, the only survivor. I was called an enemy and threat to the Alliance.\n\nMe! A threat to their great sham of an Alliance? I was a deckhand on a moonshine transport between Ratchet and Booty Bay.\n\nEnough talk. Help me get back to Ratchet will you? Let me know when you're ready and we'll make our break.",
},
[93948] = {
["o"] = "Deliver the Shadowsong Family Signet to Talaanis Shadowsong in Valanaar.",
["d"] = "Since you are going to Valanaar anyway, please deliver the signet ring you recovered from the tower to Talaanis Shadowsong in Valanaar. \r\n\r\nHe will want this back, and more importantly, he will want to learn the fate of his nephew. Talaanis is the High Elder of Zephras Isle and more importantly, he is a good man who is well loved by the people, despite our current hardships. It pains me to think of how he will react to this news. Please express my condolences for his loss.",
},
[962] = {
["o"] = "Apothecary Zamah in Thunder Bluff wants you to collect 10 Serpentbloom.",
["d"] = "The Royal Apothecary Society, based in the great Undercity of Lordaeron, has sent me here for a very specific service, N. Perhaps you wish to aid me, and in turn The Dark Lady in our efforts to advance the Forsaken.\n\nRecently I studied a rare specimen of flora named Serpentbloom. I believe in greater quantities this herb has great potential.\n\nUnfortunately Serpentbloom can only be found in the darkest recesses of the Wailing Caverns, a dangerous cave system located in the Barrens.",
},
[95350] = {
["o"] = "Travel to Orgrimmar and speak with Thrall in the Valley of Wisdom.",
["d"] = "It's a big world down here, and our new allies are the key to our survival.\r\n\r\nThe Earthen Ring is a member of the \"Horde\", a proud collection of like-minded peoples. The nearby city of Thunder Bluff is a part of the Horde, and further to the east lies the capital of Orgrimmar.\r\n\r\nSeek out the flight master in the center of Thunder Bluff. They will fly you to Orgrimmar where you will make contact with the Horde warchief--Thrall, on behalf of the Windshapers. Winds guide you, N.",
},
[94979] = {
["o"] = "Use the Taming Rod to tame an Ornery Galestrider in the Gustberry Lowlands. \r\nPractice your skills, then return the Taming Rod to Quel'ana Quickgale in Valanaar.",
["d"] = "You've proven you can tame the river's crawler. Now it's time to test your skill on open ground. The plains of Zephras echo with the cries of the galestrider, a proud, winged hunter that runs like the wind.\r\n\r\nTake this Taming Rod and seek one out. Travel to the lowlands and earn its trust.\r\n\r\nShow you're ready for the trials yet to come.",
},
[93737] = {
["o"] = "Speak with Riaani Nightwind and listen to what he has to say.",
["d"] = "Oh, hello. Ayessa sent you to assist me? Very well then. \r\n\r\nNot sure what an obvious novice like yourself can do, but if you give me a moment to pull my head out of this construct's innards I might have a few ideas of things you can do to help.",
},
[959] = {
["o"] = "Crane Operator Bigglefuzz in Ratchet wants you to retrieve the bottle of 99-Year-Old Port from Mad Magglish who is hiding in the Wailing Caverns.",
["d"] = "Oops!\n\nHad a little mishap, as you can see! The morning cargo shipment from Booty Bay was huge. Huge I say! Never seen so many crates. Well, I was trying to expedite things so I started unloading a bit more than I could handle. That's when everything came tumbling down.\n\nBefore I knew what was going on, I saw that menace, Mad Magglish, go running off with a bottle of 99-year-old port. Chased him all the way to Wailing Caverns. No way I was going in there.\n\nMaybe you're brave enough to find him?",
},
[867] = {
["o"] = "Collect 8 Witchwing talons.\n\nReturn them to Darsok Swiftdagger at the Crossroads.",
["d"] = "The blasted harpies have been ravaging our caravan supplies for too long. It's time we slit a few of their throats and diminished their numbers.\n\nI've been snooping around their nests and figured out who leads who. The most devastating attack will destroy a good section of their lower chain of command and then we can work our way to the top.\n\nI'll start you off slow, take out Witchwing Harpies and Witchwing Roguefeathers in the Northwest and bring me 8 Witchwing talons. That should be a good start...",
},
[899] = {
["o"] = "Bring 60 Bristleback Quilboar Tusks to Mankrik at the Crossroads.",
["d"] = "Perhaps you know the pain of uncertainty, perhaps not, hunter. But know this: I stand here every day, from the sun's rising till its decline, scouring the horizon for more of those monsters. I've killed every pig man I've come across since, but my thirst for their blood is far from quenched. Perhaps instead of heading north to the Crossroads I should have headed to Taurajo.\n\nYou, hunter--you  could help me.\n\nKill them. Kill as many as you can. Bring me their tusks, and we will celebrate their deaths together.",
},
[1093] = {
["o"] = "Get the Super Reaper 6000 Blueprints for Ziz Fizziks in the Stonetalon Mountains.",
["d"] = "Terrible what the Venture Company has done here, eh? What were they thinking? Goblin company hiring a gnome!\n\nLucky for me, Sputtervalve knows a genius when he sees one. Hired me just after I'd been kicked out!\n\nTells me they built some enormous woodcutting machine, and Sput' wants me to steal the plans for him. Unfortunately, Gerenzo--bloody gnome--wants me dead on sight... maybe you could steal the plans for me? You should be able to find them on one of their operators.",
},
[94896] = {
["o"] = "Collect 8 Abandoned Belongings from the ruins of Ban'aethal.",
["d"] = "You look like a capable adventurer. Do you happen to be headed towards Shadowgale Forest? Ban'aethal lies deep in the forest; that's where we're all from.\r\n\r\n<Ealaane gestures to the other refugees.>\r\n\r\nWe've recently had to evacuate Ban'aethal, as it began to fall into the sky. It was sudden and in the middle of the night. If you are headed that way, would you please look for any belongings left behind? The forest and village are far too dangerous for us to return to now.",
},
[1221] = {
["o"] = "Grab a Crate with Holes.\nGrab a Snufflenose Command Stick.\nGrab and read the Snufflenose Owner's Manual.\n\nIn Razorfen Kraul, use the Crate with Holes to summon a Snufflenose Gopher, and use the Command Stick on the gopher to make it search for Tubers.\n\nBring 6 Blueleaf Tubers, the Snufflenose Command Stick and the Crate with Holes to Mebok Mizzyrix in Ratchet.",
["d"] = "Blueleaf tubers are a delicacy around the world!  But they're rare, very rare.  The only place to find them is here in the Barrens, deep in the earth, in Razorfen Kraul.\n\nAnd even then, they're impossible to find unless you know just where to look!  That's why I've trained these snufflenose gophers to find them for me.  They have great noses and can smell a tuber from fifty paces away.\n\nIt won't be easy, but if you get me some tubers I'll pay you handsomely.",
},
[95494] = {
["o"] = "Collect 6 Savannah Lion Hides from the Savannah Matriarchs and Savannah Patriarchs in the Barrens.",
["d"] = "I need someone with a strong sword arm and some extra time on their hands to help me gather some lion hides. It stings my pride to ask a stranger for this aid, but I took an injury to my leg recently. Until I heal, I'm in no shape to go hunting myself but I have obligations to keep.\r\n\r\nThe big ones in this area generally have the best hides, so start with those first.",
},
[94490] = {
["o"] = "Bring the Ripped Missive to Elegael Thornpaw in the Shadowgale Forest.",
["d"] = "<Tucked behind one of Haalien's bracers is a note that's been slightly torn and bloodstained in your fight. It looks like it contains useful information about the cultist motivations for the attack on the druid den. Elegael would be interested in this intel.>",
},
[6562] = {
["o"] = "Speak to Je'neu Sancrea in Ashenvale.",
["d"] = "Je'neu Sancrea is in need of aid. He is at the Zoram'gar Outpost in Ashenvale. The Night elf forest is to the north of the Stonetalon mountains. You can reach it by traveling through Windshear Crag or by heading north through Barrens. Zoram Strand is far to the west of the forest. Be careful, N. There are forces there that will not take to your presence kindly.",
},
[868] = {
["o"] = "Bring 12 Silithid Eggs and the Digging Claw to Korran at the Crossroads.",
["d"] = "Hey, N. I been sent to the Crossroads to watch over the land and take note of its happenings for my masters in Orgrimmar.\n\nOne object of my studies are the insect-like creatures found to the south in the Field of Giants. We know little of the creatures, so I be makin' it a point to discover more. They seem to have intelligence to them, more so than any normal animal.\n\nTake this digging claw and collect some of the creatures' eggs from their mounds, but be careful: if alerted, they will attack you.",
},
[93735] = {
["o"] = "Find Riaani Nightwind on the west side of Valanaar.",
["d"] = "Historically, the Windshapers have seen to the tending of the magical instruments and devices that were gifted to us by the spirits of the wind. This includes the myriad of magical constructs around the island. Since the spirits left us, only a scant few of these are still functional.\r\n\r\nOne of the few remaining working constructs in Valanaar has become damaged. One of our artisans was dispatched to help, but he may be in need of aid. Travel to the west end of the city and offer any assistance you can.",
},
[1095] = {
["o"] = "Bring the new orders to Ziz Fizziks in the Stonetalon Mountains.",
["d"] = "The matter of this gnome that has been hired by the Venture Company has caused a bit of a stir in Undermine. The trade princes do not approve of Razdunk's consorting with this Gerenzo.\n\nRiddlevox has asked me to take care of the problem, and I'm sure he was instructed to do so by one or more of the trade princes. Of course, the Director didn't tell me that. Let's just say I have a hunch.\n\nWhatever the case, Gerenzo must be removed, and it would be a fitting test to have Fizziks take care of him.",
},
[93172] = {
["o"] = "Destroy 10 Wind Hollows in Shadowgale Forest.",
["d"] = "Most of the elves on this island seem to think that these woods are haunted, and they aren't wrong.\r\n\r\nAt the old ruins to the northeast, a strange type of ghost-like spirits gather. Some nights, you can almost hear them \"singing\". It's not like any song I've heard before, but it's definitely a song and it's... just so sad.\r\n\r\nI'm not sure why, but I think something terrible happened there at some point, and the spirits are trapped there somehow. If you are feeling brave, maybe you can help set them free?",
},
[92553] = {
["o"] = "Collect 3 Small Eggs and 8 Strider Meat from creatures found throughout the Shen'dar Highlands.",
["d"] = "Up for a bit of work? I could use a bit of muscle from a strong adventuring-type such as yourself. With how dangerous things are getting around here, no one's had much time to hunt or forage of late, and I need someone to get out there and source me fresh eggs and strider meat to keep this village fed.\r\n\r\nI'd be happy to teach you one of my famous recipes if you can bring me what I need. What do you say?",
},
[86576] = {
["o"] = "Bring 15 Glittering Sunstones to Mor'rogal.",
["d"] = "In addition to spreading their filth across the Charred Vale, the Bloodfury harpies gather anything shiny that they can find. I'm told that they collect a variety of golden-yellow sunstones for decoration. I have no use for such trinkets, but Mor'rogal has mentioned using them before.\r\n\r\nWhile you're fighting the harpies of the Vale, keep your eye out for Glittering Sunstones. Bring any that you find to Mor'rogal, up on the hills above us.",
},
[1096] = {
["o"] = "Bring Gerenzo Wrenchwhistle's Mechanical Arm to Ziz Fizziks in the Stonetalon Mountains.",
["d"] = "I met Gerenzo once, but let me tell you, he's not easy on the eyes. His flesh looks like it's rotting away, and he's grafted metal and gears onto his body, replaced some of his limbs with mechanical ones.\n\nNortheast of here, far above Cragpool Lake, up near the water wheel is where Gerenzo watches over the entire site. There's no way I could fight my way up there, not to mention take on Gerenzo... But you look like you might be able to make it.\n\nIf you kill him for me, I'll make it worth your while!",
},
[6393] = {
["o"] = "Bring 10 Incendrites to Tsunaman at Sun Rock Retreat.",
["d"] = "The Tribunal of the Tides has sent me to wage war on the fire elementals here in Stonetalon Mountain. Neptulon the Tidehunter, Lord of all water elementals, has taken a personal interest in seeing our fiery cousins extinguished.\n\nN, you can help me gain favor with the Tribunal by destroying the fire elementals in Charred Vale. When destroyed, the fire elementals leave Incendrites. Return these to me and be rewarded.",
},
[869] = {
["o"] = "Bring 12 Raptor Heads to Gazrog at the Crossroads.",
["d"] = "Not long ago, a shipment of silver was stolen from our guard tower.  It was meant as payroll to the Crossroads' guards, and we want that silver back.\n\nThe strange thing is... we caught one of the thieves on the night of the theft.  And... it was a raptor!  Unbelievable!\n\nI don't know what raptors would want with silver.  But I don't care -- I want the raptors dead so they won't steal from us again!\n\nHunt raptors in the Barrens.  Collect for me their heads!",
},
[94411] = {
["o"] = "Slay 6 High Order Apprentices in Shen'dar Highlands.",
["d"] = "Be warned, members of the High Order have been seen in the vicinity of the standing stones north of the village. We have warned them time and again to not meddle at our sacred sites, but they are growing more bold in pushing us. Prove your resolve to us by going to the standing stones and dispersing them.\r\n\r\nI am loathe to condone outright bloodshed, but do what you must to drive them off. Return to me when it's done.",
},
[877] = {
["o"] = "Return to Tonga at The Crossroads, after investigating the Stagnant Oasis.",
["d"] = "Like the one you found at the Forgotten Pools, there may be fissures at the other oases in the Barrens.  If so, then perhaps the fissures are the oases' source of life.\n\nWe must test this.\n\nHere, take these seeds.  They are dead and infertile, but take them to the Stagnant Oasis to the southeast.  If there is a fissure there, then place the seeds within it...and observe.",
},
[6301] = {
["o"] = "Tammra Windfield at Sun Rock Retreat wants you to gather 10 Gaea Seeds.",
["d"] = "Industrial greed and continuous war have wrecked the lands of Stonetalon. Only the blessings of the Earthmother can cure such injury.\n\nN, I will require you to seek a special seed, the Gaea seed. They are only found here in Stonetalon Mountain, north of Sun Rock Retreat at Mirkfallon Lake, near the water's edge.\n\nOnce you bring me the seeds I will imbue them with shamanistic power to speed their growth.",
},
[93949] = {
["o"] = "Kill Skyhoppers in Valanaar until you've eliminated 8 Enchanted Skyhoppers.",
["d"] = "We've been bugged.\r\n\r\nIt's skyhopper season in the lowlands, which means the pests are everywhere. One of the High Order mages reported that one of the insects that they killed had an enchantment of some kind placed upon it. When we inspected it closely it seems to be some sort of listening spell.\r\n\r\nWe suspect that the cult is using these enchanted insects as spies. Go and exterminate them for us. You won't be able to tell which are enchanted by looking at them, so you'll just have to kill them all.",
},
[6421] = {
["o"] = "Explore deep into the cave at Boulderslide Ravine and bring back 10 Resonite Crystals for Mor'rogal at Sun Rock Retreat to investigate.",
["d"] = "Something is amiss here in Stonetalon. Can you feel the tension in the air, N?\n\nSoutheast of here lies a deep cave in Boulderslide Ravine. The kobolds there are frantically mining a rare crystal called Resonite. I need you to bring back some ore samples so that I can understand what's happening in that cave.  I also need you to investigate the depth of that cave.\n\nGo young hunter, it's imperative I know what evil lurks under these mountains.",
},
[94491] = {
["o"] = "Give the missive to Lotheluum in Valanaar and tell him what has transpired.",
["d"] = "It would appear that there is a correspondent hiding somewhere in Valanaar feeding information to the cult. I am clearly in no shape to make the journey, but Lotheluum needs to know what transpired here.\r\n\r\nHe should also know the fate of those who are no longer with us. Thanks to your help I think we can handle the rest of the situation from here, though the damage has been done.\r\n\r\nPlease go swiftly, N. I hope our paths will cross again someday. Until then, I have cultists to slay.",
},
[6401] = {
["o"] = "Tell Tammra Windfield in Sun Rock Retreat the good news.\r\n",
["d"] = "Tell Tammra Windfield, Kaya's aunt who's at Sun Rock Retreat, about the good news! Kaya is alive! We had thought she was lost after the brutal attack on our village. Follow the path to the west to get to Sun Rock Retreat.\r\n\r\n",
},
[870] = {
["o"] = "Report back to Tonga Runetotem with your findings.",
["d"] = "Long ago, the Barrens was a lush place, teeming with life.  But war and cataclysm raged across the land, scorching it and leaving a dry husk.  Such is the way of things, and it saddens my heart.\n\nBut within the past few years, new oases have formed in the Barrens, and life stirs.  And deep down, we druids sense a power leaking its way to the surface.\n\nWe must find its source.  Travel to the Forgotten Pools, northwest of the Crossroads.  Search its waters for a source of power, then return here.",
},
[6284] = {
["o"] = "Kill Besseleth and bring Besseleth's Fang to Maggran at Sun Rock Retreat.",
["d"] = "Warning: Proceed into Sishir Canyon west of here at your own risk.\n\nBesseleth and her eight-legged children of the forest have claimed this canyon as their webbed lair.\n\nMaggran Earthbinder in Sun Rock Retreat has placed a bounty on Besseleth. Slay her and bring proof of your killing to Maggran; there you will receive your reward for disposing this eight-legged menace.",
},
[92515] = {
["o"] = "Collect 10 Prideclaw Pelts from the Prideclaws in Shen'dar Highlands.",
["d"] = "As if bandits and mad cultists weren't enough, the hills are thick with prideclaws as well right now. They are starting to encroach on the village borders and growing bolder by the day. It's only a matter of time before someone's pet or child is taken. It would be a mercy for us to cull their numbers now rather than after some tragedy occurs.\r\n\r\nBring me a dozen or so of their pelts. I can turn them into all sorts of goods that will be of aid to the village.",
},
[96101] = {
["o"] = "Sit near Raan's Basic Campfire and wait until you receive the Boosted Rest buff.",
["d"] = "Greetings, hunter. I can see you've got the look of an adventurer about you. This is good. The world needs more of us restless souls, seeking fortune and glory.\r\n\r\nYou'll need to learn to thrive in the wilds to be successful in this line of work. Not sure how your outdoor skills are but I can probably teach you a thing or two, if you'd be apt to learn.\r\n\r\nHave a seat near the fire and get comfortable. I'll walk you through it.",
},
[235] = {
["o"] = "Speak with Senani Thunderheart at Splintertree Post, Ashenvale.",
["d"] = "Attention, young adventurers!  The wilds of Ashenvale await you!\n\nThe Horde has established a strong presence in the lands north of the Barrens.  Our two outposts - Splintertree Post and the Zoram Strand Outpost - strive to bring glory to the Horde!  Those who would prove themselves should seek out guidance there.  Of note: Senani Thunderheart in Splintertree Post, directly north of the Barrens, seeks adventurers willing to take part in a great hunt of Ashenvale!",
},
},
},
["lastBoss"] = 1,
}
