
ItemLockForeverDB = {
["items"] = {
},
["stacks"] = {
},
["settings"] = {
["lockSound"] = "vault",
["iconCorner"] = "TOPRIGHT",
["unlockSound"] = "keys",
["holdToUnlock"] = false,
["iconSize"] = 14,
["iconColor"] = "ffffffff",
["errorSound"] = "error",
["click"] = "ALT-LeftButton",
},
["free"] = {
},
["schema"] = 1,
}
