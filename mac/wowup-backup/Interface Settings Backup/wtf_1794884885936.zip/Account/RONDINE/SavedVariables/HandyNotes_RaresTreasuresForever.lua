
HandyNotes_RaresTreasuresForeverDB = {
["showAlt"] = true,
["scaleRare"] = 1,
["scaleTreasure"] = 0.8,
["minimap"] = true,
["showTreasures"] = true,
["recordChat"] = true,
["showUnconfirmed"] = true,
["showRares"] = false,
["maxLoot"] = 15,
["remind"] = true,
["shared"] = {
},
["versionCheck"] = true,
["alpha"] = 1,
["lastReminder"] = 1794463904,
["showRecorded"] = true,
["rec"] = {
},
["showLoot"] = true,
["hidden"] = {
},
["record"] = true,
["loot"] = {
["treasure:106318"] = {
[2642] = true,
},
["rare:3270"] = {
[818] = true,
[15492] = true,
[4768] = true,
},
},
["confirmed"] = {
},
["lootQuality"] = 0,
}
