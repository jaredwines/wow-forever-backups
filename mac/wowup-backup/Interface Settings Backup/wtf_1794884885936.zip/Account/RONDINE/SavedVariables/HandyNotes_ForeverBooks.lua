
HandyNotes_ForeverBooksDB = {
["autoCollect"] = true,
["scale"] = 1.5,
["continents"] = true,
["alpha"] = 1,
["minimap"] = true,
["hideCollected"] = false,
["uncertain"] = true,
["factionOnly"] = false,
["world"] = true,
}
