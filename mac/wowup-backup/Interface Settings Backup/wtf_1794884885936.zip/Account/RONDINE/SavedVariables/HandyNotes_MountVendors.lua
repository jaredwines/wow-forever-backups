
HandyNotes_MountVendorsDB = {
["global"] = {
["setupDone"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
