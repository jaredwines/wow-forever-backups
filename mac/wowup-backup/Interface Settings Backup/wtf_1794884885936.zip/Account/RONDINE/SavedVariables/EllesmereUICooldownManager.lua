
EllesmereUICooldownManagerDB = {
}
