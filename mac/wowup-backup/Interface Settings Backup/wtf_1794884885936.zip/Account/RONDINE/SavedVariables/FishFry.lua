
FishFryDB = {
["settingsProfileMigration4bnApplied"] = true,
["foreverHudPoint"] = {
["y"] = 108.0998611450195,
["x"] = 816.4998779296875,
["point"] = "CENTER",
["relativePoint"] = "BOTTOMLEFT",
},
["forever"] = {
["sessionsUI"] = {
["schemaVersion"] = 1,
["selectedByCharacter"] = {
},
},
["characterIdentity"] = {
["schemaVersion"] = 2,
["legacyBucketsPreserved"] = true,
},
["sessions"] = {
["schemaVersion"] = 5,
["characters"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["byID"] = {
},
["characterName"] = "Rondine",
["order"] = {
},
["nextID"] = 1,
["characterKey"] = "ForeverGUID-Player-6934-0043A935",
},
},
},
["wiki"] = {
["search"] = "",
["schemaVersion"] = 1,
["category"] = "all",
},
["schemaVersion"] = 1,
["minimap"] = {
["shown"] = true,
["angle"] = 225,
["positionMigration127dApplied"] = true,
},
},
["activeBarCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["releaseReset113Applied"] = true,
["characterTackleSwap"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["normalRestoreTime"] = 15471.676,
["normalRestore"] = {
["1"] = {
["empty"] = true,
["slot"] = 1,
},
["8"] = {
["itemID"] = 252425,
["slot"] = 8,
["empty"] = false,
["link"] = "|cnIQ3:|Hitem:252425:15:::::::20:1485::::::::Player-6934-0043A935:|h[Dark Leather Boots]|h|r",
},
["16"] = {
["itemID"] = 276886,
["slot"] = 16,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:276886::::::::20:1485::11:::::::|h[Chol'aruk's Trophy Sword]|h|r",
},
["17"] = {
["empty"] = true,
["slot"] = 17,
},
["18"] = {
["itemID"] = 5309,
["slot"] = 18,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:5309::::::::20:1485::11:::::::|h[Privateer Musket]|h|r",
},
["6"] = {
["itemID"] = 4246,
["slot"] = 6,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:4246::::::::20:1485::::::::Player-6934-01B13CBF:|h[Fine Leather Belt]|h|r",
},
["10"] = {
["itemID"] = 2976,
["slot"] = 10,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:2976:15:::::::20:1485::1::1:28:5256:::::|h[Hunting Gloves]|h|r",
},
},
["active"] = false,
["normalRestoreOwner"] = "ForeverGUID-Player-6934-0043A935",
["owner"] = "ForeverGUID-Player-6934-0043A935",
["restore"] = {
},
["normalRestoreReason"] = "PLAYER_REGEN_ENABLED",
},
},
["foreverCookingKnowledge"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["lastUpdatedAt"] = 1794884833,
["legacyPositiveSeeded"] = true,
["campsiteObservedProfessions"] = {
["cooking"] = true,
["skinning"] = true,
["first aid"] = true,
["fishing"] = true,
["leatherworking"] = true,
},
["lastPositiveSource"] = "COOKING_RECIPE_POSITIVE",
["recipes"] = {
["7751"] = true,
["1230117"] = true,
["6499"] = true,
["7753"] = true,
["1229737"] = true,
["1229432"] = true,
["1229517"] = true,
["1229745"] = true,
["7752"] = true,
["7827"] = true,
},
["schemaVersion"] = 2,
["campsiteProfessionSnapshotVersion"] = 1,
},
},
["cookingCharacterCacheMigration103Applied"] = true,
["journal"] = {
["accountWide"] = true,
["fishingHistory"] = {
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["lastCaught"] = 1794535442,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533458,
["caught"] = 76,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["lastCaught"] = 1794533891,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533891,
["caught"] = 1,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["lastCaught"] = 1794550113,
["lastZone"] = "Durotar",
["firstCaught"] = 1794550113,
["caught"] = 1,
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 11,
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["lastZone"] = "The Barrens",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 86,
["firstCaught"] = 1794542998,
["lastCaught"] = 1794883714,
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 119,
["firstCaught"] = 1794543010,
["lastCaught"] = 1794884818,
},
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794882335,
["firstCaught"] = 1794882335,
["lastZone"] = "The Barrens",
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 22,
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["lastZone"] = "The Barrens",
},
},
["summaryDefault113eApplied"] = true,
["milestoneAllDefault169wApplied"] = true,
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["milestoneSearch"] = "",
["viewMode"] = "account",
["totalCatches"] = 315,
["skillCapEventStyle035Applied"] = true,
["surfaceMode"] = "milestones",
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
["totalFishingSeconds"] = 5682.286000000026,
["milestoneView"] = "all",
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
[225] = true,
[150] = true,
["225"] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["guildChatAnnounce"] = false,
["milestoneAutoShareMode"] = "OFF",
["milestoneNotices"] = true,
["characters"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["fishingHistory"] = {
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["lastCaught"] = 1794535442,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533458,
["caught"] = 76,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["lastCaught"] = 1794533891,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533891,
["caught"] = 1,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["lastCaught"] = 1794550113,
["lastZone"] = "Durotar",
["firstCaught"] = 1794550113,
["caught"] = 1,
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 11,
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["lastZone"] = "The Barrens",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 86,
["firstCaught"] = 1794542998,
["lastCaught"] = 1794883714,
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 119,
["firstCaught"] = 1794543010,
["lastCaught"] = 1794884818,
},
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794882335,
["firstCaught"] = 1794882335,
["lastZone"] = "The Barrens",
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 22,
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["lastZone"] = "The Barrens",
},
},
["lastSeen"] = 1794884833,
["fish"] = {
[6292] = {
["count"] = 1,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["count"] = 11,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["source"] = "fishing-loot-structured",
["count"] = 76,
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["count"] = 119,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884818,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6289] = {
["count"] = 86,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883714,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
[6522] = {
["count"] = 22,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
},
["skillCapEventStyle035Applied"] = true,
["totalFishingSeconds"] = 5682.286000000026,
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
[225] = true,
[150] = true,
["225"] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["skillObserved"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["source"] = "equipped",
["count"] = 1,
["lastSeen"] = 1794528221,
},
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
["count"] = 75,
},
},
["totalCatches"] = 315,
["name"] = "Rondine",
["faction"] = "Horde",
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["realm"] = "CAMWOW US2 Realm 8 PvP",
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
["skillMax"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
},
},
["milestoneForcedEmotes"] = true,
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["source"] = "equipped",
["count"] = 1,
["lastSeen"] = 1794528221,
},
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
["count"] = 75,
},
},
["activeCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["fish"] = {
[6292] = {
["count"] = 1,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["count"] = 11,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["source"] = "fishing-loot-structured",
["count"] = 76,
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["count"] = 119,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884818,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6289] = {
["count"] = 86,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883714,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
[6522] = {
["count"] = 22,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
},
["milestoneGuildReports"] = false,
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["skillObserved"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
["recordSearch"] = "",
["skillMax"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
},
["characterTackleProfiles"] = {
},
["characterCooking"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["lastScanAt"] = 1794880113,
["recipeStates"] = {
["7754"] = {
["outputItemID"] = 6316,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6317,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["7827"] = {
["outputItemID"] = 5095,
["disabled"] = false,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["lastVerifiedAt"] = 1794884833,
["reagents"] = {
{
["items"] = {
6361,
},
["quantityRequired"] = 1,
},
},
},
["25954"] = {
["outputItemID"] = 21217,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
21153,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
},
},
["1247741"] = {
["outputItemID"] = 8957,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
8959,
},
["quantityRequired"] = 1,
},
},
},
["18240"] = {
["outputItemID"] = 13928,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13755,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["6501"] = {
["outputItemID"] = 5526,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
5503,
},
["quantityRequired"] = 1,
},
{
["items"] = {
1179,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["25704"] = {
["outputItemID"] = 21072,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
21071,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["18238"] = {
["outputItemID"] = 6887,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
4603,
},
["quantityRequired"] = 1,
},
},
},
["18239"] = {
["outputItemID"] = 13927,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13754,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["18245"] = {
["outputItemID"] = 13933,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13888,
},
["quantityRequired"] = 1,
},
{
["items"] = {
159,
},
["quantityRequired"] = 1,
},
},
},
["7213"] = {
["outputItemID"] = 6038,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
4655,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
},
},
["6415"] = {
["outputItemID"] = 5476,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
5468,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["20626"] = {
["outputItemID"] = 16766,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
7974,
},
["quantityRequired"] = 2,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
{
["items"] = {
1179,
},
["quantityRequired"] = 1,
},
},
},
["18244"] = {
["outputItemID"] = 13932,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13760,
},
["quantityRequired"] = 1,
},
},
},
["7755"] = {
["outputItemID"] = 4593,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6308,
},
["quantityRequired"] = 1,
},
},
},
["18241"] = {
["outputItemID"] = 13930,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13758,
},
["quantityRequired"] = 1,
},
},
},
["20916"] = {
["outputItemID"] = 8364,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
8365,
},
["quantityRequired"] = 1,
},
},
},
["6500"] = {
["outputItemID"] = 5527,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
5504,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
},
},
["18242"] = {
["outputItemID"] = 13929,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13756,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 2,
},
},
},
["6499"] = {
["outputItemID"] = 5525,
["disabled"] = false,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["lastVerifiedAt"] = 1794884833,
["reagents"] = {
{
["items"] = {
5503,
},
["quantityRequired"] = 1,
},
{
["items"] = {
159,
},
["quantityRequired"] = 1,
},
},
},
["7753"] = {
["outputItemID"] = 4592,
["disabled"] = false,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["lastVerifiedAt"] = 1794884833,
["reagents"] = {
{
["items"] = {
6289,
},
["quantityRequired"] = 1,
},
},
},
["18247"] = {
["outputItemID"] = 13935,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13889,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["18246"] = {
["outputItemID"] = 13934,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13893,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2692,
},
["quantityRequired"] = 1,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 1,
},
},
},
["7828"] = {
["outputItemID"] = 4594,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6362,
},
["quantityRequired"] = 1,
},
},
},
["18243"] = {
["outputItemID"] = 13931,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
13759,
},
["quantityRequired"] = 1,
},
{
["items"] = {
159,
},
["quantityRequired"] = 1,
},
},
},
["7751"] = {
["outputItemID"] = 6290,
["lastVerifiedAt"] = 1794884833,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["disabled"] = false,
["reagents"] = {
{
["items"] = {
6291,
},
["quantityRequired"] = 1,
},
},
},
["8238"] = {
["outputItemID"] = 6657,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
6522,
},
["quantityRequired"] = 1,
},
{
["items"] = {
2678,
},
["quantityRequired"] = 1,
},
},
},
["7752"] = {
["outputItemID"] = 787,
["lastVerifiedAt"] = 1794884833,
["knowledgeSource"] = "IsPlayerSpell",
["known"] = true,
["verified"] = true,
["disabled"] = false,
["reagents"] = {
{
["items"] = {
6303,
},
["quantityRequired"] = 1,
},
},
},
["1250158"] = {
["outputItemID"] = 250081,
["disabled"] = false,
["verified"] = false,
["reagents"] = {
{
["items"] = {
7974,
},
["quantityRequired"] = 3,
},
{
["items"] = {
3713,
},
["quantityRequired"] = 4,
},
},
},
},
["knownTradeSkillNames"] = {
["slitherskin mackerel"] = true,
["brilliant smallfish"] = true,
["rainbow fin albacore"] = true,
["longjaw mud snapper"] = true,
["boiled clams"] = true,
},
["recipeCacheSchema"] = 4,
["scanRecipes"] = true,
["lastScanTrackedKnown"] = 5,
["recipeVariantByFish"] = {
},
["lastScanVisibleRecipes"] = 5,
["knownNames"] = {
["slitherskin mackerel"] = true,
["brilliant smallfish"] = true,
["rainbow fin albacore"] = true,
["longjaw mud snapper"] = true,
["boiled clams"] = true,
},
["characterKey"] = "ForeverGUID-Player-6934-0043A935",
["lastScanWindowRows"] = 5,
["knownTradeSkillRows"] = {
},
["lastScanNewRawRecipes"] = 0,
["knownRecipes"] = {
},
["knownTradeSkillSpells"] = {
["7751"] = true,
["7827"] = true,
["7752"] = true,
["6499"] = true,
["7753"] = true,
},
["knownRecipesScanned"] = true,
["lastScanNewTrackedRecipes"] = 0,
["knownResults"] = {
["787"] = true,
["5525"] = true,
["6290"] = true,
["4592"] = true,
["5095"] = true,
},
["knownTradeSkillResults"] = {
["787"] = true,
["5525"] = true,
["6290"] = true,
["4592"] = true,
["5095"] = true,
},
},
},
["barCharacterSpecific"] = true,
["sharedProfile"] = {
["guideFullscreen"] = false,
["snapshotOnHover"] = true,
["contextualFishingSplit172d4Applied"] = true,
["guidePoint"] = {
["y"] = 0,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["hudShown"] = false,
["milestoneNotices"] = true,
["sessionAutoStartWithPole"] = false,
["hudPoint"] = {
["y"] = 90,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["guideStarterAssist"] = true,
["tackle"] = {
["mode"] = "BEST",
},
["sound"] = {
["enabled"] = false,
["volumeBoost"] = true,
["focus"] = true,
["background"] = true,
["activation"] = "cast",
},
["contextualFishingRestored164bApplied"] = true,
["guideWindowScale"] = 1.2,
["guideTextScale"] = 1,
["tackleSwap"] = {
["restore"] = {
},
["active"] = false,
},
["milestoneAutoShareMode"] = "OFF",
["keybinds"] = {
},
["contextualKeyOptIn165bApplied"] = true,
["barShown"] = true,
["warnings"] = true,
["milestoneGuildReports"] = false,
["guideStarterAssistGroupKey"] = "",
["forever"] = {
["sessionsUI"] = {
["schemaVersion"] = 1,
["selectedByCharacter"] = {
},
},
["characterIdentity"] = {
["schemaVersion"] = 2,
["legacyBucketsPreserved"] = true,
},
["sessions"] = {
["schemaVersion"] = 1,
["characters"] = {
},
},
["schemaVersion"] = 1,
["wiki"] = {
["search"] = "",
["schemaVersion"] = 1,
["category"] = "all",
},
},
["minimap"] = {
["shown"] = true,
["angle"] = 225,
},
["activeTab"] = "guide",
["notifications"] = true,
["milestoneForcedEmotes"] = true,
["theme"] = "ocean",
["bar"] = {
["suppressTooltipsDuringActions"] = false,
["direction"] = "RIGHT",
["castTimer"] = {
["enabled"] = true,
["circleDirection"] = "CLOCKWISE",
["horizontalDirection"] = "LEFT_TO_RIGHT",
["colorMode"] = "THEME",
["verticalDirection"] = "BOTTOM_TO_TOP",
["verticalSide"] = "RIGHT",
["horizontalSide"] = "ABOVE",
},
["showAllFlyoutChoices"] = false,
["tooltips"] = true,
["autoLootPreferenceEstablished"] = true,
["locked"] = false,
["authoredHudAnimations"] = true,
["visibilityMode"] = "AUTO_COLLAPSE",
["doubleRightCast"] = true,
["forceShown"] = false,
["oneButtonInteractAssist"] = true,
["hiddenButtons"] = {
},
["oneButtonFishing"] = true,
["point"] = {
["y"] = 28,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["scale"] = 1,
["horizontalDirection"] = "RIGHT",
["lootFloaters"] = true,
["selectedCampfireAction"] = "AUTO",
["spacing"] = 2,
["mode"] = "CIRCLE",
["expanded"] = true,
["oneButtonHudClick"] = true,
["pauseClickToMoveFishing"] = false,
["effectiveReadoutColor"] = "GREEN",
["contextualFishingKeyboardKey"] = "F",
["hudButtonAnimations"] = true,
["oneButtonRangeWarning"] = true,
["oneButtonRangeBell"] = true,
["flyouts"] = {
["consume"] = "DOWN",
["cook"] = "DOWN",
["sessions"] = "DOWN",
["fire"] = "DOWN",
["gear"] = "DOWN",
["lure"] = "DOWN",
},
["verticalDirection"] = "DOWN",
["autoLootWhileFishing"] = true,
["contextualFishingKeyBeforeSplit172d4"] = "F",
["effectiveReadoutSize"] = 1,
},
},
["classicThemeRetired150Applied"] = true,
["settingsCharacterSpecific"] = true,
["activeSettingsCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["characterProfiles"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["hudPoint"] = {
["y"] = 90,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["guideStarterAssist"] = false,
["contextualFishingSplit172d4Applied"] = true,
["milestoneSystem113dApplied"] = true,
["forever"] = {
["sessionsUI"] = {
["schemaVersion"] = 1,
["selectedByCharacter"] = {
},
},
["characterIdentity"] = {
["schemaVersion"] = 2,
["legacyBucketsPreserved"] = true,
},
["sessions"] = {
["schemaVersion"] = 1,
["characters"] = {
},
},
["schemaVersion"] = 1,
["wiki"] = {
["search"] = "",
["schemaVersion"] = 1,
["category"] = "all",
},
},
["sound"] = {
["muteOriginalSplash"] = false,
["volumeBoost"] = true,
["helperVolume"] = 1,
["mutePetSoundsWhilePole"] = true,
["probeEnabled"] = false,
["adjustMusic"] = true,
["focus"] = true,
["enabled"] = true,
["background"] = true,
["soundDefault0202Applied"] = true,
["activation"] = "cast",
},
["keybinds"] = {
},
["milestoneForcedEmotes"] = false,
["milestoneGuildReports"] = false,
["guideStarterAssistGroupKey"] = "",
["notifications"] = true,
["bar"] = {
["oneButtonRangeWarning"] = true,
["direction"] = "RIGHT",
["castTimer"] = {
["enabled"] = true,
["circleDirection"] = "CLOCKWISE",
["horizontalDirection"] = "LEFT_TO_RIGHT",
["colorMode"] = "THEME",
["verticalDirection"] = "BOTTOM_TO_TOP",
["verticalSide"] = "RIGHT",
["horizontalSide"] = "ABOVE",
},
["showAllFlyoutChoices"] = false,
["tooltips"] = true,
["autoLootPreferenceEstablished"] = true,
["locked"] = false,
["authoredHudAnimations"] = true,
["autoLootWhileFishing"] = true,
["doubleRightCast"] = true,
["forceShown"] = true,
["oneButtonInteractAssist"] = true,
["hiddenButtons"] = {
["guide"] = true,
},
["oneButtonFishing"] = true,
["point"] = {
["y"] = 108.0998611450195,
["x"] = 816.4998779296875,
["point"] = "CENTER",
["relativePoint"] = "BOTTOMLEFT",
},
["contextualFishingKeyboardKey"] = "ENTER",
["effectiveReadoutColor"] = "GREEN",
["flyouts"] = {
["consume"] = "DOWN",
["cook"] = "DOWN",
["sessions"] = "DOWN",
["fire"] = "DOWN",
["gear"] = "DOWN",
["lure"] = "DOWN",
},
["selectedCampfireAction"] = "AUTO",
["spacing"] = 2,
["doubleRightCastSecureAttempt100Applied"] = true,
["mode"] = "CIRCLE",
["expanded"] = true,
["flyoutDefault042Applied"] = true,
["horizontalDirection"] = "RIGHT",
["modeDefault033Applied"] = true,
["oneButtonHudClick"] = true,
["selectedLureItemID"] = 6529,
["pauseClickToMoveFishing"] = false,
["spacingDefault031Applied"] = true,
["visibilityMode"] = "FORCED_ON",
["hudButtonAnimations"] = true,
["scale"] = 1,
["oneButtonRangeBell"] = true,
["verticalDirection"] = "DOWN",
["lootFloaters"] = true,
["effectiveReadoutSize"] = 1,
["contextualFishingKeyBeforeSplit172d4"] = "F",
["suppressTooltipsDuringActions"] = false,
},
["hudButtonSwap132dApplied"] = true,
["snapshotOnHover"] = true,
["guidePoint"] = {
["y"] = 0,
["x"] = 0,
["point"] = "CENTER",
["relativePoint"] = "CENTER",
},
["minimap"] = {
["shown"] = true,
["angle"] = 225,
},
["milestoneNotices"] = true,
["sessionAutoStartWithPole"] = false,
["tackle"] = {
["mode"] = "MANUAL",
},
["theme"] = "gilded",
["guideWindowScale"] = 1.2,
["guideTextScale"] = 1,
["tackleSwap"] = {
["normalRestoreTime"] = 15471.676,
["normalRestore"] = {
["1"] = {
["empty"] = true,
["slot"] = 1,
},
["8"] = {
["itemID"] = 252425,
["slot"] = 8,
["empty"] = false,
["link"] = "|cnIQ3:|Hitem:252425:15:::::::20:1485::::::::Player-6934-0043A935:|h[Dark Leather Boots]|h|r",
},
["16"] = {
["itemID"] = 276886,
["slot"] = 16,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:276886::::::::20:1485::11:::::::|h[Chol'aruk's Trophy Sword]|h|r",
},
["17"] = {
["empty"] = true,
["slot"] = 17,
},
["18"] = {
["itemID"] = 5309,
["slot"] = 18,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:5309::::::::20:1485::11:::::::|h[Privateer Musket]|h|r",
},
["6"] = {
["itemID"] = 4246,
["slot"] = 6,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:4246::::::::20:1485::::::::Player-6934-01B13CBF:|h[Fine Leather Belt]|h|r",
},
["10"] = {
["itemID"] = 2976,
["slot"] = 10,
["empty"] = false,
["link"] = "|cnIQ2:|Hitem:2976:15:::::::20:1485::1::1:28:5256:::::|h[Hunting Gloves]|h|r",
},
},
["active"] = false,
["normalRestoreOwner"] = "ForeverGUID-Player-6934-0043A935",
["owner"] = "ForeverGUID-Player-6934-0043A935",
["restore"] = {
},
["normalRestoreReason"] = "PLAYER_REGEN_ENABLED",
},
["milestoneAutoShareMode"] = "OFF",
["barShown"] = true,
["journal"] = {
["accountWide"] = true,
["fishingHistory"] = {
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["lastCaught"] = 1794535442,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533458,
["caught"] = 76,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["lastCaught"] = 1794533891,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533891,
["caught"] = 1,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["lastCaught"] = 1794550113,
["lastZone"] = "Durotar",
["firstCaught"] = 1794550113,
["caught"] = 1,
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 11,
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["lastZone"] = "The Barrens",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 86,
["firstCaught"] = 1794542998,
["lastCaught"] = 1794883714,
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 119,
["firstCaught"] = 1794543010,
["lastCaught"] = 1794884818,
},
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794882335,
["firstCaught"] = 1794882335,
["lastZone"] = "The Barrens",
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 22,
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["lastZone"] = "The Barrens",
},
},
["summaryDefault113eApplied"] = true,
["milestoneAllDefault169wApplied"] = true,
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["milestoneSearch"] = "",
["viewMode"] = "account",
["totalCatches"] = 315,
["skillCapEventStyle035Applied"] = true,
["surfaceMode"] = "milestones",
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
["totalFishingSeconds"] = 5682.286000000026,
["milestoneView"] = "all",
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
[225] = true,
[150] = true,
["225"] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["guildChatAnnounce"] = false,
["milestoneAutoShareMode"] = "OFF",
["milestoneNotices"] = true,
["characters"] = {
["ForeverGUID-Player-6934-0043A935"] = {
["skillCapObserved"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["fishingHistory"] = {
[6303] = {
["lastSubZone"] = "Bladefist Bay",
["opened"] = 0,
["lastCaught"] = 1794535442,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533458,
["caught"] = 76,
},
[6356] = {
["lastSubZone"] = "Darkspear Strand",
["opened"] = 0,
["lastCaught"] = 1794533891,
["lastZone"] = "Durotar",
["firstCaught"] = 1794533891,
["caught"] = 1,
},
[6292] = {
["lastSubZone"] = "Jaggedswine Farm",
["opened"] = 0,
["lastCaught"] = 1794550113,
["lastZone"] = "Durotar",
["firstCaught"] = 1794550113,
["caught"] = 1,
},
[6308] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 11,
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["lastZone"] = "The Barrens",
},
[6289] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 86,
["firstCaught"] = 1794542998,
["lastCaught"] = 1794883714,
},
[6291] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["lastZone"] = "The Barrens",
["caught"] = 119,
["firstCaught"] = 1794543010,
["lastCaught"] = 1794884818,
},
[3385] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 1,
["lastCaught"] = 1794882335,
["firstCaught"] = 1794882335,
["lastZone"] = "The Barrens",
},
[6522] = {
["lastSubZone"] = "Lushwater Oasis",
["opened"] = 0,
["caught"] = 22,
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["lastZone"] = "The Barrens",
},
},
["lastSeen"] = 1794884833,
["fish"] = {
[6292] = {
["count"] = 1,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["count"] = 11,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["source"] = "fishing-loot-structured",
["count"] = 76,
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["count"] = 119,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884818,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6289] = {
["count"] = 86,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883714,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
[6522] = {
["count"] = 22,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
},
["skillCapEventStyle035Applied"] = true,
["totalFishingSeconds"] = 5682.286000000026,
["totalCookedFish"] = 75,
["skillCapUnlocks"] = {
["Fishing"] = {
["150"] = true,
[75] = true,
["75"] = true,
[225] = true,
[150] = true,
["225"] = true,
},
["Cooking"] = {
[150] = true,
["150"] = true,
[75] = true,
["75"] = true,
},
},
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["skillObserved"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["source"] = "equipped",
["count"] = 1,
["lastSeen"] = 1794528221,
},
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
["count"] = 75,
},
},
["totalCatches"] = 315,
["name"] = "Rondine",
["faction"] = "Horde",
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["realm"] = "CAMWOW US2 Realm 8 PvP",
["achievements"] = {
["cooking_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535775,
["points"] = 5,
},
["catch_6289"] = {
["earned"] = true,
["earnedAt"] = 1794542998,
["points"] = 5,
},
["route_step_horde_horde-thunder-bluff"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["cook_787_1"] = {
["earned"] = true,
["earnedAt"] = 1794535664,
["points"] = 5,
},
["first_fry"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["trophy_family_mud_snapper"] = {
["earned"] = true,
["earnedAt"] = 1794550113,
["points"] = 15,
},
["cook_total_10"] = {
["earned"] = true,
["earnedAt"] = 1794535692,
["points"] = 10,
},
["dock_regular"] = {
["earned"] = true,
["earnedAt"] = 1794879929,
["points"] = 10,
},
["catch_6291"] = {
["earned"] = true,
["earnedAt"] = 1794543010,
["points"] = 5,
},
["stormwind_skillet"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 10,
},
["fishing_rank_journeyman"] = {
["earned"] = true,
["earnedAt"] = 1794535961,
["points"] = 5,
},
["net_mender"] = {
["earned"] = true,
["earnedAt"] = 1794543443,
["points"] = 10,
},
["fishing_rank_expert"] = {
["earned"] = true,
["earnedAt"] = 1794875817,
["points"] = 10,
},
["own_6256"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 10,
},
["catch_6303"] = {
["earned"] = true,
["earnedAt"] = 1794533458,
["points"] = 5,
},
["cook_787_25"] = {
["earned"] = true,
["earnedAt"] = 1794535738,
["points"] = 15,
},
["fishing_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["cook_total_50"] = {
["earned"] = true,
["earnedAt"] = 1794535830,
["points"] = 15,
},
["cooking_rank_apprentice"] = {
["earned"] = true,
["earnedAt"] = 1794528221,
["points"] = 5,
},
["catch_6522"] = {
["earned"] = true,
["earnedAt"] = 1794879656,
["points"] = 5,
},
["catch_6308"] = {
["earned"] = true,
["earnedAt"] = 1794879680,
["points"] = 5,
},
["bucket_warmer"] = {
["earned"] = true,
["earnedAt"] = 1794534511,
["points"] = 5,
},
},
["skillMax"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
},
},
["milestoneForcedEmotes"] = true,
["specials"] = {
[6256] = {
["firstSeen"] = 1794528221,
["source"] = "equipped",
["count"] = 1,
["lastSeen"] = 1794528221,
},
},
["cooked"] = {
[787] = {
["lastCooked"] = 1794535908,
["firstCooked"] = 1794535664,
["source"] = "cooking-craft",
["count"] = 75,
},
},
["activeCharacterKey"] = "ForeverGUID-Player-6934-0043A935",
["fish"] = {
[6292] = {
["count"] = 1,
["source"] = "fishing-loot-structured",
["zone"] = "Durotar",
["subZone"] = "Jaggedswine Farm",
["lastCaught"] = 1794550113,
["firstCaught"] = 1794550113,
["proof"] = "caught",
},
[6308] = {
["count"] = 11,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883705,
["firstCaught"] = 1794879680,
["proof"] = "caught",
},
[6303] = {
["source"] = "fishing-loot-structured",
["count"] = 76,
["zone"] = "Durotar",
["subZone"] = "Bladefist Bay",
["lastCaught"] = 1794535442,
["firstCaught"] = 1794533458,
["proof"] = "caught",
},
[6291] = {
["count"] = 119,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884818,
["firstCaught"] = 1794543010,
["proof"] = "caught",
},
[6289] = {
["count"] = 86,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794883714,
["firstCaught"] = 1794542998,
["proof"] = "caught",
},
[6522] = {
["count"] = 22,
["source"] = "fishing-loot-structured",
["zone"] = "The Barrens",
["subZone"] = "Lushwater Oasis",
["lastCaught"] = 1794884333,
["firstCaught"] = 1794879656,
["proof"] = "caught",
},
},
["milestoneGuildReports"] = false,
["milestoneInbox"] = {
["order"] = {
"first_fry",
"catch_6303",
"bucket_warmer",
"cook_787_1",
"cook_total_10",
"cook_787_25",
"cooking_rank_journeyman",
"cook_total_50",
"fishing_rank_journeyman",
"catch_6289",
"catch_6291",
"net_mender",
"trophy_family_mud_snapper",
"fishing_rank_expert",
"catch_6522",
"catch_6308",
"stormwind_skillet",
"dock_regular",
},
["unseen"] = {
["cooking_rank_journeyman"] = {
["earnedAt"] = 1794535775,
},
["catch_6289"] = {
["earnedAt"] = 1794542998,
},
["cook_787_1"] = {
["earnedAt"] = 1794535664,
},
["first_fry"] = {
["earnedAt"] = 1794533458,
},
["trophy_family_mud_snapper"] = {
["earnedAt"] = 1794550113,
},
["cook_total_10"] = {
["earnedAt"] = 1794535692,
},
["dock_regular"] = {
["earnedAt"] = 1794879929,
},
["catch_6291"] = {
["earnedAt"] = 1794543010,
},
["stormwind_skillet"] = {
["earnedAt"] = 1794879680,
},
["catch_6308"] = {
["earnedAt"] = 1794879680,
},
["cook_787_25"] = {
["earnedAt"] = 1794535738,
},
["cook_total_50"] = {
["earnedAt"] = 1794535830,
},
["catch_6522"] = {
["earnedAt"] = 1794879656,
},
["fishing_rank_expert"] = {
["earnedAt"] = 1794875817,
},
["fishing_rank_journeyman"] = {
["earnedAt"] = 1794535961,
},
["net_mender"] = {
["earnedAt"] = 1794543443,
},
["catch_6303"] = {
["earnedAt"] = 1794533458,
},
["bucket_warmer"] = {
["earnedAt"] = 1794534511,
},
},
},
["skillCaps"] = {
["Fishing"] = 225,
["Cooking"] = 150,
},
["skillObserved"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
["recordSearch"] = "",
["skillMax"] = {
["Fishing"] = 170,
["Cooking"] = 73,
},
},
["milestoneSharingPolicy122wApplied"] = true,
["contextualKeyOptIn165bApplied"] = true,
["milestoneGuildReports140aApplied"] = true,
["guideFullscreen"] = false,
["warnings"] = true,
["optionsPage"] = "sound",
["activeTab"] = "options",
["hudShown"] = false,
["contextualFishingRestored164bApplied"] = true,
},
},
["bar"] = {
["oneButtonRangeWarning"] = true,
["direction"] = "RIGHT",
["castTimer"] = {
["enabled"] = true,
["circleDirection"] = "CLOCKWISE",
["horizontalDirection"] = "LEFT_TO_RIGHT",
["colorMode"] = "THEME",
["verticalDirection"] = "BOTTOM_TO_TOP",
["verticalSide"] = "RIGHT",
["horizontalSide"] = "ABOVE",
},
["showAllFlyoutChoices"] = false,
["tooltips"] = true,
["autoLootPreferenceEstablished"] = true,
["locked"] = false,
["authoredHudAnimations"] = true,
["autoLootWhileFishing"] = true,
["doubleRightCast"] = true,
["forceShown"] = true,
["oneButtonInteractAssist"] = true,
["hiddenButtons"] = {
["guide"] = true,
},
["oneButtonFishing"] = true,
["point"] = {
["y"] = 108.0998611450195,
["x"] = 816.4998779296875,
["point"] = "CENTER",
["relativePoint"] = "BOTTOMLEFT",
},
["contextualFishingKeyboardKey"] = "ENTER",
["effectiveReadoutColor"] = "GREEN",
["flyouts"] = {
["consume"] = "DOWN",
["cook"] = "DOWN",
["sessions"] = "DOWN",
["fire"] = "DOWN",
["gear"] = "DOWN",
["lure"] = "DOWN",
},
["selectedCampfireAction"] = "AUTO",
["spacing"] = 2,
["doubleRightCastSecureAttempt100Applied"] = true,
["mode"] = "CIRCLE",
["expanded"] = true,
["flyoutDefault042Applied"] = true,
["horizontalDirection"] = "RIGHT",
["modeDefault033Applied"] = true,
["oneButtonHudClick"] = true,
["selectedLureItemID"] = 6529,
["pauseClickToMoveFishing"] = false,
["spacingDefault031Applied"] = true,
["visibilityMode"] = "FORCED_ON",
["hudButtonAnimations"] = true,
["scale"] = 1,
["oneButtonRangeBell"] = true,
["verticalDirection"] = "DOWN",
["lootFloaters"] = true,
["effectiveReadoutSize"] = 1,
["contextualFishingKeyBeforeSplit172d4"] = "F",
["suppressTooltipsDuringActions"] = false,
},
}
