
HandyNotes_ClassTrainersDB = {
["global"] = {
["setupDone"] = true,
},
["profileKeys"] = {
["Rondine Signalborn"] = "Default",
},
["profiles"] = {
["Default"] = {
["portal"] = false,
["demon"] = false,
["myClassOnly"] = true,
},
},
}
